# ZeroLimit 服务器监控与钉钉机器人部署教程

这个小服务负责三件事：

1. 给 ZeroLimit 仪表盘提供服务器状态：`/status`
2. 手动推送状态到钉钉：`/notify`
3. 钉钉里发任意数字后推送状态报表：`/dingtalk/callback`

## 1. 服务器准备

服务器需要 Node.js 20 或更高版本。

```bash
node -v
```

把整个 `tools/zerolimit-monitor` 文件夹上传到服务器，例如：

```bash
/opt/zerolimit-monitor
```

## 2. 配置环境变量

先进入目录：

```bash
cd /opt/zerolimit-monitor
```

创建启动脚本：

```bash
nano start.sh
```

填入下面内容，按自己的信息修改：

```bash
#!/usr/bin/env bash
export PORT=8787
export MONITOR_TOKEN="自己设置一个长一点的访问令牌"

# 钉钉自定义机器人 Webhook，用于主动推送
export DINGTALK_WEBHOOK="https://oapi.dingtalk.com/robot/send?access_token=xxxx"
export DINGTALK_SECRET="SECxxxx"

# 钉钉回调地址保护令牌，自己设置
export DINGTALK_CALLBACK_TOKEN="自己设置一个回调令牌"

# 可选：让报表显示 ZeroLimit/CLIProxy 账号数量
export ZEROLIMIT_API_BASE="https://aisiu.me"
export ZEROLIMIT_MANAGEMENT_KEY="你的管理密钥"

# 可选：服务健康检查，多个用英文逗号分隔
export SERVICE_CHECKS="New API|https://aisiu.me,本机 CLIProxy|http://127.0.0.1:8317"

node server.mjs
```

保存后执行：

```bash
chmod +x start.sh
./start.sh
```

浏览器测试：

```text
http://服务器IP:8787/status
```

如果设置了 `MONITOR_TOKEN`，测试时要带上：

```bash
curl -H "Authorization: Bearer 你的访问令牌" http://127.0.0.1:8787/status
```

## 3. 用 pm2 后台运行

推荐用 pm2：

```bash
npm i -g pm2
pm2 start ./start.sh --name zerolimit-monitor
pm2 save
pm2 startup
```

查看日志：

```bash
pm2 logs zerolimit-monitor
```

## 4. ZeroLimit 里填写

打开 ZeroLimit：

1. 进入 `设置`
2. 找到 `服务器监控`
3. `监控服务地址` 填：

```text
http://服务器IP:8787
```

4. `访问令牌` 填 `MONITOR_TOKEN`
5. `钉钉推送地址` 填：

```text
http://服务器IP:8787/notify
```

点 `测试` 和 `推送测试`，都成功后仪表盘就会显示服务器状态。

## 5. 钉钉里发数字查状态

在钉钉机器人后台，把消息回调地址设置成：

```text
http://服务器IP:8787/dingtalk/callback?token=你的回调令牌
```

这里的 `token` 要和 `DINGTALK_CALLBACK_TOKEN` 一样。

配置完成后，你在钉钉里给机器人发任意数字，例如：

```text
1
```

机器人会推送一份 ZeroLimit 状态报表。

## 6. 防火墙

如果 ZeroLimit 客户端或钉钉访问不到，需要放行端口：

```bash
ufw allow 8787/tcp
```

如果你用宝塔，也可以在宝塔安全页放行 `8787`。

更推荐用 Nginx 反代成 HTTPS，例如：

```text
https://你的域名/zerolimit-monitor
```

然后 ZeroLimit 里就填这个 HTTPS 地址。

## 7. 注意

- 不要把 `MONITOR_TOKEN`、`DINGTALK_SECRET`、`ZEROLIMIT_MANAGEMENT_KEY` 发给别人。
- 普通钉钉群 Webhook 只能主动推送，不能接收你发的数字。
- “发数字就回报表”需要钉钉机器人支持消息回调，或者企业内部机器人/应用机器人回调。
