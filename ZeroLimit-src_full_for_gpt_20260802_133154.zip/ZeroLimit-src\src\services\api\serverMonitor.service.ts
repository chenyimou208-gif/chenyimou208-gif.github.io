import type { MonitorNotifyResponse, QuotaSnapshot, ServerMonitorStatus } from '@/types';

function buildUrl(base: string, path: string): string {
  const cleanBase = base.trim().replace(/\/+$/, '');
  const cleanPath = path.replace(/^\/+/, '');
  return `${cleanBase}/${cleanPath}`;
}

function buildHeaders(token: string): HeadersInit {
  const headers: HeadersInit = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
  };

  if (token.trim()) {
    headers.Authorization = `Bearer ${token.trim()}`;
  }

  return headers;
}

async function parseJsonResponse<T>(response: Response): Promise<T> {
  const text = await response.text();
  const data = text ? JSON.parse(text) : {};

  if (!response.ok) {
    const message = typeof data?.message === 'string' ? data.message : response.statusText;
    throw new Error(message || `HTTP ${response.status}`);
  }

  return data as T;
}

async function fetchJson<T>(url: string, options: RequestInit, timeoutMs: number, timeoutMessage: string): Promise<T> {
  try {
    const response = await fetch(url, {
      ...options,
      signal: AbortSignal.timeout(timeoutMs),
    });
    return parseJsonResponse<T>(response);
  } catch (error) {
    const err = error as Error;
    if (err.name === 'TimeoutError' || err.name === 'AbortError' || err.message.includes('timed out')) {
      throw new Error(timeoutMessage);
    }
    throw error;
  }
}

export const serverMonitorApi = {
  async getStatus(monitorUrl: string, token: string): Promise<ServerMonitorStatus> {
    if (!monitorUrl.trim()) {
      throw new Error('未配置服务器监控地址');
    }

    return fetchJson<ServerMonitorStatus>(buildUrl(monitorUrl, '/status'), {
      method: 'GET',
      headers: buildHeaders(token),
    }, 5000, '服务器监控请求超时，请检查监控服务是否正常或网络是否过慢');
  },

  async sendDingTalkReport(notifyUrl: string, token: string): Promise<MonitorNotifyResponse> {
    if (!notifyUrl.trim()) {
      throw new Error('未配置钉钉推送地址');
    }

    return fetchJson<MonitorNotifyResponse>(notifyUrl.trim(), {
      method: 'POST',
      headers: buildHeaders(token),
      body: JSON.stringify({ source: 'zerolimit-dashboard' }),
    }, 60000, '钉钉实时报告生成超时，请稍后再试');
  },

  async saveQuotaSnapshot(monitorUrl: string, token: string, snapshot: QuotaSnapshot): Promise<MonitorNotifyResponse> {
    if (!monitorUrl.trim()) return { ok: false, message: '未配置服务器监控地址' };

    return fetchJson<MonitorNotifyResponse>(buildUrl(monitorUrl, '/quota-snapshot'), {
      method: 'POST',
      headers: buildHeaders(token),
      body: JSON.stringify(snapshot),
    }, 5000, '配额快照同步到服务器超时');
  },
};
