﻿# ZeroLimit 源码包说明（给 GPT 网页版）

打包时间：20260802_133154

## 这个包包含
- 前端源码：src/
- Tauri/Rust 后端源码：src-tauri/src/
- 静态资源：public/
- 文档、脚本、截图：docs/ scripts/ screenshots/
- 构建配置：package.json、pnpm-lock.yaml、vite/tsconfig/components 配置
- Rust 配置和锁文件：src-tauri/Cargo.toml、src-tauri/Cargo.lock、tauri.conf.json
- 最近构建产物：dist/（方便参考当前页面打包结果）

## 这个包刻意不包含
- node_modules/：依赖目录太大，重新 pnpm install 即可
- src-tauri/target/：Rust 构建目录很大，重新构建即可
- .git/：版本历史很大且无助于 GPT 修改功能

## 常用命令
pnpm install
pnpm build
pnpm tauri build --bundles nsis

## 最近重点改动
- 0额度时间表：月额度/周额度分开管理。
- 启动时从旧 app 数据目录 com.0xtbug.zero-limit 迁移到 com.zerolimit.desktop。
- 修复旧版本服务器监控配置 zerolimit-integrations 恢复问题。
- main.tsx 先迁移旧本地数据，再加载 App，避免 Zustand 先读到空配置。
- 修复 X 关闭行为相关逻辑：可按设置后台运行或退出。
