export interface IntegrationSettings {
  monitorUrl: string;
  monitorToken: string;
  notifyUrl: string;
}

export interface ServerMetric {
  label?: string;
  value?: number;
  total?: number;
  used?: number;
  free?: number;
  usagePercent?: number;
}

export interface ServerDiskMetric extends ServerMetric {
  filesystem?: string;
  mount?: string;
}

export interface ServerServiceStatus {
  name: string;
  status: 'ok' | 'warning' | 'error' | 'unknown';
  message?: string;
  latencyMs?: number;
}

export interface ServerQuotaSummary {
  accountsTotal?: number;
  accountsEnabled?: number;
  accountsDisabled?: number;
  unavailable?: number;
}

export interface QuotaSnapshot {
  average: number;
  accountCount: number;
  itemCount: number;
  healthyCount: number;
  watchCount: number;
  lowCount: number;
  unavailableCount: number;
  updatedAt: string;
}

export interface ServerMonitorStatus {
  timestamp?: string;
  hostname?: string;
  ip?: string;
  uptimeSec?: number;
  load?: {
    one?: number;
    five?: number;
    fifteen?: number;
  };
  cpu?: ServerMetric & {
    cores?: number;
    model?: string;
  };
  memory?: ServerMetric;
  disks?: ServerDiskMetric[];
  network?: {
    rxBytes?: number;
    txBytes?: number;
    rxRateBps?: number;
    txRateBps?: number;
  };
  services?: ServerServiceStatus[];
  quota?: ServerQuotaSummary;
  quotaSnapshot?: QuotaSnapshot;
}

export interface MonitorNotifyResponse {
  ok: boolean;
  message?: string;
}
