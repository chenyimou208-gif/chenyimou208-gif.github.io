import axios, { AxiosError, type AxiosInstance, type AxiosRequestConfig } from 'axios';
import type {
  Sub2ApiAccount,
  Sub2ApiBatchResult,
  Sub2ApiConfig,
  Sub2ApiImportResult,
  Sub2ApiKey,
  Sub2ApiLoginResponse,
  Sub2ApiPagedResponse,
  Sub2ApiQuotaResult,
  Sub2ApiUser,
} from '@/types';

interface WrappedResponse<T> {
  code?: number | string;
  message?: string;
  data?: T;
  error?: string;
  metadata?: unknown;
}

interface Sub2ApiSession {
  accessToken: string;
  refreshToken?: string;
  tokenExpiresAt?: number;
}

function normalizeSub2ApiBase(base: string): string {
  let normalized = base.trim().replace(/\/+$/, '');
  normalized = normalized.replace(/\/api\/v1\/?$/i, '');

  if (!/^https?:\/\//i.test(normalized)) {
    normalized = `http://${normalized}`;
  }

  return `${normalized}/api/v1`;
}

function unwrapResponse<T>(response: T | WrappedResponse<T>): T {
  if (response && typeof response === 'object' && 'code' in response) {
    const wrapped = response as WrappedResponse<T>;
    const code = wrapped.code;
    const ok = code === 0 || code === '0' || code === undefined;
    if (!ok) {
      throw new Error(wrapped.message || wrapped.error || `Sub2API returned code ${String(code)}`);
    }
    return wrapped.data as T;
  }

  return response as T;
}

function extractItems<T>(value: unknown): T[] {
  const unwrapped = unwrapResponse(value as WrappedResponse<unknown>);
  if (Array.isArray(unwrapped)) return unwrapped as T[];
  if (unwrapped && typeof unwrapped === 'object') {
    const record = unwrapped as Record<string, unknown>;
    for (const key of ['items', 'records', 'list', 'data', 'accounts', 'keys', 'channels']) {
      const candidate = record[key];
      if (Array.isArray(candidate)) return candidate as T[];
    }
  }
  return [];
}

function buildQuery(params: Record<string, string | number | boolean | undefined>): string {
  const query = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== '') {
      query.set(key, String(value));
    }
  });
  const text = query.toString();
  return text ? `?${text}` : '';
}

class Sub2ApiClient {
  private instance: AxiosInstance;
  private session: Sub2ApiSession | null = null;
  private config: Sub2ApiConfig | null = null;

  constructor() {
    this.instance = axios.create({
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.instance.interceptors.request.use((config) => {
      if (this.session?.accessToken) {
        config.headers.Authorization = `Bearer ${this.session.accessToken}`;
      }
      if (this.config?.gatewayKey) {
        config.headers['X-ZeroLimit-Sub2API-Key'] = this.config.gatewayKey;
      }
      return config;
    });
  }

  setConfig(config: Sub2ApiConfig): void {
    this.config = {
      ...config,
      baseUrl: normalizeSub2ApiBase(config.baseUrl),
      email: config.email.trim(),
      gatewayKey: config.gatewayKey?.trim() || '',
    };
    this.instance.defaults.baseURL = this.config.baseUrl;
  }

  setSession(session: Sub2ApiSession | null): void {
    this.session = session;
  }

  getNormalizedBaseUrl(): string {
    return this.config?.baseUrl || '';
  }

  private ensureConfigured(): Sub2ApiConfig {
    if (!this.config?.baseUrl || !this.config.email || !this.config.password) {
      throw new Error('请先配置 Sub2API 地址、邮箱和密码');
    }
    return this.config;
  }

  private handleError(error: unknown): never {
    if (axios.isAxiosError(error)) {
      const axiosError = error as AxiosError<WrappedResponse<unknown>>;
      const data = axiosError.response?.data;
      const status = axiosError.response?.status;
      const message =
        data?.message ||
        data?.error ||
        axiosError.message ||
        'Sub2API request failed';
      if (status === 423) {
        throw new Error(`${message}。需要先在 Sub2API 后台完成首次合规确认。`);
      }
      throw new Error(status ? `${status} ${message}` : message);
    }

    throw error instanceof Error ? error : new Error('Sub2API request failed');
  }

  async login(): Promise<Sub2ApiLoginResponse> {
    const config = this.ensureConfigured();
    try {
      const response = await this.instance.post<WrappedResponse<Sub2ApiLoginResponse> | Sub2ApiLoginResponse>(
        '/auth/login',
        {
          email: config.email,
          password: config.password,
        },
        { timeout: 30000 }
      );
      const data = unwrapResponse(response.data);
      this.session = {
        accessToken: data.access_token,
        refreshToken: data.refresh_token,
        tokenExpiresAt: data.expires_in ? Date.now() + data.expires_in * 1000 : undefined,
      };
      return data;
    } catch (error) {
      this.handleError(error);
    }
  }

  async refreshToken(): Promise<Sub2ApiLoginResponse | null> {
    if (!this.session?.refreshToken) return null;

    try {
      const response = await this.instance.post<WrappedResponse<Sub2ApiLoginResponse> | Sub2ApiLoginResponse>(
        '/auth/refresh',
        { refresh_token: this.session.refreshToken },
        { timeout: 30000 }
      );
      const data = unwrapResponse(response.data);
      this.session = {
        accessToken: data.access_token,
        refreshToken: data.refresh_token || this.session.refreshToken,
        tokenExpiresAt: data.expires_in ? Date.now() + data.expires_in * 1000 : undefined,
      };
      return data;
    } catch {
      return null;
    }
  }

  async me(): Promise<Sub2ApiUser> {
    try {
      const response = await this.instance.get<WrappedResponse<Sub2ApiUser> | Sub2ApiUser>('/auth/me');
      return unwrapResponse(response.data);
    } catch (error) {
      this.handleError(error);
    }
  }

  async listAccounts(options: { page?: number; pageSize?: number; search?: string } = {}): Promise<{
    accounts: Sub2ApiAccount[];
    raw: Sub2ApiPagedResponse<Sub2ApiAccount> | Sub2ApiAccount[];
  }> {
    const page = options.page ?? 1;
    const pageSize = options.pageSize ?? 200;
    const query = buildQuery({
      page,
      page_size: pageSize,
      search: options.search?.trim(),
    });

    try {
      const response = await this.instance.get<
        WrappedResponse<Sub2ApiPagedResponse<Sub2ApiAccount> | Sub2ApiAccount[]> |
        Sub2ApiPagedResponse<Sub2ApiAccount> |
        Sub2ApiAccount[]
      >(`/admin/accounts${query}`);
      const raw = unwrapResponse(response.data);
      return {
        accounts: extractItems<Sub2ApiAccount>(response.data),
        raw: raw as Sub2ApiPagedResponse<Sub2ApiAccount> | Sub2ApiAccount[],
      };
    } catch (error) {
      this.handleError(error);
    }
  }

  async getAccount(id: number | string): Promise<Sub2ApiAccount> {
    try {
      const response = await this.instance.get<WrappedResponse<Sub2ApiAccount> | Sub2ApiAccount>(`/admin/accounts/${id}`);
      return unwrapResponse(response.data);
    } catch (error) {
      this.handleError(error);
    }
  }

  async testAccount(id: number | string): Promise<unknown> {
    return this.postAction(`/admin/accounts/${id}/test`);
  }

  async refreshAccount(id: number | string): Promise<unknown> {
    return this.postAction(`/admin/accounts/${id}/refresh`, undefined, { timeout: 120000 });
  }

  async clearError(id: number | string): Promise<unknown> {
    return this.postAction(`/admin/accounts/${id}/clear-error`);
  }

  async clearRateLimit(id: number | string): Promise<unknown> {
    return this.postAction(`/admin/accounts/${id}/clear-rate-limit`);
  }

  async recoverState(id: number | string): Promise<unknown> {
    return this.postAction(`/admin/accounts/${id}/recover-state`);
  }

  async resetQuota(id: number | string): Promise<unknown> {
    return this.postAction(`/admin/accounts/${id}/reset-quota`);
  }

  async setSchedulable(id: number | string, schedulable: boolean): Promise<unknown> {
    return this.postAction(`/admin/accounts/${id}/schedulable`, { schedulable });
  }

  async updateStatus(id: number | string, status: string): Promise<unknown> {
    try {
      const response = await this.instance.put<WrappedResponse<unknown> | unknown>(`/admin/accounts/${id}`, { status });
      return unwrapResponse(response.data);
    } catch (error) {
      this.handleError(error);
    }
  }

  async deleteAccount(id: number | string): Promise<unknown> {
    try {
      const response = await this.instance.delete<WrappedResponse<unknown> | unknown>(`/admin/accounts/${id}`);
      return unwrapResponse(response.data);
    } catch (error) {
      this.handleError(error);
    }
  }

  async queryOpenAiQuota(id: number | string): Promise<Sub2ApiQuotaResult> {
    try {
      const response = await this.instance.get<WrappedResponse<Sub2ApiQuotaResult> | Sub2ApiQuotaResult>(
        `/admin/openai/accounts/${id}/quota`
      );
      return unwrapResponse(response.data);
    } catch (error) {
      this.handleError(error);
    }
  }

  async batchRefresh(ids: Array<number | string>): Promise<Sub2ApiBatchResult> {
    return this.postAction('/admin/accounts/batch-refresh', { account_ids: ids }, { timeout: 120000 }) as Promise<Sub2ApiBatchResult>;
  }

  async batchClearError(ids: Array<number | string>): Promise<Sub2ApiBatchResult> {
    return this.postAction('/admin/accounts/batch-clear-error', { account_ids: ids }) as Promise<Sub2ApiBatchResult>;
  }

  async bulkUpdate(ids: Array<number | string>, updates: Record<string, unknown>): Promise<Sub2ApiBatchResult> {
    return this.postAction('/admin/accounts/bulk-update', {
      account_ids: ids,
      ...updates,
    }) as Promise<Sub2ApiBatchResult>;
  }

  async importAccountData(data: string): Promise<Sub2ApiImportResult> {
    return this.postAction('/admin/accounts/data', {
      data,
      skip_default_group_bind: false,
    }, { timeout: 120000 }) as Promise<Sub2ApiImportResult>;
  }

  async importCodexSession(content: string, name: string): Promise<Sub2ApiImportResult> {
    return this.postAction('/admin/accounts/import/codex-session', {
      content,
      name,
      update_existing: true,
    }, { timeout: 120000 }) as Promise<Sub2ApiImportResult>;
  }

  async listKeys(): Promise<Sub2ApiKey[]> {
    try {
      const response = await this.instance.get<WrappedResponse<Sub2ApiPagedResponse<Sub2ApiKey> | Sub2ApiKey[]> | Sub2ApiPagedResponse<Sub2ApiKey> | Sub2ApiKey[]>(
        '/keys?page=1&page_size=100'
      );
      return extractItems<Sub2ApiKey>(response.data);
    } catch (error) {
      this.handleError(error);
    }
  }

  private async postAction(path: string, data?: unknown, config?: AxiosRequestConfig): Promise<unknown> {
    try {
      const response = await this.instance.post<WrappedResponse<unknown> | unknown>(path, data, config);
      return unwrapResponse(response.data);
    } catch (error) {
      this.handleError(error);
    }
  }
}

export const sub2apiApi = new Sub2ApiClient();
export { normalizeSub2ApiBase };
