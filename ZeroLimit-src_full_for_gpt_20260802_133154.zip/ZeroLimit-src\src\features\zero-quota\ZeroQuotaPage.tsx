import { useCallback, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { toast } from 'sonner';
import {
  AlertCircle,
  CalendarClock,
  CheckCircle2,
  Clock3,
  Database,
  Eye,
  EyeOff,
  Loader2,
  Network,
  Power,
  RefreshCw,
  Search,
} from 'lucide-react';
import { authFilesApi } from '@/services/api/auth.service';
import { quotaApi } from '@/services/api/quota.service';
import { useAuthStore } from '@/features/auth/auth.store';
import { useCpaNodesStore } from '@/features/nodes/nodes.store';
import { resolveCodexChatgptAccountId } from '@/shared/utils/quota.helpers';
import { maskEmail } from '@/shared/utils/privacy';
import { Button } from '@/shared/components/ui/button';
import { Badge } from '@/shared/components/ui/badge';
import { Card, CardContent } from '@/shared/components/ui/card';
import { Input } from '@/shared/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/shared/components/ui/select';
import type { AuthFile, CpaNodeConnectionConfig, QuotaModel } from '@/types';

const DISABLED_OVERRIDES_STORAGE_KEY = 'zerolimit.quota.disabledOverrides.v1';
const ZERO_QUOTA_DISABLED_STORAGE_KEY = 'zerolimit.quota.zeroQuotaDisabled.v1';
const IMPORT_TIMES_STORAGE_KEY = 'zerolimit.quota.importTimes.v1';
const ZERO_QUOTA_ZEROED_AT_STORAGE_KEY = 'zerolimit.quota.zeroQuotaZeroedAt.v1';

const WEEKLY_QUOTA_DISABLED_STORAGE_KEY = 'zerolimit.quota.weeklyQuotaDisabled.v1';
const WEEKLY_QUOTA_ZEROED_AT_STORAGE_KEY = 'zerolimit.quota.weeklyQuotaZeroedAt.v1';
const WEEKLY_QUOTA_RESET_AT_STORAGE_KEY = 'zerolimit.quota.weeklyQuotaResetAt.v1';
const REFRESH_CONCURRENCY = 4;
const ENABLE_CONCURRENCY = 8;

type QuotaArchiveScope = 'monthly' | 'weekly';

const QUOTA_ARCHIVE_SCOPE_OPTIONS: Array<{ id: QuotaArchiveScope; label: string }> = [
  { id: 'monthly', label: '月额度' },
  { id: 'weekly', label: '周限额' },
];

interface StorageSnapshot {
  disabledOverrides: Record<string, boolean>;
  zeroQuotaKeys: Record<string, boolean>;
  weeklyQuotaKeys: Record<string, boolean>;
  importTimes: Record<string, string>;
  zeroedAtTimes: Record<string, string>;
  weeklyZeroedAtTimes: Record<string, string>;
  weeklyResetAtTimes: Record<string, string>;
}

interface ZeroQuotaAccount {
  key: string;
  scope: QuotaArchiveScope;
  accountKey: string;
  nodeId: string;
  nodeName: string;
  name: string;
  filename: string;
  email: string;
  provider: string;
  authIndex: string;
  disabled: boolean;
  zeroTracked: boolean;
  importedAt: number | null;
  zeroedAt: number | null;
  resetAt: number | null;
  importSource: string;
  originalFile: AuthFile;
}

interface ZeroQuotaGroup {
  id: string;
  dayLabel: string;
  importedAt: number | null;
  zeroedAt: number | null;
  refreshAt: number | null;
  ready: boolean;
  scope: QuotaArchiveScope;
  accounts: ZeroQuotaAccount[];
}

function loadStoredRecord(key: string): Record<string, string | boolean> {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed as Record<string, string | boolean> : {};
  } catch {
    return {};
  }
}

function saveStoredRecord(key: string, record: Record<string, string | boolean>) {
  window.localStorage.setItem(key, JSON.stringify(record));
}

function getScopedAccountKey(nodeId: string | undefined, accountKey: string): string {
  return `${nodeId || 'default'}::${accountKey}`;
}

function readScopedRecordValue(
  record: Record<string, string | boolean>,
  nodeId: string | undefined,
  accountKey: string,
  defaultNodeId: string | null,
): string | boolean | undefined {
  const scopedKey = getScopedAccountKey(nodeId, accountKey);
  if (record[scopedKey] !== undefined) return record[scopedKey];
  if (nodeId && defaultNodeId && nodeId === defaultNodeId && record[accountKey] !== undefined) return record[accountKey];
  return undefined;
}

function asBooleanRecord(record: Record<string, string | boolean>): Record<string, boolean> {
  return Object.fromEntries(
    Object.entries(record).filter((entry): entry is [string, boolean] => typeof entry[1] === 'boolean'),
  );
}

function asStringRecord(record: Record<string, string | boolean>): Record<string, string> {
  return Object.fromEntries(
    Object.entries(record).filter((entry): entry is [string, string] => typeof entry[1] === 'string'),
  );
}

function readStorageSnapshot(): StorageSnapshot {
  return {
    disabledOverrides: asBooleanRecord(loadStoredRecord(DISABLED_OVERRIDES_STORAGE_KEY)),
    zeroQuotaKeys: asBooleanRecord(loadStoredRecord(ZERO_QUOTA_DISABLED_STORAGE_KEY)),
    weeklyQuotaKeys: asBooleanRecord(loadStoredRecord(WEEKLY_QUOTA_DISABLED_STORAGE_KEY)),
    importTimes: asStringRecord(loadStoredRecord(IMPORT_TIMES_STORAGE_KEY)),
    zeroedAtTimes: asStringRecord(loadStoredRecord(ZERO_QUOTA_ZEROED_AT_STORAGE_KEY)),
    weeklyZeroedAtTimes: asStringRecord(loadStoredRecord(WEEKLY_QUOTA_ZEROED_AT_STORAGE_KEY)),
    weeklyResetAtTimes: asStringRecord(loadStoredRecord(WEEKLY_QUOTA_RESET_AT_STORAGE_KEY)),
  };
}

function saveStorageSnapshot(snapshot: StorageSnapshot) {
  saveStoredRecord(DISABLED_OVERRIDES_STORAGE_KEY, snapshot.disabledOverrides);
  saveStoredRecord(ZERO_QUOTA_DISABLED_STORAGE_KEY, snapshot.zeroQuotaKeys);
  saveStoredRecord(WEEKLY_QUOTA_DISABLED_STORAGE_KEY, snapshot.weeklyQuotaKeys);
  saveStoredRecord(IMPORT_TIMES_STORAGE_KEY, snapshot.importTimes);
  saveStoredRecord(ZERO_QUOTA_ZEROED_AT_STORAGE_KEY, snapshot.zeroedAtTimes);
  saveStoredRecord(WEEKLY_QUOTA_ZEROED_AT_STORAGE_KEY, snapshot.weeklyZeroedAtTimes);
  saveStoredRecord(WEEKLY_QUOTA_RESET_AT_STORAGE_KEY, snapshot.weeklyResetAtTimes);
}

function extractAuthFiles(body: unknown): AuthFile[] {
  if (Array.isArray(body)) return body as AuthFile[];
  if (!body || typeof body !== 'object') return [];

  const record = body as Record<string, unknown>;
  for (const key of ['files', 'items', 'data', 'auth_files', 'authFiles']) {
    const value = record[key];
    if (Array.isArray(value)) return value as AuthFile[];
    if (value && typeof value === 'object') {
      const nested = value as Record<string, unknown>;
      for (const nestedKey of ['files', 'items', 'data']) {
        if (Array.isArray(nested[nestedKey])) return nested[nestedKey] as AuthFile[];
      }
    }
  }

  return [];
}

function normalizeTimestamp(value: unknown): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value < 10000000000 ? value * 1000 : value;
  }

  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return null;

    const numeric = Number(trimmed);
    if (Number.isFinite(numeric)) {
      return numeric < 10000000000 ? numeric * 1000 : numeric;
    }

    const parsed = Date.parse(trimmed);
    return Number.isFinite(parsed) ? parsed : null;
  }

  return null;
}

function getNestedValue(file: AuthFile, key: string): unknown {
  const direct = file[key];
  if (direct !== undefined && direct !== null) return direct;

  for (const parentKey of ['metadata', 'attributes', 'meta']) {
    const parent = file[parentKey];
    if (parent && typeof parent === 'object' && !Array.isArray(parent)) {
      const value = (parent as Record<string, unknown>)[key];
      if (value !== undefined && value !== null) return value;
    }
  }

  return undefined;
}

function resolveImportTimestamp(file: AuthFile, storedImportTime: string | undefined): { timestamp: number | null; source: string } {
  const stored = normalizeTimestamp(storedImportTime);
  if (stored !== null) return { timestamp: stored, source: '首次导入记录' };

  const primaryKeys = [
    'importedAt',
    'imported_at',
    'importTime',
    'import_time',
    'uploadedAt',
    'uploaded_at',
    'createdAt',
    'created_at',
    'created',
    'ctime',
  ];

  for (const key of primaryKeys) {
    const timestamp = normalizeTimestamp(getNestedValue(file, key));
    if (timestamp !== null) return { timestamp, source: 'CPA后台' };
  }

  for (const key of ['mtime', 'modifiedAt', 'modified_at', 'updatedAt', 'updated_at']) {
    const timestamp = normalizeTimestamp(getNestedValue(file, key));
    if (timestamp !== null) return { timestamp, source: '文件修改时间' };
  }

  return { timestamp: null, source: '未识别' };
}

function getAuthFileName(file: AuthFile, fallback = ''): string {
  return String(file.name || file.filename || file.id || fallback);
}

function getAuthFileStorageName(file: AuthFile, fallback = ''): string {
  const name = getAuthFileName(file, fallback);
  if (!name) return '';
  return name.toLowerCase().endsWith('.json') ? name : `${name}.json`;
}

function getAuthIndex(file: AuthFile, fallback = ''): string {
  return String(file.auth_index || file.authIndex || file.id || file.filename || file.name || fallback);
}

function getAuthFileKey(file: AuthFile, fallback = ''): string {
  return String(file.auth_index || file.authIndex || file.id || file.filename || file.name || fallback);
}

function getAccountEmail(file: AuthFile, fallback = ''): string {
  const value = file.account || file.email || file.label || file.name || file.filename || fallback;
  return String(value || fallback).replace(/\.json$/i, '');
}

function isAuthFileDisabled(file: AuthFile, disabledOverrides: Record<string, boolean>, key: string): boolean {
  if (typeof disabledOverrides[key] === 'boolean') return disabledOverrides[key];

  const value = file.disabled ?? file.is_disabled ?? file.isDisabled;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value === 1;
  if (typeof value === 'string') {
    return ['true', '1', 'yes', 'on'].includes(value.trim().toLowerCase());
  }
  return false;
}

function resolveAuthFileDisabled(
  file: AuthFile,
  snapshot: StorageSnapshot,
  nodeId: string,
  accountKey: string,
  defaultNodeId: string | null,
): boolean {
  const stored = readScopedRecordValue(snapshot.disabledOverrides, nodeId, accountKey, defaultNodeId);
  if (typeof stored === 'boolean') return stored;
  return isAuthFileDisabled(file, {}, accountKey);
}

function isCodexAuthFile(file: AuthFile): boolean {
  const provider = String(file.provider || file.type || '').toLowerCase();
  const name = getAuthFileName(file).toLowerCase();
  const account = String(file.account || file.email || '').toLowerCase();

  return (
    provider.includes('codex') ||
    name.includes('codex') ||
    account.endsWith('@outlook.com') ||
    account.endsWith('@hotmail.com') ||
    account.endsWith('@live.com') ||
    name.endsWith('@outlook.com.json') ||
    name.endsWith('@hotmail.com.json') ||
    name.endsWith('@live.com.json') ||
    String(file.type || '').toLowerCase() === 'codex'
  );
}

function formatDay(timestamp: number | null): string {
  if (timestamp === null) return '未知日期';
  return new Date(timestamp)
    .toLocaleDateString('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit' })
    .replace(/\//g, '-');
}

function formatDateTime(timestamp: number | null): string {
  if (timestamp === null) return '-';
  return new Date(timestamp)
    .toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    })
    .replace(/\//g, '-');
}

function addOneMonth(timestamp: number | null): number | null {
  if (timestamp === null) return null;

  const source = new Date(timestamp);
  const day = source.getDate();
  const result = new Date(source);
  result.setDate(1);
  result.setMonth(result.getMonth() + 1);
  const lastDay = new Date(result.getFullYear(), result.getMonth() + 1, 0).getDate();
  result.setDate(Math.min(day, lastDay));
  return result.getTime();
}
function addDays(timestamp: number | null, days: number): number | null {
  if (timestamp === null) return null;
  return timestamp + days * 24 * 60 * 60 * 1000;
}

function getQuotaWindowKind(item: QuotaModel): QuotaArchiveScope | 'hour' | 'other' {
  const name = item.name.toLowerCase();
  if (name.includes('monthly') || name.includes('month') || name.includes('月')) return 'monthly';
  if (name.includes('weekly') || name.includes('week') || name.includes('周')) return 'weekly';
  if (name.includes('hour') || name.includes('5h') || name.includes('5小时') || name.includes('小时')) return 'hour';
  return 'other';
}

function getQuotaItemsForScope(items: QuotaModel[], scope: QuotaArchiveScope): QuotaModel[] {
  return items.filter(item => Number.isFinite(item.percentage) && getQuotaWindowKind(item) === scope);
}

function getZeroQuotaDetection(items: QuotaModel[], scope: QuotaArchiveScope): { zero: boolean; resetAt: number | null } {
  const numericItems = items.filter(item => Number.isFinite(item.percentage));
  const scopedItems = getQuotaItemsForScope(numericItems, scope);
  const targetItems = scopedItems.length > 0
    ? scopedItems
    : scope === 'monthly'
      ? numericItems
      : [];

  if (targetItems.length === 0) return { zero: false, resetAt: null };

  const resetAtValues = targetItems
    .map(item => normalizeTimestamp(item.resetAt))
    .filter((value): value is number => value !== null);

  return {
    zero: targetItems.every(item => clampPercentage(item.percentage) <= 0),
    resetAt: resetAtValues.length ? Math.max(...resetAtValues) : null,
  };
}

function getScopeLabel(scope: QuotaArchiveScope): string {
  return scope === 'weekly' ? '周限额' : '月额度';
}

function getScopeHint(scope: QuotaArchiveScope): string {
  return scope === 'weekly'
    ? '按周限额归0时间分组；刷新时间优先使用CPA返回的周限额刷新时间，缺失时按归0后7天估算。'
    : '按首次导入日期分组，月额度归0后停用；到下个月同日再一键启用。';
}

function resolveRefreshTimestamp(
  scope: QuotaArchiveScope,
  importedAt: number | null,
  zeroedAt: number | null,
  resetAt: number | null,
): number | null {
  if (scope === 'weekly') return resetAt ?? addDays(zeroedAt, 7);
  return addOneMonth(importedAt);
}

function formatCountdown(refreshAt: number | null, now: number): string {
  if (refreshAt === null) return '等待识别导入时间';
  const diff = refreshAt - now;
  if (diff <= 0) return '已到刷新日';

  const minutes = Math.max(1, Math.floor(diff / 60000));
  const days = Math.floor(minutes / 1440);
  const hours = Math.floor((minutes % 1440) / 60);
  const mins = minutes % 60;

  if (days > 0) return `${days}天${hours}小时`;
  if (hours > 0) return `${hours}小时${mins}分钟`;
  return `${mins}分钟`;
}

function normalizeDownloadedAuth(data: unknown): AuthFile | null {
  if (!data) return null;
  if (typeof data === 'string') {
    try {
      return JSON.parse(data) as AuthFile;
    } catch {
      return null;
    }
  }
  if (typeof data === 'object' && !Array.isArray(data)) return data as AuthFile;
  return null;
}

function createAuthUploadForm(content: string, filename: string): FormData {
  const blob = new Blob([content], { type: 'application/json' });
  const formData = new FormData();
  formData.append('file', blob, filename);
  return formData;
}

function clampPercentage(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, Math.round(value)));
}


async function runWithConcurrency<T>(
  items: T[],
  limit: number,
  worker: (item: T) => Promise<void>,
) {
  let nextIndex = 0;
  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (nextIndex < items.length) {
      const item = items[nextIndex++];
      await worker(item);
    }
  });
  await Promise.all(runners);
}

function buildAccounts(
  files: AuthFile[],
  snapshot: StorageSnapshot,
  nodeId: string,
  nodeName: string,
  defaultNodeId: string | null,
  scope: QuotaArchiveScope,
): { accounts: ZeroQuotaAccount[]; importTimes: Record<string, string> } {
  const nextImportTimes = { ...snapshot.importTimes };
  const quotaKeys = scope === 'weekly' ? snapshot.weeklyQuotaKeys : snapshot.zeroQuotaKeys;
  const zeroedAtTimes = scope === 'weekly' ? snapshot.weeklyZeroedAtTimes : snapshot.zeroedAtTimes;

  const accounts = files.map((file, index): ZeroQuotaAccount => {
    const name = getAuthFileName(file, String(index));
    const filename = getAuthFileStorageName(file, name);
    const accountKey = getAuthFileKey(file, filename || String(index));
    const key = getScopedAccountKey(nodeId, accountKey);
    const storedImportTime = readScopedRecordValue(snapshot.importTimes, nodeId, accountKey, defaultNodeId);
    const { timestamp, source } = resolveImportTimestamp(file, typeof storedImportTime === 'string' ? storedImportTime : undefined);
    const disabled = resolveAuthFileDisabled(file, snapshot, nodeId, accountKey, defaultNodeId);
    const monthlyTracked = readScopedRecordValue(snapshot.zeroQuotaKeys, nodeId, accountKey, defaultNodeId) === true;
    const scopedTracked = readScopedRecordValue(quotaKeys, nodeId, accountKey, defaultNodeId) === true;
    const zeroTracked = scope === 'weekly' ? scopedTracked && !monthlyTracked : scopedTracked;
    const zeroedAtValue = readScopedRecordValue(zeroedAtTimes, nodeId, accountKey, defaultNodeId);
    const resetAtValue = scope === 'weekly'
      ? readScopedRecordValue(snapshot.weeklyResetAtTimes, nodeId, accountKey, defaultNodeId)
      : undefined;

    if (timestamp !== null && !nextImportTimes[key]) {
      nextImportTimes[key] = new Date(timestamp).toISOString();
    }

    return {
      key,
      scope,
      accountKey,
      nodeId,
      nodeName,
      name,
      filename,
      email: getAccountEmail(file, filename || name),
      provider: String(file.provider || file.type || 'codex'),
      authIndex: getAuthIndex(file, filename),
      disabled,
      zeroTracked,
      importedAt: timestamp,
      zeroedAt: typeof zeroedAtValue === 'string' ? normalizeTimestamp(zeroedAtValue) : null,
      resetAt: typeof resetAtValue === 'string' ? normalizeTimestamp(resetAtValue) : null,
      importSource: source,
      originalFile: { ...file, __nodeId: nodeId, __nodeName: nodeName },
    };
  });

  return { accounts, importTimes: nextImportTimes };
}

export function ZeroQuotaPage() {
  const { t } = useTranslation();
  const { isAuthenticated } = useAuthStore();
  const { nodes, defaultNodeId, selectedNodeId, setSelectedNode } = useCpaNodesStore();
  const [accounts, setAccounts] = useState<ZeroQuotaAccount[]>([]);
  const [quotaScope, setQuotaScope] = useState<QuotaArchiveScope>('monthly');
  const [storage, setStorage] = useState<StorageSnapshot>(() => readStorageSnapshot());
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [enablingGroupId, setEnablingGroupId] = useState<string | null>(null);
  const [refreshProgress, setRefreshProgress] = useState({ done: 0, total: 0 });
  const [search, setSearch] = useState('');
  const [showEmails, setShowEmails] = useState(false);
  const [now, setNow] = useState(() => Date.now());

  const activeNode = useMemo(() => {
    return nodes.find(node => node.id === selectedNodeId) ||
      nodes.find(node => node.id === defaultNodeId) ||
      nodes.find(node => node.enabled) ||
      nodes[0] ||
      null;
  }, [defaultNodeId, nodes, selectedNodeId]);
  const activeNodeId = activeNode?.id || '';
  const activeNodeName = activeNode?.name || '未选择节点';
  const nodeConfig = useMemo<CpaNodeConnectionConfig | null>(() => (
    activeNode ? { apiBase: activeNode.apiBase, managementKey: activeNode.managementKey } : null
  ), [activeNode]);
  const nodeOptions = useMemo(() => nodes.map(node => ({
    id: node.id,
    name: node.name,
    enabled: node.enabled,
    tags: node.tags,
  })), [nodes]);
  const canWriteSelectedNode = Boolean(activeNode && activeNode.enabled && nodeConfig);
  const scopeLabel = getScopeLabel(quotaScope);
  const scopeHint = getScopeHint(quotaScope);

  useEffect(() => {
    if (!nodes.length) return;
    if (selectedNodeId && nodes.some(node => node.id === selectedNodeId)) return;
    setSelectedNode(defaultNodeId || nodes[0].id);
  }, [defaultNodeId, nodes, selectedNodeId, setSelectedNode]);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 30000);
    return () => window.clearInterval(timer);
  }, []);

  const loadAccounts = useCallback(async () => {
    if (!isAuthenticated) return;

    if (!activeNode || !nodeConfig || !activeNode.enabled) {
      setAccounts([]);
      return;
    }

    setLoading(true);
    try {
      const snapshot = readStorageSnapshot();
      const resp = await authFilesApi.list(nodeConfig);
      const { accounts: nextAccounts, importTimes } = buildAccounts(extractAuthFiles(resp), snapshot, activeNode.id, activeNode.name, defaultNodeId, quotaScope);
      const nextSnapshot = { ...snapshot, importTimes };

      saveStorageSnapshot(nextSnapshot);
      setStorage(nextSnapshot);
      setAccounts(nextAccounts);
    } catch (error) {
      toast.error(`加载0额度时间表失败：${(error as Error).message}`);
    } finally {
      setLoading(false);
    }
  }, [activeNode, defaultNodeId, isAuthenticated, nodeConfig, quotaScope]);

  useEffect(() => {
    void loadAccounts();
  }, [loadAccounts]);

  const updateAuthFileDisabled = useCallback(async (account: ZeroQuotaAccount, disabled: boolean) => {
    const accountNode = nodes.find(node => node.id === account.nodeId) || activeNode;
    if (!accountNode || !accountNode.enabled) throw new Error('No enabled CPA node selected');
    const accountNodeConfig: CpaNodeConnectionConfig = { apiBase: accountNode.apiBase, managementKey: accountNode.managementKey };
    const downloaded = await authFilesApi.download(account.filename, accountNodeConfig);
    const content = normalizeDownloadedAuth(downloaded) || account.originalFile;

    if (!content || typeof content !== 'object' || Array.isArray(content)) {
      throw new Error('授权文件内容不是有效 JSON');
    }

    const updated = {
      ...(content as Record<string, unknown>),
      disabled,
    };

    const serialized = JSON.stringify(updated, null, 2);
    await authFilesApi.upload(createAuthUploadForm(serialized, account.filename), accountNodeConfig);

    const verifyData = await authFilesApi.download(account.filename, accountNodeConfig);
    const verifyContent = normalizeDownloadedAuth(verifyData);
    if (verifyContent && isAuthFileDisabled(verifyContent, {}, account.key) === disabled) return;

    await authFilesApi.deleteFile(account.filename, accountNodeConfig);
    await authFilesApi.upload(createAuthUploadForm(serialized, account.filename), accountNodeConfig);
  }, [activeNode, nodes]);

  const groups = useMemo(() => {
    const term = search.trim().toLowerCase();
    const zeroAccounts = accounts.filter(account => {
      if (!account.zeroTracked || !account.disabled) return false;
      if (!term) return true;
      const scopeDay = quotaScope === 'weekly'
        ? formatDay(resolveRefreshTimestamp(quotaScope, account.importedAt, account.zeroedAt, account.resetAt))
        : formatDay(account.importedAt);
      return (
        account.email.toLowerCase().includes(term) ||
        account.filename.toLowerCase().includes(term) ||
        formatDay(account.importedAt).toLowerCase().includes(term) ||
        formatDay(account.zeroedAt).toLowerCase().includes(term) ||
        formatDay(account.resetAt).toLowerCase().includes(term) ||
        scopeDay.toLowerCase().includes(term)
      );
    });

    const byDay = new Map<string, ZeroQuotaAccount[]>();
    zeroAccounts.forEach(account => {
      const groupTimestamp = quotaScope === 'weekly'
        ? resolveRefreshTimestamp(quotaScope, account.importedAt, account.zeroedAt, account.resetAt)
        : account.importedAt;
      const day = formatDay(groupTimestamp);
      byDay.set(day, [...(byDay.get(day) || []), account]);
    });

    return Array.from(byDay.entries())
      .map(([dayLabel, groupAccounts]): ZeroQuotaGroup => {
        const importedTimestamps = groupAccounts
          .map(account => account.importedAt)
          .filter((value): value is number => value !== null);
        const zeroedTimestamps = groupAccounts
          .map(account => account.zeroedAt)
          .filter((value): value is number => value !== null);
        const resetTimestamps = groupAccounts
          .map(account => account.resetAt)
          .filter((value): value is number => value !== null);
        const importedAt = importedTimestamps.length ? Math.min(...importedTimestamps) : null;
        const zeroedAt = zeroedTimestamps.length ? Math.max(...zeroedTimestamps) : null;
        const resetAt = resetTimestamps.length ? Math.max(...resetTimestamps) : null;
        const refreshAt = resolveRefreshTimestamp(quotaScope, importedAt, zeroedAt, resetAt);
        return {
          id: getScopedAccountKey(activeNodeId, `${quotaScope}::${dayLabel}`),
          dayLabel,
          importedAt,
          zeroedAt,
          refreshAt,
          ready: refreshAt !== null && refreshAt <= now,
          scope: quotaScope,
          accounts: groupAccounts.sort((a, b) => a.email.localeCompare(b.email)),
        };
      })
      .sort((a, b) => {
        if (a.ready !== b.ready) return a.ready ? -1 : 1;
        if (a.refreshAt !== null || b.refreshAt !== null) {
          return (a.refreshAt ?? Number.MAX_SAFE_INTEGER) - (b.refreshAt ?? Number.MAX_SAFE_INTEGER);
        }
        return a.dayLabel.localeCompare(b.dayLabel);
      });
  }, [accounts, activeNodeId, now, quotaScope, search]);

  const readyGroups = useMemo(() => groups.filter(group => group.ready), [groups]);
  const waitingGroups = useMemo(() => groups.filter(group => !group.ready), [groups]);
  const nextWaitingGroup = waitingGroups[0] || null;

  const stats = useMemo(() => {
    const zeroAccounts = accounts.filter(account => account.zeroTracked && account.disabled);
    const readyCount = readyGroups.reduce((sum, group) => sum + group.accounts.length, 0);
    return {
      total: accounts.length,
      zeroDisabled: zeroAccounts.length,
      groups: groups.length,
      ready: readyCount,
      enabled: accounts.filter(account => !account.disabled).length,
    };
  }, [accounts, groups, readyGroups]);

  const enableAccounts = useCallback(async (targetAccounts: ZeroQuotaAccount[], label: string) => {
    if (targetAccounts.length === 0) return;

    setEnablingGroupId(label);
    let successCount = 0;
    let failureCount = 0;
    const successfulKeys = new Set<string>();

    try {
      await runWithConcurrency(targetAccounts, ENABLE_CONCURRENCY, async (account) => {
        try {
          await updateAuthFileDisabled(account, false);
          successCount++;
          successfulKeys.add(account.key);
        } catch (error) {
          failureCount++;
          console.error('Failed to enable zero quota account:', account.filename, error);
        }
      });

      if (successCount > 0) {
        const nextStorage: StorageSnapshot = {
          disabledOverrides: { ...storage.disabledOverrides },
          zeroQuotaKeys: { ...storage.zeroQuotaKeys },
          weeklyQuotaKeys: { ...storage.weeklyQuotaKeys },
          importTimes: { ...storage.importTimes },
          zeroedAtTimes: { ...storage.zeroedAtTimes },
          weeklyZeroedAtTimes: { ...storage.weeklyZeroedAtTimes },
          weeklyResetAtTimes: { ...storage.weeklyResetAtTimes },
        };
        targetAccounts
          .filter(account => successfulKeys.has(account.key))
          .forEach(account => {
            nextStorage.disabledOverrides[account.key] = false;

            if (account.scope === 'weekly') {
              nextStorage.weeklyQuotaKeys[account.key] = false;
              delete nextStorage.weeklyZeroedAtTimes[account.key];
              delete nextStorage.weeklyResetAtTimes[account.key];
            } else {
              nextStorage.zeroQuotaKeys[account.key] = false;
              delete nextStorage.zeroedAtTimes[account.key];
            }

            if (account.nodeId === defaultNodeId) {
              nextStorage.disabledOverrides[account.accountKey] = false;
              if (account.scope === 'weekly') {
                nextStorage.weeklyQuotaKeys[account.accountKey] = false;
                delete nextStorage.weeklyZeroedAtTimes[account.accountKey];
                delete nextStorage.weeklyResetAtTimes[account.accountKey];
              } else {
                nextStorage.zeroQuotaKeys[account.accountKey] = false;
                delete nextStorage.zeroedAtTimes[account.accountKey];
              }
            }
          });

        saveStorageSnapshot(nextStorage);
        setStorage(nextStorage);
        setAccounts(prev => prev.map(account => (
          successfulKeys.has(account.key)
            ? { ...account, disabled: false, zeroTracked: false, zeroedAt: null, resetAt: null }
            : account
        )));
      }

      if (successCount > 0 && failureCount === 0) {
        toast.success(`已启用 ${successCount} 个账号`);
      } else if (successCount > 0) {
        toast.info(`已启用 ${successCount} 个账号，${failureCount} 个失败`);
        await loadAccounts();
      } else {
        toast.error('启用失败，请检查CPA后台连接');
        await loadAccounts();
      }
    } finally {
      setEnablingGroupId(null);
    }
  }, [defaultNodeId, loadAccounts, storage, updateAuthFileDisabled]);

  const enableReadyGroups = useCallback(async () => {
    const targets = groups.filter(group => group.ready).flatMap(group => group.accounts);
    if (targets.length === 0) {
      toast.info(`还没有到刷新日的${scopeLabel}0额度账号`);
      return;
    }
    await enableAccounts(targets, 'ready');
  }, [enableAccounts, groups, scopeLabel]);

  const refreshAndArchiveZeroQuota = useCallback(async () => {
    if (!isAuthenticated) return;
    if (!activeNode || !nodeConfig || !activeNode.enabled) {
      toast.error('请选择已启用的 CPA 节点');
      return;
    }

    setRefreshing(true);
    setRefreshProgress({ done: 0, total: 0 });

    try {
      const snapshot = readStorageSnapshot();
      const resp = await authFilesApi.list(nodeConfig);
      const { accounts: freshAccounts, importTimes } = buildAccounts(extractAuthFiles(resp), snapshot, activeNode.id, activeNode.name, defaultNodeId, quotaScope);
      const targets = freshAccounts.filter(account => (
        !account.disabled &&
        account.authIndex &&
        isCodexAuthFile(account.originalFile)
      ));

      if (targets.length === 0) {
        const nextSnapshot = { ...snapshot, importTimes };
        saveStorageSnapshot(nextSnapshot);
        setStorage(nextSnapshot);
        setAccounts(freshAccounts);
        toast.info(`没有启用中的${scopeLabel}账号需要刷新`);
        return;
      }

      setAccounts(freshAccounts);
      setRefreshProgress({ done: 0, total: targets.length });

      const zeroDetections = new Map<string, { resetAt: number | null }>();
      let errorCount = 0;
      const zeroedIso = new Date().toISOString();
      const zeroedAt = normalizeTimestamp(zeroedIso);

      await runWithConcurrency(targets, REFRESH_CONCURRENCY, async (account) => {
        try {
          const downloaded = await authFilesApi.download(account.filename, nodeConfig);
          const fullAuthFile = normalizeDownloadedAuth(downloaded) || account.originalFile;
          const accountId = resolveCodexChatgptAccountId(fullAuthFile) || resolveCodexChatgptAccountId(account.originalFile);
          const result = await quotaApi.fetchCodex(account.authIndex, accountId || undefined, nodeConfig);

          if (result.error) {
            errorCount++;
            return;
          }

          const detection = getZeroQuotaDetection(result.limits, quotaScope);
          if (detection.zero) {
            await updateAuthFileDisabled(account, true);
            zeroDetections.set(account.key, { resetAt: detection.resetAt });
          }
        } catch (error) {
          errorCount++;
          console.error('Failed to refresh zero quota account:', account.filename, error);
        } finally {
          setRefreshProgress(prev => ({ ...prev, done: prev.done + 1 }));
        }
      });

      const nextStorage: StorageSnapshot = {
        disabledOverrides: { ...snapshot.disabledOverrides },
        zeroQuotaKeys: { ...snapshot.zeroQuotaKeys },
        weeklyQuotaKeys: { ...snapshot.weeklyQuotaKeys },
        importTimes,
        zeroedAtTimes: { ...snapshot.zeroedAtTimes },
        weeklyZeroedAtTimes: { ...snapshot.weeklyZeroedAtTimes },
        weeklyResetAtTimes: { ...snapshot.weeklyResetAtTimes },
      };

      freshAccounts.forEach(account => {
        const detection = zeroDetections.get(account.key);
        if (!detection) return;

        const keys = account.nodeId === defaultNodeId
          ? [account.key, account.accountKey]
          : [account.key];

        keys.forEach(key => {
          nextStorage.disabledOverrides[key] = true;
          if (account.importedAt !== null && !nextStorage.importTimes[key]) {
            nextStorage.importTimes[key] = new Date(account.importedAt).toISOString();
          }

          if (quotaScope === 'weekly') {
            nextStorage.weeklyQuotaKeys[key] = true;
            if (!nextStorage.weeklyZeroedAtTimes[key]) {
              nextStorage.weeklyZeroedAtTimes[key] = zeroedIso;
            }
            if (detection.resetAt !== null) {
              nextStorage.weeklyResetAtTimes[key] = new Date(detection.resetAt).toISOString();
            }
            return;
          }

          nextStorage.zeroQuotaKeys[key] = true;
          if (!nextStorage.zeroedAtTimes[key]) {
            nextStorage.zeroedAtTimes[key] = zeroedIso;
          }
        });
      });

      saveStorageSnapshot(nextStorage);
      setStorage(nextStorage);
      setAccounts(freshAccounts.map(account => {
        const detection = zeroDetections.get(account.key);
        return detection
          ? { ...account, disabled: true, zeroTracked: true, zeroedAt, resetAt: detection.resetAt ?? account.resetAt }
          : account;
      }));

      if (zeroDetections.size > 0) {
        toast.success(`总刷新完成，已归入并停用 ${zeroDetections.size} 个${scopeLabel}0额度账号${errorCount ? `，${errorCount} 个刷新失败` : ''}`);
      } else {
        toast.info(`总刷新完成，没有新增${scopeLabel}0额度账号${errorCount ? `，${errorCount} 个刷新失败` : ''}`);
      }
    } finally {
      setRefreshing(false);
      setRefreshProgress({ done: 0, total: 0 });
    }
  }, [activeNode, defaultNodeId, isAuthenticated, nodeConfig, quotaScope, scopeLabel, updateAuthFileDisabled]);

  const renderGroupCard = (group: ZeroQuotaGroup) => {
    const previewAccounts = group.accounts.slice(0, 10);
    const hiddenCount = Math.max(0, group.accounts.length - previewAccounts.length);

    return (
      <Card key={group.id} className={group.ready ? 'border-emerald-500/50 bg-emerald-500/5' : 'border'}>
        <CardContent className="p-4">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                {group.ready ? (
                  <Badge className="bg-emerald-600 text-white">
                    <CheckCircle2 className="mr-1 h-3 w-3" />
                    可启用
                  </Badge>
                ) : (
                  <Badge variant="outline" className="border-orange-500/40 bg-orange-500/10 text-orange-700">
                    <Clock3 className="mr-1 h-3 w-3" />
                    等待中
                  </Badge>
                )}
                <span className="text-lg font-semibold">{group.dayLabel}</span>
                <span className="rounded-md bg-muted px-2 py-1 text-xs text-muted-foreground">
                  {group.scope === 'weekly' ? '周刷新日' : group.accounts[0]?.importSource || '未识别'}
                </span>
              </div>

              <div className="mt-3 grid gap-2 text-sm sm:grid-cols-2 xl:grid-cols-4">
                <div>
                  <div className="text-xs text-muted-foreground">{scopeLabel}0额度账号</div>
                  <div className="mt-1 flex items-center gap-1.5 font-semibold">
                    <Database className="h-4 w-4 text-muted-foreground" />
                    {group.accounts.length} 个
                  </div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">归0时间</div>
                  <div className="mt-1 font-medium">{formatDateTime(group.zeroedAt)}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">预计刷新</div>
                  <div className="mt-1 font-medium">{formatDateTime(group.refreshAt)}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">剩余时间</div>
                  <div className={group.ready ? 'mt-1 font-semibold text-emerald-700' : 'mt-1 font-medium text-orange-700'}>
                    {formatCountdown(group.refreshAt, now)}
                  </div>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-1.5">
                {previewAccounts.map(account => (
                  <span key={account.key} className="max-w-full rounded-md bg-background px-2 py-1 text-xs shadow-xs ring-1 ring-border">
                    {showEmails ? account.email : maskEmail(account.email)}
                  </span>
                ))}
                {hiddenCount > 0 && (
                  <span className="rounded-md bg-muted px-2 py-1 text-xs text-muted-foreground">
                    还有 {hiddenCount} 个
                  </span>
                )}
              </div>
            </div>

            <Button
              className="w-full lg:w-auto"
              variant={group.ready ? 'default' : 'outline'}
              onClick={() => void enableAccounts(group.accounts, group.id)}
              disabled={!canWriteSelectedNode || loading || refreshing || Boolean(enablingGroupId)}
              title={group.ready ? '启用这一批账号' : '未到刷新日，确认需要也可以手动启用'}
            >
              {enablingGroupId === group.id ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Power className="mr-2 h-4 w-4" />
              )}
              启用这一批
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (!isAuthenticated) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="space-y-6"
      >
        <div>
          <h1 className="text-3xl font-bold">0额度时间表</h1>
        </div>
        <Card className="border">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <AlertCircle className="mb-4 h-12 w-12 text-muted-foreground" />
            <p className="text-muted-foreground">{t('quota.connectPrompt')}</p>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6"
    >
      <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">0额度时间表</h1>
          <p className="mt-1 text-sm text-muted-foreground">{scopeHint}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-md border bg-muted/30 p-1">
            {QUOTA_ARCHIVE_SCOPE_OPTIONS.map(option => (
              <Button
                key={option.id}
                type="button"
                size="sm"
                variant={quotaScope === option.id ? 'default' : 'ghost'}
                className="h-7 px-3"
                onClick={() => setQuotaScope(option.id)}
              >
                {option.label}
              </Button>
            ))}
          </div>
          <div className="flex min-w-[260px] items-center gap-2 rounded-md border bg-background px-2 py-1.5">
            <Network className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">CPA节点</span>
            <Select value={activeNodeId || ''} onValueChange={setSelectedNode} disabled={nodeOptions.length === 0}>
              <SelectTrigger className="h-8 min-w-[170px] border-0 px-2 shadow-none focus:ring-0">
                <SelectValue placeholder="选择节点" />
              </SelectTrigger>
              <SelectContent>
                {nodeOptions.map(node => (
                  <SelectItem key={node.id} value={node.id}>
                    {node.name}{node.enabled ? '' : '（停用）'}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <span className="hidden truncate text-xs text-muted-foreground sm:inline" title={activeNodeName}>{activeNodeName}</span>
            <span className={canWriteSelectedNode ? 'text-xs text-emerald-600' : 'text-xs text-destructive'}>
              {canWriteSelectedNode ? '可用' : '不可用'}
            </span>
          </div>
          <Button variant="outline" onClick={() => setShowEmails(value => !value)}>
            {showEmails ? <EyeOff className="mr-2 h-4 w-4" /> : <Eye className="mr-2 h-4 w-4" />}
            {showEmails ? '隐藏账号' : '显示账号'}
          </Button>
          <Button variant="outline" onClick={() => void loadAccounts()} disabled={!canWriteSelectedNode || loading || refreshing || Boolean(enablingGroupId)}>
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            刷新列表
          </Button>
          <Button variant="outline" onClick={() => void refreshAndArchiveZeroQuota()} disabled={!canWriteSelectedNode || loading || refreshing || Boolean(enablingGroupId)}>
            {refreshing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            {refreshing ? `总刷新中 ${refreshProgress.done}/${refreshProgress.total}` : `总刷新并归入${scopeLabel}0额度`}
          </Button>
          <Button onClick={() => void enableReadyGroups()} disabled={!canWriteSelectedNode || loading || refreshing || Boolean(enablingGroupId) || stats.ready === 0}>
            {enablingGroupId === 'ready' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Power className="mr-2 h-4 w-4" />}
            启用到期账号（{stats.ready}）
          </Button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Card className={stats.ready > 0 ? 'border-emerald-500/50 bg-emerald-500/5' : 'border'}>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-emerald-600">{stats.ready}</div>
            <div className="text-sm text-muted-foreground">到期可启用</div>
          </CardContent>
        </Card>
        <Card className="border">
          <CardContent className="p-4">
            <div className="text-xl font-bold">{nextWaitingGroup ? formatCountdown(nextWaitingGroup.refreshAt, now) : '--'}</div>
            <div className="text-sm text-muted-foreground">下一批刷新</div>
          </CardContent>
        </Card>
        <Card className="border">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-orange-600">{stats.zeroDisabled}</div>
            <div className="text-sm text-muted-foreground">已停用{scopeLabel}0额度</div>
          </CardContent>
        </Card>
        <Card className="border">
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{stats.groups}</div>
            <div className="text-sm text-muted-foreground">日期分组</div>
          </CardContent>
        </Card>
        <Card className="border">
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{stats.enabled}</div>
            <div className="text-sm text-muted-foreground">当前启用中</div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col gap-3 rounded-lg border bg-card/80 p-3 shadow-sm lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <CalendarClock className="h-4 w-4" />
          <span>{scopeHint}</span>
        </div>
        <div className="relative w-full lg:w-[320px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="搜索日期、账号或文件名"
            className="pl-9"
          />
        </div>
      </div>

      {refreshing && (
        <div className="rounded-lg border bg-card/80 p-4 shadow-sm">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium">总刷新并归入{scopeLabel}0额度</span>
            <span className="text-muted-foreground">{refreshProgress.done}/{refreshProgress.total}</span>
          </div>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-primary transition-all"
              style={{ width: `${refreshProgress.total ? Math.round(refreshProgress.done / refreshProgress.total * 100) : 0}%` }}
            />
          </div>
        </div>
      )}

      <div className="grid gap-5 xl:grid-cols-2">
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">可启用</h2>
              <p className="text-sm text-muted-foreground">已经到刷新日的{scopeLabel}0额度账号，优先处理这里。</p>
            </div>
            <Badge className="bg-emerald-600 text-white">{readyGroups.length} 组</Badge>
          </div>
          {readyGroups.length > 0 ? (
            readyGroups.map(renderGroupCard)
          ) : (
            <Card className="border border-dashed">
              <CardContent className="flex items-center gap-3 p-4 text-sm text-muted-foreground">
                <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                当前没有到期的{scopeLabel}0额度账号。
              </CardContent>
            </Card>
          )}
        </section>

        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">等待中</h2>
              <p className="text-sm text-muted-foreground">还没到刷新日的{scopeLabel}账号，按最近到期排序。</p>
            </div>
            <Badge variant="outline">{waitingGroups.length} 组</Badge>
          </div>
          {waitingGroups.length > 0 ? (
            waitingGroups.map(renderGroupCard)
          ) : (
            <Card className="border border-dashed">
              <CardContent className="flex items-center gap-3 p-4 text-sm text-muted-foreground">
                <Clock3 className="h-5 w-5 text-orange-600" />
                当前没有等待中的{scopeLabel}0额度账号。
              </CardContent>
            </Card>
          )}
        </section>
      </div>

      {!loading && groups.length === 0 && (
        <Card className="border">
          <CardContent className="py-12 text-center text-muted-foreground">
            <CalendarClock className="mx-auto mb-3 h-8 w-8" />
            暂时没有已停用的{scopeLabel}0额度账号。点“总刷新并归入{scopeLabel}0额度”后，会自动归到对应日期。
          </CardContent>
        </Card>
      )}

      {loading && (
        <Card className="border">
          <CardContent className="py-12 text-center text-muted-foreground">
            <Loader2 className="mx-auto mb-3 h-8 w-8 animate-spin" />
            正在加载时间表
          </CardContent>
        </Card>
      )}
    </motion.div>
  );
}







