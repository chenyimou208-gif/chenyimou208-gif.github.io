﻿import type { CodexQuotaResult, QuotaModel } from '@/types';
import {
  parseCodexUsagePayload,
  formatCodexResetLabel,
  normalizeNumberValue,
  type CodexUsageWindow
} from '@/shared/utils/quota.helpers';

function getWindowResetAtMs(window: CodexUsageWindow): number | undefined {
  const resetAt = normalizeNumberValue(window.reset_at ?? window.resetAt);
  if (resetAt !== null && resetAt > 0) {
    return resetAt < 10000000000 ? resetAt * 1000 : resetAt;
  }

  const resetAfter = normalizeNumberValue(window.reset_after_seconds ?? window.resetAfterSeconds);
  if (resetAfter !== null && resetAfter > 0) {
    return Date.now() + resetAfter * 1000;
  }

  return undefined;
}

function getWindowDurationSeconds(window: CodexUsageWindow): number | null {
  const resetAfter = normalizeNumberValue(window.reset_after_seconds ?? window.resetAfterSeconds);
  if (resetAfter !== null && resetAfter > 0) {
    return resetAfter;
  }

  const resetAtMs = getWindowResetAtMs(window);
  if (resetAtMs !== undefined) {
    return Math.max(0, Math.round((resetAtMs - Date.now()) / 1000));
  }

  return null;
}

function getCodexWindowName(fallbackName: string, window: CodexUsageWindow): string {
  const duration = getWindowDurationSeconds(window);
  if (duration === null) return fallbackName;

  if (duration <= 6 * 60 * 60) return '5小时限额';
  if (duration <= 10 * 24 * 60 * 60) return '周限额';
  return '月度限额';
}

export function parseCodexUsage(body: unknown): CodexQuotaResult {
  const payload = parseCodexUsagePayload(body);
  if (!payload) return { limits: [] };

  const planType = (payload.plan_type ?? payload.planType ?? 'Plus') as string;
  const limits: QuotaModel[] = [];

  const processWindow = (
    name: string,
    windowProp: CodexUsageWindow | boolean | undefined
  ) => {
    if (!windowProp || typeof windowProp !== 'object') return;
    const window = windowProp as CodexUsageWindow;
    const resolvedName = getCodexWindowName(name, window);

    const usedRaw = window.used_percent ?? window.usedPercent;
    let percentage = 0;

    if (usedRaw !== null && usedRaw !== undefined) {
      percentage = Math.max(0, Math.min(100, 100 - Number(usedRaw)));
    } else {
      const remaining = window.remaining_count ?? window.remainingCount ?? 0;
      const total = window.total_count ?? window.totalCount ?? 1;
      percentage = Math.round((Number(remaining) / Math.max(Number(total), 1)) * 100);
    }

    const resetAt = getWindowResetAtMs(window);
    const resetTime = formatCodexResetLabel(window);

    limits.push({
      name: resolvedName,
      percentage,
      resetTime: resetTime !== '-' ? resetTime : undefined,
      resetAt,
      resetReady: resetAt !== undefined ? resetAt <= Date.now() : undefined,
    });
  };

  if (payload.rate_limit && typeof payload.rate_limit === 'object') {
    const rl = payload.rate_limit as Record<string, any>;
    processWindow('限额', rl.primary_window ?? rl.primaryWindow);
    processWindow('限额', rl.secondary_window ?? rl.secondaryWindow);
    processWindow('月度限额', rl.monthly_window ?? rl.monthlyWindow);
  } else {
    processWindow('5小时限额', (payload['5_hour_window'] ?? payload.fiveHourWindow) as CodexUsageWindow);
    processWindow('周限额', (payload['weekly_window'] ?? payload.weeklyWindow) as CodexUsageWindow);
    processWindow('月度限额', (payload['monthly_window'] ?? payload.monthlyWindow) as CodexUsageWindow);
  }

  if (payload.code_review_rate_limit && typeof payload.code_review_rate_limit === 'object') {
    const cr = payload.code_review_rate_limit as Record<string, any>;
    processWindow('代码审查限额', cr.primary_window ?? cr.primaryWindow);
  } else {
    processWindow('代码审查限额', (payload['code_review_window'] ?? payload.codeReviewWindow) as CodexUsageWindow);
  }

  return { plan: planType, limits };
}
