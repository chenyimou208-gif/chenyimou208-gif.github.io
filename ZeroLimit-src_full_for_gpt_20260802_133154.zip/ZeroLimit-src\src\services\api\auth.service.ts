/**
 * Auth Files API
 */

import { apiClient } from './client';
import type { AuthFilesResponse, CpaNodeConnectionConfig } from '@/types';

export const authFilesApi = {
  list: (nodeConfig?: CpaNodeConnectionConfig) => apiClient.get<AuthFilesResponse>('/auth-files', { nodeConfig }),

  deleteFile: (name: string, nodeConfig?: CpaNodeConnectionConfig) => apiClient.delete(`/auth-files?name=${encodeURIComponent(name)}`, { nodeConfig }),

  deleteAll: (nodeConfig?: CpaNodeConnectionConfig) => apiClient.delete('/auth-files?all=true', { nodeConfig }),

  download: (name: string, nodeConfig?: CpaNodeConnectionConfig) => apiClient.get<any>(`/auth-files/download?name=${encodeURIComponent(name)}`, { nodeConfig }),

  upload: (formData: FormData, nodeConfig?: CpaNodeConnectionConfig) => apiClient.post<{ status: string }>('/auth-files', formData, {
    nodeConfig,
    headers: { 'Content-Type': 'multipart/form-data' },
  }),
};