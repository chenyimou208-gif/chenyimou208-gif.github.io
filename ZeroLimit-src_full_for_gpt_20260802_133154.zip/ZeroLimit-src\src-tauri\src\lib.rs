﻿//! CLI Proxy Management Center - Tauri Backend
//!
//! Clean, organized Tauri backend with modular architecture.

mod commands;
mod error;
mod state;
mod single_instance;
mod tray;

use commands::*;
use tauri::Manager;

pub(crate) fn cleanup_on_exit() {
    if let Ok(mut guard) = state::CLI_PROXY_PROCESS.lock() {
        if let Some(ref mut child) = *guard {
            #[cfg(windows)]
            {
                use std::os::windows::process::CommandExt;
                use std::process::Command;
                const CREATE_NO_WINDOW: u32 = 0x08000000;

                let pid = child.id();
                let _ = Command::new("taskkill")
                    .args(["/F", "/T", "/PID", &pid.to_string()])
                    .creation_flags(CREATE_NO_WINDOW)
                    .output();
            }

            #[cfg(not(windows))]
            {
                let _ = child.kill();
            }

            let _ = child.wait();
        }
        *guard = None;
    }

    if let Ok(mut name_guard) = state::CLI_PROXY_NAME.lock() {
        if let Some(ref name) = *name_guard {
            if name.to_lowercase().contains("cliproxy") {
                #[cfg(windows)]
                {
                    use std::os::windows::process::CommandExt;
                    use std::process::Command;
                    const CREATE_NO_WINDOW: u32 = 0x08000000;

                    let _ = Command::new("taskkill")
                        .args(["/F", "/T", "/IM", name])
                        .creation_flags(CREATE_NO_WINDOW)
                        .output();
                }

                #[cfg(not(windows))]
                {
                    use std::process::Command;
                    let _ = Command::new("pkill").args(["-f", name]).output();
                }
            }
        }
        *name_guard = None;
    }
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let _single_instance_guard = match single_instance::acquire() {
        Ok(Some(guard)) => guard,
        Ok(None) => return,
        Err(error) => {
            eprintln!("Failed to acquire ZeroLimit single-instance lock: {error}");
            return;
        }
    };

    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_process::init())
        .plugin(tauri_plugin_os::init())
        .setup(|app| {
            tray::setup_tray(app)?;
            Ok(())
        })
        .on_window_event(|window, event| {
            if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                if state::get_run_in_background() {
                    let _ = window.hide();
                    api.prevent_close();
                } else {
                    api.prevent_close();
                    cleanup_on_exit();
                    window.app_handle().exit(0);
                }
            }
        })
        .invoke_handler(tauri::generate_handler![
            open_external_url,
            set_run_in_background,
            start_cli_proxy,
            stop_cli_proxy,
            is_cli_proxy_running,
            download_and_extract_proxy,
            find_alternate_proxy_exe,
            check_proxy_version,
            get_codex_token_usage,
            read_legacy_quota_storage,
        ])
        .build(tauri::generate_context!())
        .expect("error while building tauri application")
        .run(|_app_handle, event| {
            if let tauri::RunEvent::Exit = event {
                cleanup_on_exit();
            }
        });
}
