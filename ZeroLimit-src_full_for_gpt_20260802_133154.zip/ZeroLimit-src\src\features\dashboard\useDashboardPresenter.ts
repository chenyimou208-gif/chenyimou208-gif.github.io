import { useEffect, useCallback, useRef, useState } from 'react';
import { useAuthStore } from '@/features/auth/auth.store';
import { useCliProxyStore } from '@/features/settings/cliProxy.store';
import { useIntegrationStore } from '@/features/integrations/integration.store';
import { useHeaderRefresh } from '@/shared/hooks';
import { authFilesApi } from '@/services/api/auth.service';
import { serverMonitorApi } from '@/services/api/serverMonitor.service';
import type { ServerMonitorStatus } from '@/types';

export function useDashboardPresenter() {
  const { connectionStatus, checkAuth, updateConnectionStatus, apiBase } = useAuthStore();
  const { isApiHealthy, checkApiHealth } = useCliProxyStore();
  const { monitorUrl, monitorToken, notifyUrl } = useIntegrationStore();
  const [activeAccountsCount, setActiveAccountsCount] = useState<number>(0);
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [serverStatus, setServerStatus] = useState<ServerMonitorStatus | null>(null);
  const [serverStatusError, setServerStatusError] = useState<string | null>(null);
  const [lastServerRefresh, setLastServerRefresh] = useState<number | null>(null);
  const [notifying, setNotifying] = useState(false);
  const serverStatusInFlightRef = useRef(false);

  const loadData = useCallback(async () => {
    setDashboardLoading(true);
    try {
      const response = await authFilesApi.list();
      const rawFiles = Array.isArray(response) ? response : (response?.files ?? response?.items ?? []);
      const filesList = Array.isArray(rawFiles) ? rawFiles : [];
      setActiveAccountsCount(filesList.length);
    } catch {
      setActiveAccountsCount(0);
    } finally {
      setDashboardLoading(false);
    }
  }, []);

  const loadServerStatus = useCallback(async () => {
    if (!monitorUrl.trim()) {
      setServerStatus(null);
      setServerStatusError(null);
      setLastServerRefresh(null);
      return;
    }
    if (serverStatusInFlightRef.current) return;

    serverStatusInFlightRef.current = true;
    try {
      const status = await serverMonitorApi.getStatus(monitorUrl, monitorToken);
      setServerStatus(status);
      setServerStatusError(null);
      setLastServerRefresh(Date.now());
    } catch (error) {
      setServerStatusError((error as Error).message || '服务器监控读取失败');
    } finally {
      serverStatusInFlightRef.current = false;
    }
  }, [monitorToken, monitorUrl]);

  const refreshAll = useCallback(async () => {
    await Promise.allSettled([loadData(), loadServerStatus()]);
  }, [loadData, loadServerStatus]);

  const sendDingTalkReport = useCallback(async () => {
    setNotifying(true);
    try {
      await serverMonitorApi.sendDingTalkReport(notifyUrl, monitorToken);
    } finally {
      setNotifying(false);
    }
  }, [monitorToken, notifyUrl]);

  useEffect(() => {
    checkApiHealth(apiBase);
  }, [checkApiHealth, apiBase]);

  useEffect(() => {
    if (isApiHealthy) {
      checkAuth();
    } else {
      updateConnectionStatus('disconnected');
    }
  }, [isApiHealthy, checkAuth, updateConnectionStatus]);

  useEffect(() => {
    if (connectionStatus === 'connected') {
      loadData();
    }
  }, [connectionStatus, loadData]);

  useEffect(() => {
    loadServerStatus();
  }, [loadServerStatus]);

  useEffect(() => {
    if (!monitorUrl.trim()) return;
    const intervalId = window.setInterval(loadServerStatus, 5000);
    return () => window.clearInterval(intervalId);
  }, [loadServerStatus, monitorUrl]);

  useHeaderRefresh(refreshAll);

  return {
    connectionStatus,
    dashboardLoading,
    activeAccountsCount,
    serverStatus,
    serverStatusError,
    lastServerRefresh,
    monitorUrl,
    notifyUrl,
    notifying,
    loadData: refreshAll,
    sendDingTalkReport,
  };
}
