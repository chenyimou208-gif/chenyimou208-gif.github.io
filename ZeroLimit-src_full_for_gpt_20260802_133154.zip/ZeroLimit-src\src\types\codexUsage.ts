export interface CodexTokenCount {
  inputTokens: number;
  cachedInputTokens: number;
  outputTokens: number;
  reasoningOutputTokens: number;
  totalTokens: number;
}

export interface CodexRateLimit {
  limitId?: string;
  planType?: string;
  usedPercent?: number;
  windowMinutes?: number;
  resetsAt?: number;
  rateLimitReachedType?: string;
}

export interface CodexTokenEvent {
  timestamp: string;
  codexHome: string;
  codexHomeName: string;
  sessionId?: string;
  cwd?: string;
  total: CodexTokenCount;
  last: CodexTokenCount;
  modelContextWindow?: number;
  rateLimit?: CodexRateLimit;
}

export interface CodexHomeUsageSummary {
  name: string;
  path: string;
  sessionsScanned: number;
  tokenEvents: number;
  lastUpdated?: string;
}

export interface CodexTokenUsageReport {
  codexHome: string;
  codexHomes: CodexHomeUsageSummary[];
  sessionsScanned: number;
  tokenEvents: number;
  lastUpdated?: string;
  events: CodexTokenEvent[];
}
