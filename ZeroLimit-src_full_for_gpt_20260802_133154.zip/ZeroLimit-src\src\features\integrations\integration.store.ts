import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { STORAGE_KEY_INTEGRATIONS } from '@/constants';
import type { IntegrationSettings } from '@/types';

interface IntegrationState extends IntegrationSettings {
  setMonitorUrl: (monitorUrl: string) => void;
  setMonitorToken: (monitorToken: string) => void;
  setNotifyUrl: (notifyUrl: string) => void;
}

function normalizeUrl(value: string): string {
  return value.trim().replace(/\/+$/, '');
}

export const useIntegrationStore = create<IntegrationState>()(
  persist(
    (set) => ({
      monitorUrl: '',
      monitorToken: '',
      notifyUrl: '',
      setMonitorUrl: (monitorUrl) => set({ monitorUrl: normalizeUrl(monitorUrl) }),
      setMonitorToken: (monitorToken) => set({ monitorToken: monitorToken.trim() }),
      setNotifyUrl: (notifyUrl) => set({ notifyUrl: normalizeUrl(notifyUrl) }),
    }),
    {
      name: STORAGE_KEY_INTEGRATIONS,
      partialize: (state) => ({
        monitorUrl: state.monitorUrl,
        monitorToken: state.monitorToken,
        notifyUrl: state.notifyUrl,
      }),
    }
  )
);
