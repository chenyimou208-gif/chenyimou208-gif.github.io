import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { AuthState, LoginCredentials, ConnectionStatus } from '@/types';
import { STORAGE_KEY_AUTH } from '@/constants';
import {
  DEFAULT_API_BASE,
  DEFAULT_MANAGEMENT_KEY,
  HAS_BUNDLED_CONNECTION,
  shouldPreferBundledConnection
} from '@/constants/defaultConnection';
import { secureStorage } from '@/services/storage/secureStorage';
import { readLocalConnectionConfig } from '@/services/storage/localConnection';
import { apiClient } from '@/services/api/client';
import { useConfigStore } from '@/features/settings/config.store';
import { useCpaNodesStore } from '@/features/nodes/nodes.store';
import { detectApiBaseFromLocation, normalizeApiBase } from '@/shared/utils/connection';

interface AuthStoreState extends AuthState {
  connectionStatus: ConnectionStatus;
  connectionError: string | null;
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: (options?: { clearSavedCredentials?: boolean }) => void;
  checkAuth: () => Promise<boolean>;
  restoreSession: () => Promise<boolean>;
  updateServerVersion: (version: string | null, buildDate?: string | null) => void;
  updateConnectionStatus: (status: ConnectionStatus, error?: string | null) => void;
}

let restoreSessionPromise: Promise<boolean> | null = null;

function syncDefaultNode(apiBase: string, managementKey: string, markConnected = false) {
  if (!apiBase || !managementKey) return null;
  return useCpaNodesStore.getState().ensureDefaultNode({
    name: '默认节点',
    apiBase,
    managementKey,
    enabled: true,
  }, { markConnected });
}

export const useAuthStore = create<AuthStoreState>()(
  persist(
    (set, get) => ({
      isAuthenticated: false,
      apiBase: '',
      managementKey: '',
      rememberPassword: false,
      serverVersion: null,
      serverBuildDate: null,
      connectionStatus: 'disconnected',
      connectionError: null,

      restoreSession: () => {
        if (restoreSessionPromise) return restoreSessionPromise;

        restoreSessionPromise = (async () => {
          secureStorage.migratePlaintextKeys(['apiBase', 'apiUrl', 'managementKey']);

          const wasLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
          const legacyBase =
            secureStorage.getItem<string>('apiBase') ||
            secureStorage.getItem<string>('apiUrl');
          const legacyKey = secureStorage.getItem<string>('managementKey');
          const localConnection = await readLocalConnectionConfig();
          const defaultNode = useCpaNodesStore.getState().getDefaultNode();

          const { apiBase, managementKey, rememberPassword } = get();
          const storedBase = localConnection?.apiBase || defaultNode?.apiBase || apiBase || legacyBase || '';
          const storedKey = localConnection?.managementKey || defaultNode?.managementKey || managementKey || legacyKey || '';
          const useBundledConnection = shouldPreferBundledConnection(storedBase, storedKey);
          const resolvedBase = normalizeApiBase(
            useBundledConnection
              ? DEFAULT_API_BASE
              : storedBase || DEFAULT_API_BASE || detectApiBaseFromLocation()
          );
          const resolvedKey = useBundledConnection
            ? DEFAULT_MANAGEMENT_KEY
            : storedKey || DEFAULT_MANAGEMENT_KEY || '';
          const resolvedRememberPassword =
            rememberPassword || Boolean(storedKey) || HAS_BUNDLED_CONNECTION;
          const migratedNode = syncDefaultNode(resolvedBase, resolvedKey);
          const nodeBase = migratedNode?.apiBase || resolvedBase;
          const nodeKey = migratedNode?.managementKey || resolvedKey;

          set({
            apiBase: nodeBase,
            managementKey: nodeKey,
            rememberPassword: resolvedRememberPassword,
          });
          apiClient.setConfig({ apiBase: nodeBase, managementKey: nodeKey });

          if ((wasLoggedIn || resolvedRememberPassword) && nodeBase && nodeKey) {
            set({
              isAuthenticated: true,
              connectionStatus: 'connecting',
              connectionError: null,
            });

            try {
              await useConfigStore.getState().fetchConfig(true);
              if (migratedNode) {
                useCpaNodesStore.getState().markNodeConnected(migratedNode.id);
              }
              set({
                isAuthenticated: true,
                connectionStatus: 'connected',
                connectionError: null,
              });
              localStorage.setItem('isLoggedIn', 'true');
              return true;
            } catch (error) {
              console.warn('Auto login failed:', error);
              set({
                isAuthenticated: true,
                connectionStatus: 'error',
                connectionError: (error as Error).message || 'Connection failed',
              });
              return true;
            }
          }

          return false;
        })();

        return restoreSessionPromise;
      },

      login: async (credentials) => {
        const apiBase = normalizeApiBase(credentials.apiBase);
        const managementKey = credentials.managementKey.trim();
        const rememberPassword = credentials.rememberPassword ?? get().rememberPassword ?? false;

        try {
          set({ connectionStatus: 'connecting' });
          apiClient.setConfig({ apiBase, managementKey });
          await useConfigStore.getState().fetchConfig(true);
          const node = syncDefaultNode(apiBase, managementKey, true);
          const resolvedBase = node?.apiBase || apiBase;
          const resolvedKey = node?.managementKey || managementKey;

          set({
            isAuthenticated: true,
            apiBase: resolvedBase,
            managementKey: resolvedKey,
            rememberPassword,
            connectionStatus: 'connected',
            connectionError: null,
          });

          if (rememberPassword) {
            localStorage.setItem('isLoggedIn', 'true');
          } else {
            localStorage.removeItem('isLoggedIn');
          }
        } catch (error: unknown) {
          set({
            connectionStatus: 'error',
            connectionError: (error as Error).message || 'Connection failed',
          });
          throw error;
        }
      },

      logout: (options = { clearSavedCredentials: true }) => {
        restoreSessionPromise = null;
        useConfigStore.getState().clearCache();
        set({
          isAuthenticated: false,
          apiBase: options.clearSavedCredentials ? '' : get().apiBase,
          managementKey: options.clearSavedCredentials ? '' : get().managementKey,
          serverVersion: null,
          serverBuildDate: null,
          connectionStatus: 'disconnected',
          connectionError: null,
        });
        if (options.clearSavedCredentials) {
          localStorage.removeItem('isLoggedIn');
        }
      },

      checkAuth: async () => {
        const defaultNode = useCpaNodesStore.getState().getDefaultNode();
        const apiBase = defaultNode?.apiBase || get().apiBase;
        const managementKey = defaultNode?.managementKey || get().managementKey;

        if (!managementKey || !apiBase) {
          return false;
        }

        try {
          apiClient.setConfig({ apiBase, managementKey });
          await useConfigStore.getState().fetchConfig();
          if (defaultNode) {
            useCpaNodesStore.getState().markNodeConnected(defaultNode.id);
          }
          set({
            isAuthenticated: true,
            apiBase,
            managementKey,
            connectionStatus: 'connected',
          });
          return true;
        } catch {
          set({
            connectionStatus: 'error',
          });
          return false;
        }
      },

      updateServerVersion: (version, buildDate) => {
        set({ serverVersion: version || null, serverBuildDate: buildDate || null });
      },

      updateConnectionStatus: (status, error = null) => {
        set({
          connectionStatus: status,
          connectionError: error,
        });
      },
    }),
    {
      name: STORAGE_KEY_AUTH,
      storage: createJSONStorage(() => ({
        getItem: (name) => {
          const data = secureStorage.getItem<AuthStoreState>(name);
          return data ? JSON.stringify(data) : null;
        },
        setItem: (name, value) => {
          secureStorage.setItem(name, JSON.parse(value));
        },
        removeItem: (name) => {
          secureStorage.removeItem(name);
        },
      })),
      partialize: (state) => ({
        apiBase: state.apiBase,
        ...(state.rememberPassword ? { managementKey: state.managementKey } : {}),
        rememberPassword: state.rememberPassword,
        serverVersion: state.serverVersion,
        serverBuildDate: state.serverBuildDate,
      }),
    }
  )
);

if (typeof window !== 'undefined') {
  window.addEventListener('unauthorized', () => {
    useAuthStore.getState().updateConnectionStatus('error', 'Management request unauthorized. Please check the management key.');
  });

  window.addEventListener(
    'server-version-update',
    ((e: CustomEvent) => {
      const detail = e.detail || {};
      useAuthStore.getState().updateServerVersion(detail.version || null, detail.buildDate || null);
    }) as EventListener
  );

  window.addEventListener('network-error', () => {
    useAuthStore.getState().updateConnectionStatus('disconnected', 'Network error or server unreachable');
  });
}