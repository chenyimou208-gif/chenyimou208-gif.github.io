import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuthStore } from '@/features/auth/auth.store';
import { useIntegrationStore } from '@/features/integrations/integration.store';
import { useCpaNodesStore } from '@/features/nodes/nodes.store';
import { authFilesApi } from '@/services/api/auth.service';
import { quotaApi } from '@/services/api/quota.service';
import { serverMonitorApi } from '@/services/api/serverMonitor.service';
import type { AuthFile, CpaNodeConnectionConfig, FileQuota, ProviderSection, QuotaModel, QuotaSnapshot } from '@/types';
import type { ProviderFilterItem } from '@/features/quota/components/ProviderFilter';
import { resolveCodexChatgptAccountId, resolveCodexPlanType, resolveGeminiCliProjectId } from '@/shared/utils/quota.helpers';
import { toast } from 'sonner';

function getProviderType(file: AuthFile): 'antigravity' | 'codex' | 'gemini-cli' | 'kiro' | 'copilot' | 'anthropic' | 'unknown' {
  const filename = (file?.filename || file?.id || '').toLowerCase();

  if (filename.startsWith('antigravity-') || filename.includes('antigravity')) return 'antigravity';
  if (filename.startsWith('codex-') || filename.includes('codex')) return 'codex';
  if (filename.startsWith('gemini-cli-') || filename.includes('gemini')) return 'gemini-cli';
  if (filename.startsWith('kiro-') || filename.includes('kiro')) return 'kiro';
  if (filename.startsWith('github-copilot-') || filename.includes('copilot')) return 'copilot';
  if (filename.startsWith('claude-') || filename.includes('claude') || filename.includes('anthropic')) return 'anthropic';

  const provider = (file?.provider || '').toLowerCase();
  if (provider.includes('antigravity')) return 'antigravity';
  if (provider.includes('codex')) return 'codex';
  if (provider.includes('gemini')) return 'gemini-cli';
  if (provider.includes('kiro')) return 'kiro';
  if (provider.includes('copilot') || provider.includes('github')) return 'copilot';
  if (provider.includes('claude') || provider.includes('anthropic')) return 'anthropic';

  return 'unknown';
}

function formatFilename(name: string): string {
  return name.replace(/_gmail_com/g, '').replace(/\.json$/g, '');
}

function getQuotaItemCount(file: FileQuota): number {
  return (file.models || file.limits || []).filter(item => Number.isFinite(item.percentage)).length;
}

function getAuthFileDeleteName(file: FileQuota): string {
  return (
    file.originalFile?.name ||
    file.originalFile?.filename ||
    file.originalFile?.id ||
    file.fileId
  ) as string;
}

function getAuthFileStorageName(file: FileQuota): string {
  const name = getAuthFileDeleteName(file);
  if (!name) return '';
  return name.toLowerCase().endsWith('.json') ? name : `${name}.json`;
}

function isAuthFileDisabled(file?: AuthFile): boolean {
  const value = file?.disabled ?? file?.is_disabled ?? file?.isDisabled;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value === 1;
  if (typeof value === 'string') {
    return ['true', '1', 'yes', 'on'].includes(value.trim().toLowerCase());
  }
  return false;
}

function isTransientQuotaError(error?: string): boolean {
  const text = (error || '').toLowerCase();
  if (!text) return false;
  if (text.includes('401') || text.includes('unauthorized') || text.includes('invalidated oauth')) return false;
  if (text.includes('403') || text.includes('access denied')) return false;

  return (
    text.includes('429') ||
    text.includes('500') ||
    text.includes('502') ||
    text.includes('503') ||
    text.includes('504') ||
    text.includes('service unavailable') ||
    text.includes('server had an error') ||
    text.includes('server error') ||
    text.includes('bad gateway') ||
    text.includes('gateway timeout') ||
    text.includes('timeout') ||
    text.includes('network') ||
    text.includes('temporarily') ||
    text.includes('try again') ||
    text.includes('rate limit') ||
    text.includes('upstream') ||
    text.includes('overloaded')
  );
}

function isUnavailableForCleanup(file: FileQuota): boolean {
  if (isAuthFileDisabled(file.originalFile)) return false;
  if (file.loading || file.quotaChecked === false) return false;
  if (file.error) return !isTransientQuotaError(file.error);
  if (file.plan?.toLowerCase() === 'suspended') return true;
  return getQuotaItemCount(file) === 0;
}

function isZeroQuotaForDisable(file: FileQuota): boolean {
  if (isAuthFileDisabled(file.originalFile)) return false;
  if (file.loading || file.quotaChecked === false || file.error) return false;
  if (file.plan?.toLowerCase() === 'suspended') return false;

  const items = (file.models || file.limits || []).filter(item => Number.isFinite(item.percentage));
  return items.length > 0 && items.every(item => clampPercentage(item.percentage) <= 0);
}

function isInvalidTokenForCleanup(file: FileQuota): boolean {
  if (file.loading) return false;
  const error = file.error?.toLowerCase() || '';
  if (!error) return false;

  return (
    error.includes('401') ||
    error.includes('unauthorized') ||
    error.includes('invalidated oauth') ||
    error.includes('invalid or expired') ||
    error.includes('token expired') ||
    error.includes('re-authenticate')
  );
}

const ICON_MAP: Record<string, { path?: string; needsInvert: boolean }> = {
  antigravity: { path: '/antigravity/antigravity.png', needsInvert: false },
  codex: { path: '/openai/openai.png', needsInvert: false },
  'gemini-cli': { path: '/gemini/gemini.png', needsInvert: false },
  kiro: { path: '/kiro/kiro.png', needsInvert: false },
  copilot: { path: '/copilot/copilot.png', needsInvert: true },
  anthropic: { path: '/claude/claude.png', needsInvert: false },
};

const PROVIDER_DISPLAY: { key: string; name: string }[] = [
  { key: 'antigravity', name: 'Antigravity' },
  { key: 'codex', name: 'Codex (OpenAI)' },
  { key: 'gemini-cli', name: 'Gemini CLI' },
  { key: 'kiro', name: 'Kiro (CodeWhisperer)' },
  { key: 'copilot', name: 'GitHub Copilot' },
  { key: 'anthropic', name: 'Claude (Anthropic)' },
  { key: 'unknown', name: 'Other' },
];

type QuotaSortMode = 'newest' | 'quota-desc' | 'quota-asc';

const DISABLED_OVERRIDES_STORAGE_KEY = 'zerolimit.quota.disabledOverrides.v1';
const ZERO_QUOTA_DISABLED_STORAGE_KEY = 'zerolimit.quota.zeroQuotaDisabled.v1';
const IMPORT_TIMES_STORAGE_KEY = 'zerolimit.quota.importTimes.v1';
const ZERO_QUOTA_ZEROED_AT_STORAGE_KEY = 'zerolimit.quota.zeroQuotaZeroedAt.v1';
const QUOTA_CACHE_STORAGE_KEY = 'zerolimit.quota.cache.v1';
const QUOTA_SORT_MODE_STORAGE_KEY = 'zerolimit.quota.sortMode.v1';
const QUOTA_CACHE_TTL_MS = 60 * 60 * 1000;
const TRANSIENT_ERROR_CACHE_TTL_MS = 5 * 60 * 1000;
const AUTO_REFRESH_MIN_CACHE_AGE_MS = 10 * 60 * 1000;
const INITIAL_REFRESH_CONCURRENCY = 4;
const MANUAL_REFRESH_CONCURRENCY = 6;
const AUTO_REFRESH_CONCURRENCY = 4;
const AUTO_REFRESH_BATCH_SIZE = 6;
const AUTO_REFRESH_INTERVAL_MS = 15000;

interface QuotaCacheEntry {
  nodeId: string;
  accountKey: string;
  providerKey: string;
  updatedAt: number;
  models?: QuotaModel[];
  limits?: QuotaModel[];
  plan?: string;
  email?: string;
  error?: string;
}

export interface CpaNodeOption {
  id: string;
  name: string;
  enabled: boolean;
  tags?: string;
}

function loadStoredRecord(key: string): Record<string, string | boolean> {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed as Record<string, string | boolean> : {};
  } catch {
    return {};
  }
}

function saveStoredRecord(key: string, record: Record<string, string | boolean>) {
  window.localStorage.setItem(key, JSON.stringify(record));
}

function isQuotaSortMode(value: unknown): value is QuotaSortMode {
  return value === 'newest' || value === 'quota-desc' || value === 'quota-asc';
}

function loadStoredQuotaSortMode(): QuotaSortMode {
  try {
    const raw = window.localStorage.getItem(QUOTA_SORT_MODE_STORAGE_KEY);
    return isQuotaSortMode(raw) ? raw : 'newest';
  } catch {
    return 'newest';
  }
}

function saveStoredQuotaSortMode(mode: QuotaSortMode) {
  window.localStorage.setItem(QUOTA_SORT_MODE_STORAGE_KEY, mode);
}
function loadQuotaCache(): Record<string, QuotaCacheEntry> {
  try {
    const raw = window.localStorage.getItem(QUOTA_CACHE_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed as Record<string, QuotaCacheEntry> : {};
  } catch {
    return {};
  }
}

function saveQuotaCache(cache: Record<string, QuotaCacheEntry>) {
  window.localStorage.setItem(QUOTA_CACHE_STORAGE_KEY, JSON.stringify(cache));
}

function getScopedAccountKey(nodeId: string | undefined, accountKey: string): string {
  return `${nodeId || 'default'}::${accountKey}`;
}

function readScopedRecordValue(
  record: Record<string, string | boolean>,
  nodeId: string | undefined,
  accountKey: string,
  defaultNodeId: string | null,
): string | boolean | undefined {
  const scopedKey = getScopedAccountKey(nodeId, accountKey);
  if (record[scopedKey] !== undefined) return record[scopedKey];
  if (nodeId && defaultNodeId && nodeId === defaultNodeId && record[accountKey] !== undefined) return record[accountKey];
  return undefined;
}

function readValidQuotaCache(
  cache: Record<string, QuotaCacheEntry>,
  nodeId: string,
  accountKey: string,
  providerKey: string,
): QuotaCacheEntry | null {
  const entry = cache[getScopedAccountKey(nodeId, accountKey)];
  if (!entry || entry.providerKey !== providerKey) return null;
  const ttl = entry.error && isTransientQuotaError(entry.error) ? TRANSIENT_ERROR_CACHE_TTL_MS : QUOTA_CACHE_TTL_MS;
  if (Date.now() - entry.updatedAt > ttl) return null;
  return entry;
}

function isQuotaCacheFreshEnough(
  cache: Record<string, QuotaCacheEntry>,
  nodeId: string,
  accountKey: string,
  providerKey: string,
  maxAgeMs: number,
): boolean {
  const entry = cache[getScopedAccountKey(nodeId, accountKey)];
  if (!entry || entry.providerKey !== providerKey) return false;
  return Date.now() - entry.updatedAt < maxAgeMs;
}

function applyCachedQuota(file: FileQuota, cache: QuotaCacheEntry): FileQuota {
  return {
    ...file,
    loading: false,
    quotaChecked: true,
    models: cache.models,
    limits: cache.limits,
    plan: cache.plan,
    email: cache.email || file.email,
    error: cache.error,
  };
}

function getAuthFileKey(file?: AuthFile, fallback = ''): string {
  return String(
    file?.auth_index ||
    file?.authIndex ||
    file?.id ||
    file?.filename ||
    file?.name ||
    fallback
  );
}

function getFileKey(file: FileQuota): string {
  const accountKey = getAuthFileKey(file.originalFile, file.fileId.split('::').pop() || file.fileId);
  return getScopedAccountKey(file.nodeId || String(file.originalFile?.__nodeId || ''), accountKey);
}

function normalizeTimestamp(value: unknown): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value < 10000000000 ? value * 1000 : value;
  }

  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return null;

    const numeric = Number(trimmed);
    if (Number.isFinite(numeric)) {
      return numeric < 10000000000 ? numeric * 1000 : numeric;
    }

    const parsed = Date.parse(trimmed);
    return Number.isFinite(parsed) ? parsed : null;
  }

  return null;
}

function getFileTimestamp(file: FileQuota): number | null {
  const storedTimestamp = normalizeTimestamp(file.importedAt);
  if (storedTimestamp !== null) return storedTimestamp;

  const original = file.originalFile;
  const candidates = [
    original?.createdAt,
    original?.created_at,
    original?.uploadedAt,
    original?.uploaded_at,
    original?.modifiedAt,
    original?.modified_at,
    original?.created,
    original?.mtime,
  ];

  for (const candidate of candidates) {
    const timestamp = normalizeTimestamp(candidate);
    if (timestamp !== null) return timestamp;
  }

  return null;
}

function getAuthFileTimestamp(file: AuthFile): number | null {
  const candidates = [
    file.createdAt,
    file.created_at,
    file.uploadedAt,
    file.uploaded_at,
    file.created,
    file.ctime,
    file.mtime,
    file.modifiedAt,
    file.modified_at,
  ];

  for (const candidate of candidates) {
    const timestamp = normalizeTimestamp(candidate);
    if (timestamp !== null) return timestamp;
  }

  return null;
}

function resolveStoredImportTime(
  file: AuthFile,
  nodeId: string,
  key: string,
  stored: Record<string, string | boolean>,
  defaultNodeId: string | null,
): string {
  const storedValue = readScopedRecordValue(stored, nodeId, key, defaultNodeId);
  if (typeof storedValue === 'string' && storedValue.trim()) return storedValue;

  const timestamp = getAuthFileTimestamp(file);
  if (timestamp !== null) return new Date(timestamp).toISOString();
  return new Date().toISOString();
}

function getFileQuotaAverage(file: FileQuota): number | null {
  const items = (file.models || file.limits || []).filter(item => Number.isFinite(item.percentage));
  if (items.length === 0) return null;
  return items.reduce((sum, item) => sum + item.percentage, 0) / items.length;
}

function clampPercentage(value: number) {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, Math.round(value)));
}

function buildQuotaSnapshot(sections: ProviderSection[]): QuotaSnapshot | null {
  const allFiles = sections.flatMap(section => section.files);
  const enabledFiles = allFiles.filter(file => !isAuthFileDisabled(file.originalFile));
  if (enabledFiles.length === 0) return null;

  const accountAverages = enabledFiles
    .map(getFileQuotaAverage)
    .filter((value): value is number => value !== null)
    .map(clampPercentage);
  const average = accountAverages.length
    ? clampPercentage(accountAverages.reduce((sum, value) => sum + value, 0) / accountAverages.length)
    : 0;

  let healthyCount = 0;
  let watchCount = 0;
  let lowCount = 0;
  let unavailableCount = 0;
  let itemCount = 0;

  enabledFiles.forEach(file => {
    const items = (file.models || file.limits || []).filter(item => Number.isFinite(item.percentage));
    itemCount += items.length;

    if (file.loading || file.error || file.plan?.toLowerCase() === 'suspended' || items.length === 0) {
      unavailableCount++;
      return;
    }

    const fileAverage = getFileQuotaAverage(file);
    if (fileAverage === null) {
      unavailableCount++;
    } else if (fileAverage > 50) {
      healthyCount++;
    } else if (fileAverage > 20) {
      watchCount++;
    } else {
      lowCount++;
    }
  });

  return {
    average,
    accountCount: enabledFiles.length,
    itemCount,
    healthyCount,
    watchCount,
    lowCount,
    unavailableCount,
    updatedAt: new Date().toISOString(),
  };
}

function compareBestQuotaFile(a: FileQuota, b: FileQuota): number {
  const aAverage = getFileQuotaAverage(a);
  const bAverage = getFileQuotaAverage(b);

  if (aAverage !== null || bAverage !== null) {
    return (bAverage ?? -1) - (aAverage ?? -1);
  }

  return (a.importOrder ?? 0) - (b.importOrder ?? 0);
}

type QuotaHealthStatus = 'healthy' | 'watch' | 'low' | 'unavailable';

function getQuotaHealthStatus(file: FileQuota): QuotaHealthStatus {
  if (file.loading || file.quotaChecked === false || file.error || file.plan?.toLowerCase() === 'suspended') return 'unavailable';

  const average = getFileQuotaAverage(file);
  if (average === null) return 'unavailable';
  if (average > 50) return 'healthy';
  if (average > 20) return 'watch';
  return 'low';
}

async function runWithConcurrency<T>(
  items: T[],
  limit: number,
  worker: (item: T) => Promise<void>
): Promise<Array<{ item: T; error: unknown }>> {
  const failures: Array<{ item: T; error: unknown }> = [];
  let nextIndex = 0;

  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (nextIndex < items.length) {
      const item = items[nextIndex++];
      try {
        await worker(item);
      } catch (error) {
        failures.push({ item, error });
      }
    }
  });

  await Promise.all(runners);
  return failures;
}

function sortFiles(files: FileQuota[], mode: QuotaSortMode): FileQuota[] {
  const sorted = [...files];

  if (mode === 'newest') {
    return sorted.sort((a, b) => {
      const aTime = getFileTimestamp(a);
      const bTime = getFileTimestamp(b);

      if (aTime !== null || bTime !== null) {
        return (bTime ?? 0) - (aTime ?? 0);
      }

      return (b.importOrder ?? 0) - (a.importOrder ?? 0);
    });
  }

  return sorted.sort((a, b) => {
    const aAverage = getFileQuotaAverage(a);
    const bAverage = getFileQuotaAverage(b);

    if (aAverage === null && bAverage === null) {
      return (b.importOrder ?? 0) - (a.importOrder ?? 0);
    }

    if (aAverage === null) return 1;
    if (bAverage === null) return -1;

    return mode === 'quota-desc' ? bAverage - aAverage : aAverage - bAverage;
  });
}

export function useQuotaPresenter() {
  const { t } = useTranslation();
  const { isAuthenticated } = useAuthStore();
  const { nodes, defaultNodeId, selectedNodeId, setSelectedNode } = useCpaNodesStore();
  const { monitorUrl, monitorToken } = useIntegrationStore();
  const [sections, setSections] = useState<ProviderSection[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadingAuthFiles, setUploadingAuthFiles] = useState(false);
  const [deletingUnavailableFiles, setDeletingUnavailableFiles] = useState(false);
  const [deletingInvalidTokenFiles, setDeletingInvalidTokenFiles] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('antigravity');
  const [viewMode, setViewMode] = useState<'list' | 'card'>('list');
  const [sortMode, setSortMode] = useState<QuotaSortMode>(() => loadStoredQuotaSortMode());
  const [isPrivacyMode, setIsPrivacyMode] = useState(true);
  const [updatingDisabledFileIds, setUpdatingDisabledFileIds] = useState<Record<string, boolean>>({});
  const [bulkUpdatingDisabledFiles, setBulkUpdatingDisabledFiles] = useState(false);
  const [disabledOverrides, setDisabledOverrides] = useState<Record<string, boolean>>(() => {
    const stored = loadStoredRecord(DISABLED_OVERRIDES_STORAGE_KEY);
    return Object.fromEntries(
      Object.entries(stored).filter((entry): entry is [string, boolean] => typeof entry[1] === 'boolean')
    );
  });
  const [zeroQuotaDisabledKeys, setZeroQuotaDisabledKeys] = useState<Record<string, boolean>>(() => {
    const stored = loadStoredRecord(ZERO_QUOTA_DISABLED_STORAGE_KEY);
    return Object.fromEntries(
      Object.entries(stored).filter((entry): entry is [string, boolean] => typeof entry[1] === 'boolean')
    );
  });
  const [importTimes, setImportTimes] = useState<Record<string, string>>(() => {
    const stored = loadStoredRecord(IMPORT_TIMES_STORAGE_KEY);
    return Object.fromEntries(
      Object.entries(stored).filter((entry): entry is [string, string] => typeof entry[1] === 'string')
    );
  });
  const silentRefreshInFlightRef = useRef(false);
  const autoRefreshCursorRef = useRef(0);
  const sectionsRef = useRef<ProviderSection[]>([]);
  const enabledFilesRef = useRef<FileQuota[]>([]);
  const importTimesRef = useRef(importTimes);
  const lastSnapshotRef = useRef('');
  const quotaCacheRef = useRef<Record<string, QuotaCacheEntry>>(loadQuotaCache());

  const activeNode = useMemo(() => {
    return nodes.find(node => node.id === selectedNodeId) ||
      nodes.find(node => node.id === defaultNodeId) ||
      nodes.find(node => node.enabled) ||
      nodes[0] ||
      null;
  }, [defaultNodeId, nodes, selectedNodeId]);
  const activeNodeId = activeNode?.id || '';
  const activeNodeName = activeNode?.name || '未选择节点';
  const nodeConfig = useMemo<CpaNodeConnectionConfig | null>(() => (
    activeNode ? { apiBase: activeNode.apiBase, managementKey: activeNode.managementKey } : null
  ), [activeNode]);
  const nodeOptions: CpaNodeOption[] = useMemo(() => nodes.map(node => ({
    id: node.id,
    name: node.name,
    enabled: node.enabled,
    tags: node.tags,
  })), [nodes]);
  const canWriteSelectedNode = Boolean(activeNode && activeNode.enabled && nodeConfig);

  useEffect(() => {
    if (!nodes.length) return;
    if (selectedNodeId && nodes.some(node => node.id === selectedNodeId)) return;
    setSelectedNode(defaultNodeId || nodes[0].id);
  }, [defaultNodeId, nodes, selectedNodeId, setSelectedNode]);

  useEffect(() => {
    saveStoredRecord(DISABLED_OVERRIDES_STORAGE_KEY, disabledOverrides);
  }, [disabledOverrides]);

  useEffect(() => {
    saveStoredRecord(ZERO_QUOTA_DISABLED_STORAGE_KEY, zeroQuotaDisabledKeys);
  }, [zeroQuotaDisabledKeys]);

  useEffect(() => {
    saveStoredRecord(IMPORT_TIMES_STORAGE_KEY, importTimes);
    importTimesRef.current = importTimes;
  }, [importTimes]);

  useEffect(() => {
    saveStoredQuotaSortMode(sortMode);
  }, [sortMode]);

  useEffect(() => {
    sectionsRef.current = sections;
  }, [sections]);

  const writeQuotaCacheEntry = useCallback((entry: QuotaCacheEntry) => {
    const nextCache = {
      ...quotaCacheRef.current,
      [getScopedAccountKey(entry.nodeId, entry.accountKey)]: entry,
    };
    quotaCacheRef.current = nextCache;
    saveQuotaCache(nextCache);
  }, []);

  useEffect(() => {
    if (!monitorUrl.trim() || !monitorToken.trim()) return;

    const snapshot = buildQuotaSnapshot(sections);
    if (!snapshot || snapshot.itemCount === 0) return;

    const signature = JSON.stringify({
      average: snapshot.average,
      accountCount: snapshot.accountCount,
      itemCount: snapshot.itemCount,
      healthyCount: snapshot.healthyCount,
      watchCount: snapshot.watchCount,
      lowCount: snapshot.lowCount,
      unavailableCount: snapshot.unavailableCount,
    });

    if (signature === lastSnapshotRef.current) return;
    lastSnapshotRef.current = signature;

    serverMonitorApi.saveQuotaSnapshot(monitorUrl, monitorToken, snapshot).catch((error) => {
      console.warn('Failed to sync quota snapshot:', error);
    });
  }, [monitorToken, monitorUrl, sections]);

  const getNodeForId = useCallback((nodeId?: string | null) => {
    if (!nodeId) return activeNode;
    return nodes.find(node => node.id === nodeId) || activeNode;
  }, [activeNode, nodes]);

  const getNodeConfigForFile = useCallback((file?: FileQuota | AuthFile): CpaNodeConnectionConfig | null => {
    const record = file as Record<string, unknown> | undefined;
    const original = record?.originalFile as Record<string, unknown> | undefined;
    const nodeId = String(record?.nodeId || record?.__nodeId || original?.__nodeId || activeNode?.id || '');
    const node = getNodeForId(nodeId);
    if (!node || !node.enabled) return null;
    return { apiBase: node.apiBase, managementKey: node.managementKey };
  }, [activeNode, getNodeForId]);

  const fetchQuotaForFile = useCallback(async (
    fileId: string,
    providedFile?: AuthFile,
    options: { silent?: boolean; force?: boolean } = {}
  ) => {
    const silent = Boolean(options.silent);
    let targetProvider: string | undefined;
    let existingQuotaFile: FileQuota | undefined;

    for (const section of sectionsRef.current) {
      const match = section.files.find(f => f.fileId === fileId);
      if (match) {
        existingQuotaFile = match;
        targetProvider = section.provider;
        break;
      }
    }

    if (providedFile && isAuthFileDisabled(providedFile)) {
      setSections((prev) => prev.map(section => ({
        ...section,
        files: section.files.map(f => f.fileId === fileId ? { ...f, loading: false, error: undefined } : f)
      })));
      return;
    }

    if (providedFile) {
      const type = getProviderType(providedFile);
      if (type !== 'unknown') targetProvider = type;
    }

    if (!targetProvider) return;

    try {
      let file = providedFile;
      if (!file) {
        file = existingQuotaFile?.originalFile;
      }

      if (!file) throw new Error('File not found');

      const targetNodeId = String(file.__nodeId || existingQuotaFile?.nodeId || activeNode?.id || '');
      const targetNode = getNodeForId(targetNodeId);
      if (!targetNode || !targetNode.enabled) throw new Error('No enabled CPA node selected');
      const targetNodeConfig: CpaNodeConnectionConfig = { apiBase: targetNode.apiBase, managementKey: targetNode.managementKey };

      const rawFileId = fileId.split('::').pop() || fileId;
      const authIndex = (file['auth_index'] as string) || (file['authIndex'] as string) || file.id || file.filename;
      if (!authIndex) throw new Error('No auth index (auth_index, id or filename) found');

      const accountKey = getAuthFileKey(file, rawFileId);
      const cachedQuota = options.force ? null : readValidQuotaCache(quotaCacheRef.current, targetNode.id, accountKey, targetProvider);
      if (cachedQuota) {
        setSections((prev) => prev.map(section => ({
          ...section,
          files: section.files.map(f => f.fileId === fileId ? applyCachedQuota(f, cachedQuota) : f)
        })));
        return;
      }

      if (!silent) {
        setSections((prev) => prev.map(section => {
          if (section.provider !== targetProvider) return section;
          return {
            ...section,
            files: section.files.map(f => f.fileId === fileId ? { ...f, loading: true, quotaChecked: false, error: undefined } : f)
          };
        }));
      }

      if (targetProvider === 'antigravity') {
        const result = await quotaApi.fetchAntigravity(authIndex, targetNodeConfig);
        writeQuotaCacheEntry({ nodeId: targetNode.id, accountKey, providerKey: targetProvider, updatedAt: Date.now(), models: result.models, error: result.error });
        setSections((prev) => prev.map(s => s.provider === 'antigravity' ? {
          ...s,
          files: s.files.map(f => f.fileId === fileId ? {
            ...f, loading: false, quotaChecked: true, models: result.models, error: result.error
          } : f)
        } : s));

      } else if (targetProvider === 'codex') {
        const accountId = resolveCodexChatgptAccountId(file);
        const result = await quotaApi.fetchCodex(authIndex, accountId || undefined, targetNodeConfig);
        const plan = result.plan || resolveCodexPlanType(file) || 'Plus';
        writeQuotaCacheEntry({ nodeId: targetNode.id, accountKey, providerKey: targetProvider, updatedAt: Date.now(), limits: result.limits, plan, error: result.error });

        setSections((prev) => prev.map(s => s.provider === 'codex' ? {
          ...s,
          files: s.files.map(f => f.fileId === fileId ? {
            ...f, loading: false, quotaChecked: true, plan, limits: result.limits, error: result.error
          } : f)
        } : s));

      } else if (targetProvider === 'gemini-cli') {
        const projectId = resolveGeminiCliProjectId(file);
        if (!projectId) throw new Error('Project ID not found in file');
        const result = await quotaApi.fetchGeminiCli(authIndex, projectId, targetNodeConfig);

        const models = result.buckets.map(b => ({
          name: b.modelId, percentage: b.percentage, resetTime: b.resetTime
        }));
        writeQuotaCacheEntry({ nodeId: targetNode.id, accountKey, providerKey: targetProvider, updatedAt: Date.now(), models, error: result.error });

        setSections((prev) => prev.map(s => s.provider === 'gemini-cli' ? {
          ...s,
          files: s.files.map(f => f.fileId === fileId ? {
            ...f,
            loading: false,
            quotaChecked: true,
            models,
            error: result.error
          } : f)
        } : s));

      } else if (targetProvider === 'kiro') {
        const result = await quotaApi.fetchKiro(authIndex, targetNodeConfig);
        writeQuotaCacheEntry({ nodeId: targetNode.id, accountKey, providerKey: targetProvider, updatedAt: Date.now(), plan: result.plan, models: result.models, email: result.email, error: result.error });
        setSections((prev) => prev.map(s => s.provider === 'kiro' ? {
          ...s,
          files: s.files.map(f => f.fileId === fileId ? {
            ...f, loading: false, quotaChecked: true, plan: result.plan, models: result.models, email: result.email, error: result.error
          } : f)
        } : s));

      } else if (targetProvider === 'copilot') {
        const result = await quotaApi.fetchCopilot(authIndex, targetNodeConfig);
        writeQuotaCacheEntry({ nodeId: targetNode.id, accountKey, providerKey: targetProvider, updatedAt: Date.now(), plan: result.plan, models: result.models, error: result.error });
        setSections((prev) => prev.map(s => s.provider === 'copilot' ? {
          ...s,
          files: s.files.map(f => f.fileId === fileId ? {
            ...f, loading: false, quotaChecked: true, plan: result.plan, models: result.models, error: result.error
          } : f)
        } : s));
      } else if (targetProvider === 'anthropic') {
        const result = await quotaApi.fetchClaude(authIndex, targetNodeConfig);
        writeQuotaCacheEntry({ nodeId: targetNode.id, accountKey, providerKey: targetProvider, updatedAt: Date.now(), email: result.email, models: result.models, error: result.error });
        setSections((prev) => prev.map(s => s.provider === 'anthropic' ? {
          ...s,
          files: s.files.map(f => f.fileId === fileId ? {
            ...f, loading: false, quotaChecked: true, email: result.email, models: result.models, error: result.error
          } : f)
        } : s));
      }
    } catch (err) {
      const msg = (err as Error).message;
      setSections((prev) => prev.map(section => ({
        ...section,
        files: section.files.map(f => f.fileId === fileId ? { ...f, loading: false, quotaChecked: true, error: msg } : f)
      })));
    }
  }, [activeNode, getNodeForId, writeQuotaCacheEntry]);

  const loadAuthFiles = useCallback(async () => {
    if (!isAuthenticated) return;

    if (!activeNode || !nodeConfig || !activeNode.enabled) {
      setSections(PROVIDER_DISPLAY.map(p => ({ provider: p.key, displayName: p.name, files: [] })));
      setError(activeNode ? '当前 CPA 节点已停用，请在设置中启用后再刷新。' : '请先在设置中添加 CPA 节点。');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const resp = await authFilesApi.list(nodeConfig);
      const files: AuthFile[] = Array.isArray(resp) ? resp : (resp as any).items || (resp as any).files || [];

      const grouped: Record<string, FileQuota[]> = {
        antigravity: [], codex: [], 'gemini-cli': [], kiro: [], copilot: [], anthropic: [], unknown: []
      };
      const refreshTargets: Array<{ fileId: string; file: AuthFile }> = [];
      const nextImportTimes = { ...importTimesRef.current };
      let importTimesChanged = false;

      files.forEach((file, index) => {
        if (!file) return;
        const providerType = getProviderType(file);
        if (!grouped[providerType]) return;

        const rawFileId = String(file.id || file.filename || index);
        const fileId = getScopedAccountKey(activeNode.id, rawFileId);
        const accountKey = getAuthFileKey(file, rawFileId);
        const scopedKey = getScopedAccountKey(activeNode.id, accountKey);
        const importedAt = resolveStoredImportTime(file, activeNode.id, accountKey, nextImportTimes, defaultNodeId);
        const disabledOverride = readScopedRecordValue(disabledOverrides, activeNode.id, accountKey, defaultNodeId);
        const zeroTracked = readScopedRecordValue(zeroQuotaDisabledKeys, activeNode.id, accountKey, defaultNodeId) === true;
        const effectiveDisabled = typeof disabledOverride === 'boolean'
          ? disabledOverride
          : isAuthFileDisabled(file);
        const cachedQuota = providerType === 'unknown'
          ? null
          : readValidQuotaCache(quotaCacheRef.current, activeNode.id, accountKey, providerType);
        const shouldRefresh = !effectiveDisabled && !zeroTracked && providerType !== 'unknown' && !cachedQuota;
        const originalFile = { ...file, disabled: effectiveDisabled, __nodeId: activeNode.id, __nodeName: activeNode.name } as AuthFile;

        if (nextImportTimes[scopedKey] !== importedAt) {
          nextImportTimes[scopedKey] = importedAt;
          importTimesChanged = true;
        }

        let quotaFile: FileQuota = {
          fileId,
          filename: formatFilename(file.filename || file.id || 'unknown'),
          provider: providerType.charAt(0).toUpperCase() + providerType.slice(1),
          providerKey: providerType,
          loading: shouldRefresh,
          quotaChecked: shouldRefresh ? false : cachedQuota ? true : undefined,
          originalFile,
          importOrder: index,
          importedAt,
          nodeId: activeNode.id,
          nodeName: activeNode.name,
        };

        if (cachedQuota) {
          quotaFile = applyCachedQuota(quotaFile, cachedQuota);
        }

        grouped[providerType].push(quotaFile);

        if (shouldRefresh) {
          refreshTargets.push({ fileId, file: originalFile });
        }
      });

      setSections(PROVIDER_DISPLAY.map(p => ({
        provider: p.key,
        displayName: p.name,
        files: grouped[p.key] || [],
      })));

      if (refreshTargets.length > 0) {
        void runWithConcurrency(refreshTargets, INITIAL_REFRESH_CONCURRENCY, async (target) => {
          await fetchQuotaForFile(target.fileId, target.file);
        });
      }

      if (importTimesChanged) {
        setImportTimes(nextImportTimes as Record<string, string>);
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [activeNode, defaultNodeId, disabledOverrides, fetchQuotaForFile, isAuthenticated, nodeConfig, zeroQuotaDisabledKeys]);

  useEffect(() => {
    loadAuthFiles();
  }, [loadAuthFiles]);

  const filterItems: ProviderFilterItem[] = useMemo(() => {
    return sections
      .filter(s => s.files.length > 0)
      .map(s => {
        const iconInfo = ICON_MAP[s.provider] || { needsInvert: false };
        return {
          id: s.provider,
          label: s.displayName,
          count: s.files.length,
          icon: iconInfo.path,
          iconNeedsInvert: iconInfo.needsInvert
        };
      });
  }, [sections]);

  useEffect(() => {
    if (filterItems.length > 0 && !filterItems.some(i => i.id === activeTab)) {
      setActiveTab(filterItems[0].id);
    }
  }, [filterItems, activeTab]);

  const displayedFiles = useMemo(() => {
    const section = sections.find(s => s.provider === activeTab);
    const files = section ? section.files : [];
    return sortFiles(files, sortMode);
  }, [sections, activeTab, sortMode]);

  const allFiles = useMemo(() => sections.flatMap(section => section.files), [sections]);

  const enabledFiles = useMemo(() => {
    return allFiles.filter(file => (
      !isAuthFileDisabled(file.originalFile) &&
      !zeroQuotaDisabledKeys[getFileKey(file)] &&
      !isInvalidTokenForCleanup(file) &&
      file.providerKey !== 'unknown'
    ));
  }, [allFiles, zeroQuotaDisabledKeys]);

  useEffect(() => {
    enabledFilesRef.current = enabledFiles;
    if (autoRefreshCursorRef.current >= enabledFiles.length) {
      autoRefreshCursorRef.current = 0;
    }
  }, [enabledFiles]);

  const unavailableFiles = useMemo(() => {
    return sections.flatMap(section => section.files).filter(isUnavailableForCleanup);
  }, [sections]);

  const zeroQuotaFiles = useMemo(() => {
    return sections.flatMap(section => section.files).filter(isZeroQuotaForDisable);
  }, [sections]);

  const zeroQuotaDisabledFiles = useMemo(() => {
    return allFiles.filter(file => isAuthFileDisabled(file.originalFile) && Boolean(zeroQuotaDisabledKeys[getFileKey(file)]));
  }, [allFiles, zeroQuotaDisabledKeys]);

  const watchQuotaFiles = useMemo(() => {
    return enabledFiles.filter(file => getQuotaHealthStatus(file) === 'watch');
  }, [enabledFiles]);

  const lowQuotaFiles = useMemo(() => {
    return enabledFiles.filter(file => getQuotaHealthStatus(file) === 'low');
  }, [enabledFiles]);

  const invalidTokenFiles = useMemo(() => {
    return sections.flatMap(section => section.files).filter(isInvalidTokenForCleanup);
  }, [sections]);

  const refreshDisplayed = useCallback(() => {
    if (!canWriteSelectedNode) {
      toast.error(t('quota.nodeRequired', '请选择已启用的 CPA 节点'));
      return;
    }

    const targets = displayedFiles.filter(file => (
      !isAuthFileDisabled(file.originalFile) &&
      !zeroQuotaDisabledKeys[getFileKey(file)] &&
      !isInvalidTokenForCleanup(file) &&
      file.providerKey !== 'unknown'
    ));

    if (targets.length === 0) {
      toast.info('当前列表没有需要刷新的账号');
      return;
    }

    setLoading(true);
    void runWithConcurrency(targets, MANUAL_REFRESH_CONCURRENCY, async (file) => {
      await fetchQuotaForFile(file.fileId, file.originalFile, { force: true });
    }).then((failures) => {
      if (failures.length > 0) {
        toast.error(`刷新完成，${failures.length} 个账号失败`);
        return;
      }
      toast.success(`已刷新 ${targets.length} 个账号`);
    }).finally(() => {
      setLoading(false);
    });
  }, [canWriteSelectedNode, displayedFiles, fetchQuotaForFile, t, zeroQuotaDisabledKeys]);

  useEffect(() => {
    if (!isAuthenticated) return;

    const intervalId = window.setInterval(() => {
      if (silentRefreshInFlightRef.current) return;

      const files = enabledFilesRef.current.filter(file => !isAuthFileDisabled(file.originalFile));
      if (files.length === 0) return;

      const start = autoRefreshCursorRef.current % files.length;
      const scanCount = Math.min(files.length, AUTO_REFRESH_BATCH_SIZE * 3);
      const candidates = Array.from({ length: scanCount }, (_, offset) => {
        return files[(start + offset) % files.length];
      });
      const batch = candidates.filter((file) => {
        const accountKey = getAuthFileKey(file.originalFile, file.fileId.split('::').pop() || file.fileId);
        return !isQuotaCacheFreshEnough(
          quotaCacheRef.current,
          file.nodeId || String(file.originalFile?.__nodeId || activeNode?.id || ''),
          accountKey,
          file.providerKey,
          AUTO_REFRESH_MIN_CACHE_AGE_MS,
        );
      }).slice(0, AUTO_REFRESH_BATCH_SIZE);

      autoRefreshCursorRef.current = (start + scanCount) % files.length;
      if (batch.length === 0) return;

      silentRefreshInFlightRef.current = true;
      runWithConcurrency(batch, AUTO_REFRESH_CONCURRENCY, async (file) => {
        await fetchQuotaForFile(file.fileId, file.originalFile, { silent: true, force: true });
      }).finally(() => {
        silentRefreshInFlightRef.current = false;
      });
    }, AUTO_REFRESH_INTERVAL_MS);

    return () => window.clearInterval(intervalId);
  }, [activeNode, fetchQuotaForFile, isAuthenticated]);

  const uploadAuthFiles = useCallback(async () => {
    if (!canWriteSelectedNode || !nodeConfig) {
      toast.error(t('quota.nodeRequired', '请选择已启用的 CPA 节点'));
      return;
    }

    setUploadingAuthFiles(true);

    try {
      const { open } = await import('@tauri-apps/plugin-dialog');
      const { readTextFile } = await import('@tauri-apps/plugin-fs');
      const { basename } = await import('@tauri-apps/api/path');

      const selectedPaths = await open({
        multiple: true,
        filters: [{ name: 'JSON', extensions: ['json'] }],
      });

      if (!selectedPaths) return;

      const paths = Array.isArray(selectedPaths) ? selectedPaths : [selectedPaths];
      if (paths.length === 0) return;

      let uploadCount = 0;
      for (const path of paths) {
        try {
          const content = await readTextFile(path);
          const name = await basename(path);
          const blob = new Blob([content], { type: 'application/json' });
          const formData = new FormData();
          formData.append('file', blob, name);

          await authFilesApi.upload(formData, nodeConfig);
          uploadCount++;
        } catch (err) {
          console.error('Failed to upload auth file:', path, err);
        }
      }

      if (uploadCount > 0) {
        toast.success(t('quota.uploadSuccess', 'Auth files imported successfully'));
        await loadAuthFiles();
      } else {
        toast.error(t('quota.uploadFailed', 'Failed to import auth files'));
      }
    } catch (err) {
      toast.error(`${t('quota.uploadFailed', 'Failed to import auth files')}: ${(err as Error).message}`);
    } finally {
      setUploadingAuthFiles(false);
    }
  }, [canWriteSelectedNode, loadAuthFiles, nodeConfig, t]);

  const deleteAuthFile = useCallback(async (name: string) => {
    if (!name) return;
    if (!nodeConfig) {
      toast.error(t('quota.nodeRequired', '请选择已启用的 CPA 节点'));
      return;
    }

    try {
      await authFilesApi.deleteFile(name, nodeConfig);
      toast.success(t('quota.deleteSuccess', 'Auth file deleted'));
      await loadAuthFiles();
    } catch (err) {
      toast.error(`${t('quota.deleteFailed', 'Failed to delete auth file')}: ${(err as Error).message}`);
    }
  }, [loadAuthFiles, nodeConfig, t]);

  const deleteUnavailableAuthFiles = useCallback(async () => {
    if (!nodeConfig) {
      toast.error(t('quota.nodeRequired', '请选择已启用的 CPA 节点'));
      return;
    }

    const targets = unavailableFiles
      .map(getAuthFileDeleteName)
      .filter((name): name is string => Boolean(name));

    if (targets.length === 0) {
      toast.info(t('quota.noUnavailableFiles', 'No unavailable auth files to delete'));
      return;
    }

    setDeletingUnavailableFiles(true);

    let deletedCount = 0;
    try {
      for (const name of targets) {
        try {
          await authFilesApi.deleteFile(name, nodeConfig);
          deletedCount++;
        } catch (err) {
          console.error('Failed to delete unavailable auth file:', name, err);
        }
      }

      if (deletedCount > 0) {
        toast.success(t('quota.deleteUnavailableSuccess', 'Deleted {{count}} unavailable auth files', { count: deletedCount }));
        await loadAuthFiles();
      } else {
        toast.error(t('quota.deleteUnavailableFailed', 'Failed to delete unavailable auth files'));
      }
    } finally {
      setDeletingUnavailableFiles(false);
    }
  }, [loadAuthFiles, nodeConfig, t, unavailableFiles]);

  const deleteInvalidTokenAuthFiles = useCallback(async () => {
    if (!nodeConfig) {
      toast.error(t('quota.nodeRequired', '请选择已启用的 CPA 节点'));
      return;
    }

    const targets = invalidTokenFiles
      .map(getAuthFileDeleteName)
      .filter((name): name is string => Boolean(name));

    if (targets.length === 0) {
      toast.info(t('quota.noInvalidTokenFiles', 'No 401/token-invalid accounts to delete'));
      return;
    }

    setDeletingInvalidTokenFiles(true);

    let deletedCount = 0;
    try {
      for (const name of targets) {
        try {
          await authFilesApi.deleteFile(name, nodeConfig);
          deletedCount++;
        } catch (err) {
          console.error('Failed to delete 401 auth file:', name, err);
        }
      }

      if (deletedCount > 0) {
        toast.success(t('quota.deleteInvalidTokenSuccess', 'Deleted {{count}} 401/token-invalid accounts', { count: deletedCount }));
        await loadAuthFiles();
      } else {
        toast.error(t('quota.deleteInvalidTokenFailed', 'Failed to delete 401/token-invalid accounts'));
      }
    } finally {
      setDeletingInvalidTokenFiles(false);
    }
  }, [invalidTokenFiles, loadAuthFiles, nodeConfig, t]);

  const updateAuthFileDisabled = useCallback(async (file: FileQuota, disabled: boolean) => {
    const name = getAuthFileStorageName(file);
    if (!name) return;

    const fileNodeConfig = getNodeConfigForFile(file);
    if (!fileNodeConfig) throw new Error('No enabled CPA node selected');

    const data = await authFilesApi.download(name, fileNodeConfig);
    const content = typeof data === 'string' ? JSON.parse(data) : data;

    if (!content || typeof content !== 'object' || Array.isArray(content)) {
      throw new Error('Invalid auth file content');
    }

    const updated = {
      ...(content as Record<string, unknown>),
      disabled,
    };
    const blob = new Blob([JSON.stringify(updated, null, 2)], { type: 'application/json' });
    const createFormData = () => {
      const formData = new FormData();
      formData.append('file', blob, name);
      return formData;
    };

    await authFilesApi.upload(createFormData(), fileNodeConfig);

    const verifyData = await authFilesApi.download(name, fileNodeConfig);
    const verifyContent = typeof verifyData === 'string' ? JSON.parse(verifyData) : verifyData;
    if (isAuthFileDisabled(verifyContent as AuthFile) === disabled) return;

    await authFilesApi.deleteFile(name, fileNodeConfig);
    await authFilesApi.upload(createFormData(), fileNodeConfig);
  }, [getNodeConfigForFile]);

  const applyDisabledStateLocally = useCallback((updates: Map<string, boolean>) => {
    setSections(prev => prev.map(section => ({
      ...section,
      files: section.files.map(file => {
        const disabled = updates.get(file.fileId);
        if (disabled === undefined) return file;

        return {
          ...file,
          loading: false,
          error: undefined,
          models: file.models,
          limits: file.limits,
          originalFile: file.originalFile
            ? { ...file.originalFile, disabled }
            : file.originalFile,
        };
      }),
    })));
  }, []);

  const toggleAuthFileDisabled = useCallback(async (file: FileQuota, disabled: boolean) => {
    setUpdatingDisabledFileIds(prev => ({ ...prev, [file.fileId]: true }));

    try {
      await updateAuthFileDisabled(file, disabled);
      setDisabledOverrides(prev => ({ ...prev, [getFileKey(file)]: disabled }));
      if (!disabled) {
        setZeroQuotaDisabledKeys(prev => {
          const next = { ...prev };
          next[getFileKey(file)] = false;
          return next;
        });
      }
      applyDisabledStateLocally(new Map([[file.fileId, disabled]]));
      toast.success(disabled
        ? t('quota.disableSuccess', 'Account disabled')
        : t('quota.enableSuccess', 'Account enabled')
      );
      if (!disabled) {
        window.setTimeout(() => fetchQuotaForFile(file.fileId, { ...file.originalFile, disabled: false } as AuthFile), 0);
      }
    } catch (err) {
      toast.error(`${t('quota.toggleDisabledFailed', 'Failed to update account status')}: ${(err as Error).message}`);
    } finally {
      setUpdatingDisabledFileIds(prev => {
        const next = { ...prev };
        delete next[file.fileId];
        return next;
      });
    }
  }, [applyDisabledStateLocally, fetchQuotaForFile, t, updateAuthFileDisabled]);

  const enableAllAuthFiles = useCallback(async () => {
    const targets = allFiles.filter(file => isAuthFileDisabled(file.originalFile));
    if (targets.length === 0) {
      toast.info(t('quota.noDisabledAccounts', 'No disabled accounts'));
      return;
    }

    setBulkUpdatingDisabledFiles(true);
    setUpdatingDisabledFileIds(prev => {
      const next = { ...prev };
      targets.forEach(file => {
        next[file.fileId] = true;
      });
      return next;
    });

    try {
      const failures = await runWithConcurrency(targets, 8, file => updateAuthFileDisabled(file, false));
      const successCount = targets.length - failures.length;

      failures.forEach(({ item, error }) => {
        console.error('Failed to enable auth file:', item.fileId, error);
      });

      if (successCount > 0) {
        const successfulFiles = targets.filter(file => !failures.some(({ item }) => item.fileId === file.fileId));
        setDisabledOverrides(prev => {
          const next = { ...prev };
          successfulFiles.forEach(file => {
            next[getFileKey(file)] = false;
          });
          return next;
        });
        setZeroQuotaDisabledKeys(prev => {
          const next = { ...prev };
          successfulFiles.forEach(file => {
            next[getFileKey(file)] = false;
          });
          return next;
        });
        applyDisabledStateLocally(new Map(
          successfulFiles
            .map(file => [file.fileId, false])
        ));
        toast.success(t('quota.enableAllSuccess', 'Enabled {{count}} accounts', { count: successCount }));
        successfulFiles.forEach(file => {
          window.setTimeout(() => fetchQuotaForFile(file.fileId, { ...file.originalFile, disabled: false } as AuthFile), 0);
        });
      } else {
        toast.error(t('quota.toggleDisabledFailed', 'Failed to update account status'));
      }
    } finally {
      setBulkUpdatingDisabledFiles(false);
      setUpdatingDisabledFileIds(prev => {
        const next = { ...prev };
        targets.forEach(file => {
          delete next[file.fileId];
        });
        return next;
      });
    }
  }, [allFiles, applyDisabledStateLocally, fetchQuotaForFile, t, updateAuthFileDisabled]);

  const disableAllButBestAuthFile = useCallback(async () => {
    if (enabledFiles.length <= 1) {
      toast.info(t('quota.needAtLeastTwoAccounts', 'At least two accounts are required'));
      return;
    }

    const [bestFile] = [...enabledFiles].sort(compareBestQuotaFile);
    if (!bestFile) return;

    const targets = enabledFiles.filter(file => {
      const shouldDisable = file.fileId !== bestFile.fileId;
      return isAuthFileDisabled(file.originalFile) !== shouldDisable;
    });
    if (targets.length === 0) {
      toast.info(t('quota.disableAllNoChange', 'Only the best account is enabled already'));
      return;
    }

    setBulkUpdatingDisabledFiles(true);
    setUpdatingDisabledFileIds(prev => {
      const next = { ...prev };
      targets.forEach(file => {
        next[file.fileId] = true;
      });
      return next;
    });

    try {
      const failures = await runWithConcurrency(targets, 8, file => {
        const shouldDisable = file.fileId !== bestFile.fileId;
        return updateAuthFileDisabled(file, shouldDisable);
      });
      const successCount = targets.length - failures.length;

      failures.forEach(({ item, error }) => {
        console.error('Failed to update auth file disabled status:', item.fileId, error);
      });

      if (successCount > 0) {
        const successfulFiles = targets.filter(file => !failures.some(({ item }) => item.fileId === file.fileId));
        setDisabledOverrides(prev => {
          const next = { ...prev };
          successfulFiles.forEach(file => {
            next[getFileKey(file)] = file.fileId !== bestFile.fileId;
          });
          return next;
        });
        applyDisabledStateLocally(new Map(
          successfulFiles
            .map(file => [file.fileId, file.fileId !== bestFile.fileId])
        ));
        toast.success(t('quota.disableAllSuccess', 'Disabled accounts and kept the highest quota account enabled'));
        window.setTimeout(() => fetchQuotaForFile(bestFile.fileId, { ...bestFile.originalFile, disabled: false } as AuthFile), 0);
      } else {
        toast.error(t('quota.toggleDisabledFailed', 'Failed to update account status'));
      }
    } finally {
      setBulkUpdatingDisabledFiles(false);
      setUpdatingDisabledFileIds(prev => {
        const next = { ...prev };
        targets.forEach(file => {
          delete next[file.fileId];
        });
        return next;
      });
    }
  }, [applyDisabledStateLocally, enabledFiles, fetchQuotaForFile, t, updateAuthFileDisabled]);

  const disableZeroQuotaAuthFiles = useCallback(async () => {
    const targets = zeroQuotaFiles;
    if (targets.length === 0) {
      toast.info(t('quota.noZeroQuotaAccounts', 'No 0% quota accounts to disable'));
      return;
    }

    setBulkUpdatingDisabledFiles(true);
    setUpdatingDisabledFileIds(prev => {
      const next = { ...prev };
      targets.forEach(file => {
        next[file.fileId] = true;
      });
      return next;
    });

    try {
      const failures = await runWithConcurrency(targets, 8, file => updateAuthFileDisabled(file, true));
      const successCount = targets.length - failures.length;

      failures.forEach(({ item, error }) => {
        console.error('Failed to disable zero quota auth file:', item.fileId, error);
      });

      if (successCount > 0) {
        const successfulFiles = targets.filter(file => !failures.some(({ item }) => item.fileId === file.fileId));
        setDisabledOverrides(prev => {
          const next = { ...prev };
          successfulFiles.forEach(file => {
            next[getFileKey(file)] = true;
          });
          return next;
        });
        setZeroQuotaDisabledKeys(prev => {
          const next = { ...prev };
          successfulFiles.forEach(file => {
            next[getFileKey(file)] = true;
          });
          return next;
        });

        const nextZeroedAtTimes = Object.fromEntries(
          Object.entries(loadStoredRecord(ZERO_QUOTA_ZEROED_AT_STORAGE_KEY))
            .filter((entry): entry is [string, string] => typeof entry[1] === 'string')
        );
        const zeroedIso = new Date().toISOString();
        successfulFiles.forEach(file => {
          const key = getFileKey(file);
          if (!nextZeroedAtTimes[key]) {
            nextZeroedAtTimes[key] = zeroedIso;
          }
        });
        saveStoredRecord(ZERO_QUOTA_ZEROED_AT_STORAGE_KEY, nextZeroedAtTimes);

        applyDisabledStateLocally(new Map(
          successfulFiles.map(file => [file.fileId, true])
        ));
        toast.success(t('quota.disableZeroQuotaSuccess', 'Disabled {{count}} 0% quota accounts', { count: successCount }));
      } else {
        toast.error(t('quota.toggleDisabledFailed', 'Failed to update account status'));
      }
    } finally {
      setBulkUpdatingDisabledFiles(false);
      setUpdatingDisabledFileIds(prev => {
        const next = { ...prev };
        targets.forEach(file => {
          delete next[file.fileId];
        });
        return next;
      });
    }
  }, [applyDisabledStateLocally, t, updateAuthFileDisabled, zeroQuotaFiles]);

  const enableZeroQuotaAuthFiles = useCallback(async () => {
    const targets = zeroQuotaDisabledFiles;
    if (targets.length === 0) {
      toast.info(t('quota.noZeroQuotaDisabledAccounts', 'No disabled 0% quota accounts to enable'));
      return;
    }

    setBulkUpdatingDisabledFiles(true);
    setUpdatingDisabledFileIds(prev => {
      const next = { ...prev };
      targets.forEach(file => {
        next[file.fileId] = true;
      });
      return next;
    });

    try {
      const failures = await runWithConcurrency(targets, 8, file => updateAuthFileDisabled(file, false));
      const successCount = targets.length - failures.length;

      failures.forEach(({ item, error }) => {
        console.error('Failed to enable zero quota auth file:', item.fileId, error);
      });

      if (successCount > 0) {
        const successfulFiles = targets.filter(file => !failures.some(({ item }) => item.fileId === file.fileId));
        setDisabledOverrides(prev => {
          const next = { ...prev };
          successfulFiles.forEach(file => {
            next[getFileKey(file)] = false;
          });
          return next;
        });
        setZeroQuotaDisabledKeys(prev => {
          const next = { ...prev };
          successfulFiles.forEach(file => {
            next[getFileKey(file)] = false;
          });
          return next;
        });
        applyDisabledStateLocally(new Map(successfulFiles.map(file => [file.fileId, false])));
        toast.success(t('quota.enableZeroQuotaSuccess', 'Enabled {{count}} zero quota accounts', { count: successCount }));
        successfulFiles.forEach(file => {
          window.setTimeout(() => fetchQuotaForFile(file.fileId, { ...file.originalFile, disabled: false } as AuthFile), 0);
        });
      } else {
        toast.error(t('quota.toggleDisabledFailed', 'Failed to update account status'));
      }
    } finally {
      setBulkUpdatingDisabledFiles(false);
      setUpdatingDisabledFileIds(prev => {
        const next = { ...prev };
        targets.forEach(file => {
          delete next[file.fileId];
        });
        return next;
      });
    }
  }, [applyDisabledStateLocally, fetchQuotaForFile, t, updateAuthFileDisabled, zeroQuotaDisabledFiles]);

  const applyPreferredQuotaStatus = useCallback(async (status: Extract<QuotaHealthStatus, 'watch' | 'low'>) => {
    const targetFiles = enabledFiles.filter(file => getQuotaHealthStatus(file) === status);
    if (targetFiles.length === 0) {
      toast.info(status === 'low'
        ? t('quota.noLowQuotaAccounts', 'No low quota accounts loaded')
        : t('quota.noWatchQuotaAccounts', 'No watch quota accounts loaded')
      );
      return;
    }

    const targetIds = new Set(targetFiles.map(file => file.fileId));
    const targets = enabledFiles.filter(file => {
      const shouldDisable = !targetIds.has(file.fileId);
      return isAuthFileDisabled(file.originalFile) !== shouldDisable;
    });

    if (targets.length === 0) {
      toast.info(status === 'low'
        ? t('quota.preferLowNoChange', 'Low quota accounts are already preferred')
        : t('quota.preferWatchNoChange', 'Watch quota accounts are already preferred')
      );
      return;
    }

    setBulkUpdatingDisabledFiles(true);
    setUpdatingDisabledFileIds(prev => {
      const next = { ...prev };
      targets.forEach(file => {
        next[file.fileId] = true;
      });
      return next;
    });

    try {
      const failures = await runWithConcurrency(targets, 8, file => updateAuthFileDisabled(file, !targetIds.has(file.fileId)));
      const successfulFiles = targets.filter(file => !failures.some(({ item }) => item.fileId === file.fileId));
      const successCount = successfulFiles.length;

      failures.forEach(({ item, error }) => {
        console.error('Failed to apply preferred quota status:', status, item.fileId, error);
      });

      if (successCount > 0) {
        setDisabledOverrides(prev => {
          const next = { ...prev };
          successfulFiles.forEach(file => {
            next[getFileKey(file)] = !targetIds.has(file.fileId);
          });
          return next;
        });
        setZeroQuotaDisabledKeys(prev => {
          const next = { ...prev };
          successfulFiles.forEach(file => {
            if (targetIds.has(file.fileId)) next[getFileKey(file)] = false;
          });
          return next;
        });
        applyDisabledStateLocally(new Map(successfulFiles.map(file => [file.fileId, !targetIds.has(file.fileId)])));
        toast.success(status === 'low'
          ? t('quota.preferLowSuccess', 'Low quota accounts are now preferred')
          : t('quota.preferWatchSuccess', 'Watch quota accounts are now preferred')
        );
        successfulFiles
          .filter(file => targetIds.has(file.fileId))
          .forEach(file => {
            window.setTimeout(() => fetchQuotaForFile(file.fileId, { ...file.originalFile, disabled: false } as AuthFile), 0);
          });
      } else {
        toast.error(t('quota.toggleDisabledFailed', 'Failed to update account status'));
      }
    } finally {
      setBulkUpdatingDisabledFiles(false);
      setUpdatingDisabledFileIds(prev => {
        const next = { ...prev };
        targets.forEach(file => {
          delete next[file.fileId];
        });
        return next;
      });
    }
  }, [applyDisabledStateLocally, enabledFiles, fetchQuotaForFile, t, updateAuthFileDisabled]);

  const preferLowQuotaAuthFiles = useCallback(() => {
    void applyPreferredQuotaStatus('low');
  }, [applyPreferredQuotaStatus]);

  const preferWatchQuotaAuthFiles = useCallback(() => {
    void applyPreferredQuotaStatus('watch');
  }, [applyPreferredQuotaStatus]);

  const togglePrivacyMode = useCallback(() => {
    setIsPrivacyMode(prev => !prev);
  }, []);

  return {
    isAuthenticated,
    sections,
    loading,
    error,
    activeTab,
    setActiveTab,
    viewMode,
    setViewMode,
    sortMode,
    setSortMode,
    isPrivacyMode,
    togglePrivacyMode,
    uploadingAuthFiles,
    uploadAuthFiles,
    deleteAuthFile,
    deletingUnavailableFiles,
    deleteUnavailableAuthFiles,
    unavailableFileCount: unavailableFiles.length,
    deletingInvalidTokenFiles,
    deleteInvalidTokenAuthFiles,
    invalidTokenFileCount: invalidTokenFiles.length,
    disableZeroQuotaAuthFiles,
    zeroQuotaFileCount: zeroQuotaFiles.length,
    enableZeroQuotaAuthFiles,
    zeroQuotaDisabledFileCount: zeroQuotaDisabledFiles.length,
    preferLowQuotaAuthFiles,
    preferWatchQuotaAuthFiles,
    lowQuotaFileCount: lowQuotaFiles.length,
    watchQuotaFileCount: watchQuotaFiles.length,
    updatingDisabledFileIds,
    bulkUpdatingDisabledFiles,
    toggleAuthFileDisabled,
    enableAllAuthFiles,
    disableAllButBestAuthFile,
    isAuthFileDisabled,
    filterItems,
    displayedFiles,
    refreshDisplayed,
    fetchQuotaForFile,
    nodeOptions,
    activeNodeId,
    activeNodeName,
    setActiveNodeId: setSelectedNode,
    canWriteSelectedNode,
  };
}



