import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { AlertTriangle, BarChart3, CheckCircle2, Clock3, Layers3, XCircle, Users } from 'lucide-react';
import { Card, CardContent } from '@/shared/components/ui/card';
import { Badge } from '@/shared/components/ui/badge';
import type { FileQuota, ProviderSection, QuotaModel } from '@/types';

const QUOTA_HISTORY_STORAGE_KEY = 'zerolimit.quota.summaryHistory.v3';
const QUOTA_HISTORY_WINDOW_MS = 60 * 60 * 1000;
const MIN_ESTIMATE_OBSERVATION_MS = 60 * 1000;
const MIN_ESTIMATE_SEGMENT_MS = 60 * 1000;
const MIN_ESTIMATE_DROP_PERCENT = 0.1;
const MAX_REASONABLE_PERCENT_PER_HOUR = 50;

interface QuotaHistoryPoint {
  timestamp: number;
  average: number;
  accountCount: number;
  itemCount: number;
}

interface QuotaSummaryCardProps {
  sections: ProviderSection[];
}

type HealthStatus = 'healthy' | 'watch' | 'low' | 'pending' | 'serviceError' | 'unavailable';

interface HealthGroup {
  status: HealthStatus;
  count: number;
  percentage: number;
}

function clampPercentage(value: number) {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, value));
}

function formatWholePercent(value: number) {
  return `${Math.round(clampPercentage(value))}%`;
}

function getQuotaItems(file: FileQuota): QuotaModel[] {
  return (file.models || file.limits || []).filter(item => Number.isFinite(item.percentage));
}

function isAuthFileDisabled(file: FileQuota): boolean {
  const value = file.originalFile?.disabled ?? file.originalFile?.is_disabled ?? file.originalFile?.isDisabled;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value === 1;
  if (typeof value === 'string') {
    return ['true', '1', 'yes', 'on'].includes(value.trim().toLowerCase());
  }
  return false;
}

function getProgressTone(percentage: number) {
  if (percentage > 50) return 'bg-emerald-500';
  if (percentage > 20) return 'bg-amber-500';
  return 'bg-red-500';
}

function getAccountAverage(file: FileQuota) {
  const items = getQuotaItems(file);
  if (items.length === 0) return null;
  return clampPercentage(items.reduce((sum, item) => sum + clampPercentage(item.percentage), 0) / items.length);
}

function isTransientQuotaError(error?: string): boolean {
  const text = (error || '').toLowerCase();
  if (!text) return false;
  if (text.includes('401') || text.includes('unauthorized') || text.includes('invalidated oauth')) return false;
  if (text.includes('403') || text.includes('access denied')) return false;

  return (
    text.includes('429') ||
    text.includes('500') ||
    text.includes('502') ||
    text.includes('503') ||
    text.includes('504') ||
    text.includes('service unavailable') ||
    text.includes('server had an error') ||
    text.includes('server error') ||
    text.includes('bad gateway') ||
    text.includes('gateway timeout') ||
    text.includes('timeout') ||
    text.includes('network') ||
    text.includes('temporarily') ||
    text.includes('try again') ||
    text.includes('rate limit') ||
    text.includes('upstream') ||
    text.includes('overloaded')
  );
}

function loadQuotaHistory(): QuotaHistoryPoint[] {
  try {
    const raw = window.localStorage.getItem(QUOTA_HISTORY_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed)
      ? parsed.filter((item): item is QuotaHistoryPoint => (
        Number.isFinite(item?.timestamp) &&
        Number.isFinite(item?.average) &&
        Number.isFinite(item?.accountCount) &&
        Number.isFinite(item?.itemCount)
      ))
      : [];
  } catch {
    return [];
  }
}

function saveQuotaHistory(points: QuotaHistoryPoint[]) {
  try {
    window.localStorage.setItem(QUOTA_HISTORY_STORAGE_KEY, JSON.stringify(points));
  } catch {
    // Ignore storage failures; the estimate can rebuild from future refreshes.
  }
}

function formatDuration(ms: number): string {
  if (!Number.isFinite(ms) || ms <= 0) return '--';
  const hours = ms / 3600000;
  if (hours < 1) return `${Math.max(1, Math.round(hours * 60))} 分钟`;
  if (hours < 24) return `${hours.toFixed(hours >= 10 ? 0 : 1)} 小时`;
  return `${(hours / 24).toFixed(hours >= 240 ? 0 : 1)} 天`;
}

function formatFinishTime(timestamp: number): string {
  if (!Number.isFinite(timestamp)) return '--';
  return new Date(timestamp).toLocaleString('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).replace(/\//g, '-');
}

function buildHistoryPoint(summary: { average: number; accountCount: number; itemCount: number }, timestamp: number): QuotaHistoryPoint {
  return {
    timestamp,
    average: summary.average,
    accountCount: summary.accountCount,
    itemCount: summary.itemCount,
  };
}

function calculateQuotaEstimate(history: QuotaHistoryPoint[], current: QuotaHistoryPoint) {
  const recent = [...history, current]
    .filter(point => current.timestamp - point.timestamp <= QUOTA_HISTORY_WINDOW_MS)
    .sort((a, b) => a.timestamp - b.timestamp);

  if (recent.length < 2) return null;

  const stableRun: QuotaHistoryPoint[] = [recent[recent.length - 1]];
  for (let index = recent.length - 2; index >= 0; index -= 1) {
    const point = recent[index];
    if (point.accountCount !== current.accountCount || point.itemCount !== current.itemCount) break;
    stableRun.unshift(point);
  }

  if (stableRun.length < 2) return null;

  const first = stableRun[0];
  const observedMs = current.timestamp - first.timestamp;
  if (observedMs < MIN_ESTIMATE_OBSERVATION_MS) return null;

  for (let index = 1; index < stableRun.length; index += 1) {
    const previous = stableRun[index - 1];
    const next = stableRun[index];
    const elapsed = next.timestamp - previous.timestamp;
    const segmentDrop = previous.average - next.average;
    if (elapsed < MIN_ESTIMATE_SEGMENT_MS || segmentDrop <= 0) continue;

    const segmentRate = segmentDrop / (elapsed / 3600000);
    if (segmentRate > MAX_REASONABLE_PERCENT_PER_HOUR) return null;
  }

  const drop = first.average - current.average;
  if (drop < MIN_ESTIMATE_DROP_PERCENT) return null;

  const hours = observedMs / 3600000;
  if (hours <= 0) return null;

  const percentPerHour = drop / hours;
  if (percentPerHour <= 0 || percentPerHour > MAX_REASONABLE_PERCENT_PER_HOUR) return null;

  const remainingMs = current.average / percentPerHour * 3600000;
  return {
    remainingLabel: formatDuration(remainingMs),
    finishLabel: formatFinishTime(current.timestamp + remainingMs),
    rateLabel: `${percentPerHour.toFixed(percentPerHour >= 1 ? 1 : 2)}%/小时`,
  };
}

function getHealthStatus(file: FileQuota): HealthStatus {
  if (file.loading || file.quotaChecked === false) return 'pending';
  if (isTransientQuotaError(file.error)) return 'serviceError';
  if (file.error || file.plan?.toLowerCase() === 'suspended') return 'unavailable';

  const average = getAccountAverage(file);
  if (average === null) return 'unavailable';
  if (average > 50) return 'healthy';
  if (average > 20) return 'watch';
  return 'low';
}

function summarizeHealth(files: FileQuota[]): HealthGroup[] {
  const total = Math.max(files.length, 1);
  const counts: Record<HealthStatus, number> = {
    healthy: 0,
    watch: 0,
    low: 0,
    pending: 0,
    serviceError: 0,
    unavailable: 0,
  };

  files.forEach(file => {
    counts[getHealthStatus(file)]++;
  });

  return (Object.entries(counts) as Array<[HealthStatus, number]>).map(([status, count]) => ({
    status,
    count,
    percentage: clampPercentage((count / total) * 100),
  }));
}

function getHealthMeta(status: HealthStatus, t: ReturnType<typeof useTranslation>['t']) {
  const meta = {
    healthy: {
      label: t('quotaSummary.healthy', { defaultValue: 'Healthy' }),
      description: t('quotaSummary.healthyDesc', { defaultValue: '>50% remaining' }),
      icon: CheckCircle2,
      tone: 'bg-emerald-500',
      iconTone: 'text-emerald-600',
    },
    watch: {
      label: t('quotaSummary.watch', { defaultValue: 'Watch' }),
      description: t('quotaSummary.watchDesc', { defaultValue: '21-50% remaining' }),
      icon: AlertTriangle,
      tone: 'bg-amber-500',
      iconTone: 'text-amber-600',
    },
    low: {
      label: t('quotaSummary.low', { defaultValue: 'Low quota' }),
      description: t('quotaSummary.lowDesc', { defaultValue: '0-20% remaining' }),
      icon: AlertTriangle,
      tone: 'bg-red-500',
      iconTone: 'text-red-600',
    },
    pending: {
      label: t('quotaSummary.pending', { defaultValue: '刷新中' }),
      description: t('quotaSummary.pendingDesc', { defaultValue: '排队检查额度' }),
      icon: Clock3,
      tone: 'bg-sky-500',
      iconTone: 'text-sky-600',
    },
    serviceError: {
      label: t('quotaSummary.serviceError', { defaultValue: '服务异常' }),
      description: t('quotaSummary.serviceErrorDesc', { defaultValue: '503/500，稍后重试' }),
      icon: AlertTriangle,
      tone: 'bg-blue-500',
      iconTone: 'text-blue-600',
    },
    unavailable: {
      label: t('quotaSummary.unavailable', { defaultValue: 'Unavailable' }),
      description: t('quotaSummary.unavailableDesc', { defaultValue: 'Error or no quota data' }),
      icon: XCircle,
      tone: 'bg-zinc-500',
      iconTone: 'text-zinc-600',
    },
  };

  return meta[status];
}

export function QuotaSummaryCard({ sections }: QuotaSummaryCardProps) {
  const { t } = useTranslation();
  const [history, setHistory] = useState<QuotaHistoryPoint[]>(() => loadQuotaHistory());

  const summary = useMemo(() => {
    const allFiles = sections.flatMap(section => section.files);
    const enabledFiles = allFiles.filter(file => !isAuthFileDisabled(file));
    const filesWithQuota = enabledFiles.filter(file => !file.loading && !file.error && getQuotaItems(file).length > 0);
    const quotaItems = filesWithQuota.flatMap(getQuotaItems);
    const accountAverages = filesWithQuota
      .map(getAccountAverage)
      .filter((value): value is number => value !== null);
    const average = accountAverages.length
      ? clampPercentage(accountAverages.reduce((sum, value) => sum + value, 0) / accountAverages.length)
      : 0;

    return {
      average,
      accountCount: enabledFiles.length,
      itemCount: quotaItems.length,
      healthGroups: summarizeHealth(enabledFiles),
    };
  }, [sections]);

  const hasQuota = summary.itemCount > 0;
  const tone = getProgressTone(summary.average);
  const estimate = useMemo(() => {
    if (!hasQuota) return null;
    const now = Date.now();
    return calculateQuotaEstimate(history, buildHistoryPoint(summary, now));
  }, [hasQuota, history, summary]);

  useEffect(() => {
    if (!hasQuota) return;
    const now = Date.now();
    const nextPoint = buildHistoryPoint(summary, now);
    setHistory((prev) => {
      const last = prev.at(-1);
      const shouldAppend = !last
        || now - last.timestamp > 60 * 1000
        || Math.abs(last.average - summary.average) >= 0.01
        || last.accountCount !== summary.accountCount
        || last.itemCount !== summary.itemCount;

      if (!shouldAppend) return prev;

      const next = [...prev, nextPoint]
        .filter(point => now - point.timestamp <= 24 * 60 * 60 * 1000)
        .slice(-200);
      saveQuotaHistory(next);
      return next;
    });
  }, [hasQuota, summary.accountCount, summary.average, summary.itemCount]);

  return (
    <Card className="overflow-hidden border bg-card py-0">
      <CardContent className="space-y-4 p-5">
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="rounded-lg bg-primary/10 p-2 text-primary">
                <BarChart3 className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-lg font-semibold">
                  {t('quotaSummary.title', { defaultValue: 'Total Quota' })}
                </h2>
                <p className="text-sm text-muted-foreground">
                  {t('quotaSummary.description', {
                    defaultValue: 'Aggregated from all loaded credential quota percentages.',
                  })}
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary" className="gap-1.5 rounded-md px-2.5 py-1">
              <Users className="h-3.5 w-3.5" />
              {t('quotaSummary.accounts', {
                count: summary.accountCount,
                defaultValue: '{{count}} accounts',
              })}
            </Badge>
            <Badge variant="secondary" className="gap-1.5 rounded-md px-2.5 py-1">
              <Layers3 className="h-3.5 w-3.5" />
              {t('quotaSummary.items', {
                count: summary.itemCount,
                defaultValue: '{{count}} quota items',
              })}
            </Badge>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-end justify-between gap-4">
            <div>
              <div className="text-4xl font-bold tracking-tight">
                {hasQuota ? formatWholePercent(summary.average) : '--'}
              </div>
              <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                {t('quotaSummary.remaining', { defaultValue: 'estimated remaining' })}
              </div>
            </div>
            {!hasQuota && (
              <div className="pb-2 text-sm text-muted-foreground">
                {t('quotaSummary.waiting', { defaultValue: 'Refresh quotas to build the total.' })}
              </div>
            )}
          </div>

          <div className="h-3 w-full overflow-hidden rounded-full bg-secondary">
            <div
              className={`h-full rounded-full transition-all duration-500 ${tone}`}
              style={{ width: `${hasQuota ? summary.average : 0}%` }}
            />
          </div>
        </div>

        <div className="flex flex-col gap-3 rounded-lg border bg-muted/20 p-3 md:flex-row md:items-center md:justify-between">
          <div className="flex min-w-0 items-center gap-2">
            <Clock3 className="h-4 w-4 shrink-0 text-muted-foreground" />
            <div className="min-w-0">
              <div className="text-sm font-medium">预计用完</div>
              <div className="truncate text-xs text-muted-foreground">
                依据近 1 小时真实下降速度估算；刚导入、启停账号或额度未下降时不会硬算。
              </div>
            </div>
          </div>
          <div className="shrink-0 text-left md:text-right">
            <div className="text-lg font-semibold">{estimate?.remainingLabel ?? '--'}</div>
            <div className="text-xs text-muted-foreground">
              {estimate ? `${estimate.finishLabel} · ${estimate.rateLabel}` : '数据不足或近 1 小时未下降'}
            </div>
          </div>
        </div>

        {summary.healthGroups.length > 0 && (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-6">
            {summary.healthGroups.map(group => {
              const meta = getHealthMeta(group.status, t);
              const Icon = meta.icon;

              return (
              <div key={group.status} className="space-y-2 rounded-lg border bg-muted/20 p-3">
                <div className="flex items-center justify-between gap-2 text-sm">
                  <span className="flex min-w-0 items-center gap-1.5 truncate font-medium" title={meta.label}>
                    <Icon className={`h-3.5 w-3.5 shrink-0 ${meta.iconTone}`} />
                    <span className="truncate">{meta.label}</span>
                  </span>
                  <span className="font-semibold">{group.count}</span>
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${meta.tone}`}
                    style={{ width: `${group.percentage}%` }}
                  />
                </div>
                <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
                  <span className="truncate">{meta.description}</span>
                  <span>{formatWholePercent(group.percentage)}</span>
                </div>
              </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
