#!/usr/bin/env node
import http from 'node:http';
import os from 'node:os';
import crypto from 'node:crypto';
import { readFileSync } from 'node:fs';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);

const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '0.0.0.0';
const MONITOR_TOKEN = process.env.MONITOR_TOKEN || '';
const DINGTALK_WEBHOOK = process.env.DINGTALK_WEBHOOK || '';
const DINGTALK_SECRET = process.env.DINGTALK_SECRET || '';
const DINGTALK_CALLBACK_TOKEN = process.env.DINGTALK_CALLBACK_TOKEN || '';
const ZEROLIMIT_API_BASE = process.env.ZEROLIMIT_API_BASE || '';
const ZEROLIMIT_MANAGEMENT_KEY = process.env.ZEROLIMIT_MANAGEMENT_KEY || '';
const SERVICE_CHECKS = process.env.SERVICE_CHECKS || '';

let previousCpu = readCpuSnapshot();
let previousNetwork = readNetworkSnapshot();

function json(res, statusCode, payload) {
  res.writeHead(statusCode, {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json; charset=utf-8',
  });
  res.end(JSON.stringify(payload));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1024 * 1024) {
        req.destroy();
        reject(new Error('Request body too large'));
      }
    });
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

function getBearerToken(reqUrl, req) {
  const auth = req.headers.authorization || '';
  if (auth.toLowerCase().startsWith('bearer ')) {
    return auth.slice(7).trim();
  }
  return reqUrl.searchParams.get('token') || '';
}

function requireMonitorAuth(reqUrl, req, res) {
  if (!MONITOR_TOKEN) return true;
  if (getBearerToken(reqUrl, req) === MONITOR_TOKEN) return true;
  json(res, 401, { ok: false, message: 'Unauthorized' });
  return false;
}

function requireCallbackAuth(reqUrl, res) {
  if (!DINGTALK_CALLBACK_TOKEN) return true;
  if (reqUrl.searchParams.get('token') === DINGTALK_CALLBACK_TOKEN) return true;
  json(res, 401, { ok: false, message: 'Unauthorized callback' });
  return false;
}

function readCpuSnapshot() {
  const cpus = os.cpus();
  const totals = cpus.reduce((acc, cpu) => {
    const idle = cpu.times.idle;
    const total = Object.values(cpu.times).reduce((sum, value) => sum + value, 0);
    acc.idle += idle;
    acc.total += total;
    return acc;
  }, { idle: 0, total: 0 });
  return totals;
}

function calculateCpuUsage() {
  const current = readCpuSnapshot();
  const idleDelta = current.idle - previousCpu.idle;
  const totalDelta = current.total - previousCpu.total;
  previousCpu = current;

  if (totalDelta <= 0) return 0;
  return Math.max(0, Math.min(100, (1 - idleDelta / totalDelta) * 100));
}

function readNetworkSnapshot() {
  const snapshot = { rxBytes: 0, txBytes: 0, timestamp: Date.now() };
  try {
    const content = os.platform() === 'linux'
      ? readFileSync('/proc/net/dev', 'utf8')
      : '';

    for (const line of content.split('\n').slice(2)) {
      const [ifacePart, dataPart] = line.split(':');
      if (!ifacePart || !dataPart) continue;
      const iface = ifacePart.trim();
      if (iface === 'lo') continue;
      const values = dataPart.trim().split(/\s+/).map(Number);
      snapshot.rxBytes += values[0] || 0;
      snapshot.txBytes += values[8] || 0;
    }
  } catch {
    return snapshot;
  }
  return snapshot;
}

function calculateNetwork() {
  const current = readNetworkSnapshot();
  const seconds = Math.max(1, (current.timestamp - previousNetwork.timestamp) / 1000);
  const network = {
    rxBytes: current.rxBytes,
    txBytes: current.txBytes,
    rxRateBps: Math.max(0, (current.rxBytes - previousNetwork.rxBytes) / seconds),
    txRateBps: Math.max(0, (current.txBytes - previousNetwork.txBytes) / seconds),
  };
  previousNetwork = current;
  return network;
}

async function readDisks() {
  if (os.platform() !== 'linux') return [];
  try {
    const { stdout } = await execFileAsync('df', ['-kP', '/']);
    return stdout
      .trim()
      .split('\n')
      .slice(1)
      .map(line => line.trim().split(/\s+/))
      .filter(parts => parts.length >= 6)
      .map(parts => {
        const total = Number(parts[1]) * 1024;
        const used = Number(parts[2]) * 1024;
        const free = Number(parts[3]) * 1024;
        return {
          filesystem: parts[0],
          total,
          used,
          free,
          usagePercent: total > 0 ? used / total * 100 : 0,
          mount: parts.slice(5).join(' '),
        };
      });
  } catch (error) {
    return [{
      filesystem: 'unknown',
      mount: '/',
      usagePercent: 0,
      message: error.message,
    }];
  }
}

function normalizeManagementBase(base) {
  let normalized = base.trim().replace(/\/?v0\/management\/?$/i, '').replace(/\/+$/, '');
  if (!normalized) return '';
  if (!/^https?:\/\//i.test(normalized)) normalized = `http://${normalized}`;
  return `${normalized}/v0/management`;
}

function isDisabledAuthFile(file) {
  const value = file?.disabled ?? file?.is_disabled ?? file?.isDisabled;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value === 1;
  if (typeof value === 'string') return ['true', '1', 'yes', 'on'].includes(value.trim().toLowerCase());
  return false;
}

async function fetchQuotaSummary() {
  const base = normalizeManagementBase(ZEROLIMIT_API_BASE);
  if (!base || !ZEROLIMIT_MANAGEMENT_KEY) return null;

  try {
    const response = await fetch(`${base}/auth-files`, {
      headers: {
        Accept: 'application/json',
        Authorization: `Bearer ${ZEROLIMIT_MANAGEMENT_KEY}`,
      },
      signal: AbortSignal.timeout(8000),
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const files = Array.isArray(data) ? data : (data.files || data.items || []);
    const accountsDisabled = files.filter(isDisabledAuthFile).length;
    return {
      accountsTotal: files.length,
      accountsEnabled: files.length - accountsDisabled,
      accountsDisabled,
    };
  } catch (error) {
    return {
      accountsTotal: 0,
      accountsEnabled: 0,
      accountsDisabled: 0,
      error: error.message,
    };
  }
}

function parseServiceChecks() {
  return SERVICE_CHECKS
    .split(',')
    .map(item => item.trim())
    .filter(Boolean)
    .map(item => {
      const [name, url] = item.split('|').map(part => part.trim());
      return { name: name || url, url };
    })
    .filter(item => item.name && item.url);
}

async function checkServices() {
  const checks = parseServiceChecks();
  return Promise.all(checks.map(async check => {
    const startedAt = Date.now();
    try {
      const response = await fetch(check.url, {
        method: 'GET',
        signal: AbortSignal.timeout(5000),
      });
      return {
        name: check.name,
        status: response.ok ? 'ok' : 'error',
        message: `HTTP ${response.status}`,
        latencyMs: Date.now() - startedAt,
      };
    } catch (error) {
      return {
        name: check.name,
        status: 'error',
        message: error.message,
        latencyMs: Date.now() - startedAt,
      };
    }
  }));
}

async function collectStatus() {
  const totalMemory = os.totalmem();
  const freeMemory = os.freemem();
  const usedMemory = totalMemory - freeMemory;
  const cpus = os.cpus();
  const [one, five, fifteen] = os.loadavg();
  const [disks, services, quota] = await Promise.all([
    readDisks(),
    checkServices(),
    fetchQuotaSummary(),
  ]);

  return {
    timestamp: new Date().toISOString(),
    hostname: os.hostname(),
    ip: findPrimaryIp(),
    uptimeSec: os.uptime(),
    load: { one, five, fifteen },
    cpu: {
      usagePercent: calculateCpuUsage(),
      cores: cpus.length,
      model: cpus[0]?.model || '',
    },
    memory: {
      total: totalMemory,
      used: usedMemory,
      free: freeMemory,
      usagePercent: totalMemory > 0 ? usedMemory / totalMemory * 100 : 0,
    },
    disks,
    network: calculateNetwork(),
    services,
    quota: quota || undefined,
  };
}

function findPrimaryIp() {
  for (const entries of Object.values(os.networkInterfaces())) {
    for (const entry of entries || []) {
      if (entry.family === 'IPv4' && !entry.internal) return entry.address;
    }
  }
  return '';
}

function formatBytes(value) {
  if (!Number.isFinite(value) || value <= 0) return '-';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let size = value;
  let index = 0;
  while (size >= 1024 && index < units.length - 1) {
    size /= 1024;
    index += 1;
  }
  return `${size.toFixed(size >= 10 || index === 0 ? 0 : 1)} ${units[index]}`;
}

function buildMarkdown(status) {
  const disk = status.disks?.[0];
  const services = status.services?.length
    ? status.services.map(service => `- ${service.name}: ${service.status === 'ok' ? '正常' : '异常'} ${service.message || ''}`).join('\n')
    : '- 未配置服务检查';
  const quota = status.quota
    ? `账号：${status.quota.accountsTotal ?? '-'}，启用：${status.quota.accountsEnabled ?? '-'}，停用：${status.quota.accountsDisabled ?? '-'}`
    : '账号：未配置 CLIProxy 管理信息';

  return [
    '### ZeroLimit 状态报表',
    `时间：${new Date(status.timestamp).toLocaleString('zh-CN', { hour12: false })}`,
    `服务器：${status.hostname || '-'} ${status.ip || ''}`,
    `CPU：${status.cpu.usagePercent.toFixed(1)}%（${status.cpu.cores || '-'} 核）`,
    `内存：${status.memory.usagePercent.toFixed(1)}%（${formatBytes(status.memory.used)} / ${formatBytes(status.memory.total)}）`,
    `磁盘：${disk ? `${disk.usagePercent.toFixed(1)}%（${formatBytes(disk.used)} / ${formatBytes(disk.total)}）` : '-'}`,
    `负载：${status.load.one.toFixed(2)} / ${status.load.five.toFixed(2)} / ${status.load.fifteen.toFixed(2)}`,
    quota,
    '',
    '服务：',
    services,
  ].join('\n\n');
}

function signedDingTalkUrl(webhook, secret) {
  if (!secret) return webhook;
  const timestamp = Date.now();
  const sign = crypto
    .createHmac('sha256', secret)
    .update(`${timestamp}\n${secret}`)
    .digest('base64');
  const url = new URL(webhook);
  url.searchParams.set('timestamp', String(timestamp));
  url.searchParams.set('sign', sign);
  return url.toString();
}

async function postDingTalkMarkdown(webhook, markdown, secret = '') {
  if (!webhook) throw new Error('DINGTALK_WEBHOOK is not configured');
  const response = await fetch(signedDingTalkUrl(webhook, secret), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      msgtype: 'markdown',
      markdown: {
        title: 'ZeroLimit 状态报表',
        text: markdown,
      },
    }),
    signal: AbortSignal.timeout(10000),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || (data.errcode && data.errcode !== 0)) {
    throw new Error(data.errmsg || `DingTalk HTTP ${response.status}`);
  }
  return data;
}

async function sendReport(webhook = DINGTALK_WEBHOOK) {
  const status = await collectStatus();
  const markdown = buildMarkdown(status);
  await postDingTalkMarkdown(webhook, markdown, webhook === DINGTALK_WEBHOOK ? DINGTALK_SECRET : '');
  return status;
}

function extractDingTalkText(payload) {
  return String(
    payload?.text?.content ||
    payload?.text?.text ||
    payload?.content ||
    payload?.msg ||
    payload?.message ||
    ''
  ).trim();
}

function extractSessionWebhook(payload) {
  return payload?.sessionWebhook || payload?.conversationWebhook || payload?.webhook || '';
}

async function handleDingTalkCallback(req, res) {
  const raw = await readBody(req);
  const payload = raw ? JSON.parse(raw) : {};
  const text = extractDingTalkText(payload);
  const shouldReport = /\d/.test(text);

  if (!shouldReport) {
    json(res, 200, {
      msgtype: 'text',
      text: { content: '发送任意数字即可获取 ZeroLimit 状态报表。' },
    });
    return;
  }

  const sessionWebhook = extractSessionWebhook(payload);
  await sendReport(sessionWebhook || DINGTALK_WEBHOOK);
  json(res, 200, {
    msgtype: 'text',
    text: { content: 'ZeroLimit 状态报表已推送。' },
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const reqUrl = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);

    if (req.method === 'OPTIONS') {
      json(res, 204, {});
      return;
    }

    if (req.method === 'GET' && reqUrl.pathname === '/health') {
      json(res, 200, { ok: true, service: 'zerolimit-monitor' });
      return;
    }

    if (req.method === 'GET' && reqUrl.pathname === '/status') {
      if (!requireMonitorAuth(reqUrl, req, res)) return;
      json(res, 200, await collectStatus());
      return;
    }

    if (req.method === 'POST' && reqUrl.pathname === '/notify') {
      if (!requireMonitorAuth(reqUrl, req, res)) return;
      await readBody(req).catch(() => '');
      await sendReport();
      json(res, 200, { ok: true, message: 'DingTalk report sent' });
      return;
    }

    if (req.method === 'POST' && reqUrl.pathname === '/dingtalk/callback') {
      if (!requireCallbackAuth(reqUrl, res)) return;
      await handleDingTalkCallback(req, res);
      return;
    }

    json(res, 404, { ok: false, message: 'Not found' });
  } catch (error) {
    json(res, 500, { ok: false, message: error.message || 'Internal error' });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`ZeroLimit monitor listening on http://${HOST}:${PORT}`);
});
