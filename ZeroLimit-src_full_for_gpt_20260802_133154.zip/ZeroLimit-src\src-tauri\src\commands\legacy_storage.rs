﻿//! Legacy localStorage migration helpers.

use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};

use tauri::command;

use crate::error::{CommandError, CommandResult};

const LEGACY_APP_IDS: &[&str] = &["com.0xtbug.zero-limit"];
const INTEGRATIONS_STORAGE_KEY: &str = "zerolimit-integrations";
const LEGACY_STORAGE_KEYS: &[&str] = &[
    INTEGRATIONS_STORAGE_KEY,
    "zerolimit.quota.disabledOverrides.v1",
    "zerolimit.quota.zeroQuotaDisabled.v1",
    "zerolimit.quota.weeklyQuotaDisabled.v1",
    "zerolimit.quota.importTimes.v1",
    "zerolimit.quota.zeroQuotaZeroedAt.v1",
    "zerolimit.quota.weeklyQuotaZeroedAt.v1",
    "zerolimit.quota.weeklyQuotaResetAt.v1",
];

fn leveldb_dir(app_id: &str) -> Option<PathBuf> {
    dirs::data_local_dir().map(|base| {
        base.join(app_id)
            .join("EBWebView")
            .join("Default")
            .join("Local Storage")
            .join("leveldb")
    })
}

fn is_storage_file(path: &Path) -> bool {
    matches!(path.extension().and_then(|value| value.to_str()), Some("log") | Some("ldb"))
}

fn text_variants(bytes: &[u8]) -> Vec<String> {
    let mut variants = vec![String::from_utf8_lossy(bytes).replace('\0', "")];

    let utf16_units: Vec<u16> = bytes
        .chunks_exact(2)
        .map(|chunk| u16::from_le_bytes([chunk[0], chunk[1]]))
        .collect();
    if !utf16_units.is_empty() {
        variants.push(String::from_utf16_lossy(&utf16_units).replace('\0', ""));
    }

    variants
}

fn find_json_object_after(text: &str, start: usize) -> Option<(usize, usize)> {
    let relative_start = text[start..].find('{')?;
    let object_start = start + relative_start;
    let mut depth = 0usize;
    let mut in_string = false;
    let mut escaped = false;

    for (offset, ch) in text[object_start..].char_indices() {
        if in_string {
            if escaped {
                escaped = false;
            } else if ch == '\\' {
                escaped = true;
            } else if ch == '"' {
                in_string = false;
            }
            continue;
        }

        match ch {
            '"' => in_string = true,
            '{' => depth += 1,
            '}' => {
                depth = depth.saturating_sub(1);
                if depth == 0 {
                    return Some((object_start, object_start + offset + ch.len_utf8()));
                }
            }
            _ => {}
        }
    }

    None
}

fn extract_latest_value(text: &str, key: &str) -> Option<String> {
    let mut latest = None;
    let mut cursor = 0usize;

    while let Some(relative_index) = text[cursor..].find(key) {
        let key_index = cursor + relative_index;
        let value_start = key_index + key.len();

        if let Some((start, end)) = find_json_object_after(text, value_start) {
            let candidate = &text[start..end];
            if serde_json::from_str::<serde_json::Value>(candidate).is_ok() {
                latest = Some(candidate.to_string());
            }
            cursor = end;
        } else {
            cursor = value_start;
        }
    }

    latest
}

fn is_ipv4_host_port(value: &str) -> bool {
    let Some((host, port)) = value.rsplit_once(':') else {
        return false;
    };

    let port_ok = !port.is_empty() && port.len() <= 5 && port.chars().all(|ch| ch.is_ascii_digit());
    let octets: Vec<_> = host.split('.').collect();
    port_ok
        && octets.len() == 4
        && octets.iter().all(|part| {
            !part.is_empty()
                && part.len() <= 3
                && part.chars().all(|ch| ch.is_ascii_digit())
                && part.parse::<u8>().is_ok()
        })
}

fn extract_host_port(text: &str) -> Option<String> {
    let bytes = text.as_bytes();
    let mut start = 0usize;

    while start < bytes.len() {
        while start < bytes.len() && !bytes[start].is_ascii_digit() {
            start += 1;
        }
        let mut end = start;
        while end < bytes.len()
            && (bytes[end].is_ascii_digit() || bytes[end] == b'.' || bytes[end] == b':')
        {
            end += 1;
        }

        if end > start {
            let candidate = &text[start..end];
            if is_ipv4_host_port(candidate) {
                return Some(candidate.to_string());
            }
        }
        start = end.saturating_add(1);
    }

    None
}

fn extract_hex_token_after_token_marker(text: &str) -> Option<String> {
    let marker = text.find("Token").or_else(|| text.find("token"))?;
    let tail = &text[marker..];
    let bytes = tail.as_bytes();
    let mut start = 0usize;

    while start < bytes.len() {
        while start < bytes.len() && !bytes[start].is_ascii_hexdigit() {
            start += 1;
        }
        let mut end = start;
        while end < bytes.len() && bytes[end].is_ascii_hexdigit() {
            end += 1;
        }

        if end > start {
            let candidate = &tail[start..end];
            if candidate.len() >= 32 && candidate.len() <= 96 {
                return Some(candidate.to_string());
            }
        }
        start = end.saturating_add(1);
    }

    None
}

fn extract_integration_fallback(text: &str) -> Option<String> {
    let marker = text.find(INTEGRATIONS_STORAGE_KEY)?;
    let end = text[marker..]
        .find("zerolimit.quota")
        .map(|relative| marker + relative)
        .unwrap_or_else(|| (marker + 1500).min(text.len()));
    let snippet = &text[marker..end];

    let monitor_url = extract_host_port(snippet).map(|host| format!("http://{host}"));
    let monitor_token = extract_hex_token_after_token_marker(snippet);
    if monitor_url.is_none() && monitor_token.is_none() {
        return None;
    }

    let notify_url = monitor_url.as_ref().map(|url| format!("{}/notify", url.trim_end_matches('/')));
    let payload = serde_json::json!({
        "state": {
            "monitorUrl": monitor_url.unwrap_or_default(),
            "monitorToken": monitor_token.unwrap_or_default(),
            "notifyUrl": notify_url.unwrap_or_default()
        },
        "version": 0
    });

    Some(payload.to_string())
}

fn collect_legacy_storage_records() -> CommandResult<HashMap<String, String>> {
    let mut records = HashMap::new();

    for app_id in LEGACY_APP_IDS {
        let Some(dir) = leveldb_dir(app_id) else {
            continue;
        };
        if !dir.is_dir() {
            continue;
        }

        let mut entries: Vec<_> = fs::read_dir(&dir)
            .map_err(|error| CommandError::General(error.to_string()))?
            .filter_map(Result::ok)
            .filter(|entry| is_storage_file(&entry.path()))
            .collect();

        entries.sort_by_key(|entry| entry.metadata().and_then(|metadata| metadata.modified()).ok());

        for entry in entries {
            let Ok(bytes) = fs::read(entry.path()) else {
                continue;
            };

            for text in text_variants(&bytes) {
                for key in LEGACY_STORAGE_KEYS {
                    if let Some(value) = extract_latest_value(&text, key) {
                        records.insert((*key).to_string(), value);
                    }
                }

                if !records.contains_key(INTEGRATIONS_STORAGE_KEY) {
                    if let Some(value) = extract_integration_fallback(&text) {
                        records.insert(INTEGRATIONS_STORAGE_KEY.to_string(), value);
                    }
                }
            }
        }
    }

    Ok(records)
}

#[command]
pub async fn read_legacy_quota_storage() -> CommandResult<HashMap<String, String>> {
    collect_legacy_storage_records()
}
