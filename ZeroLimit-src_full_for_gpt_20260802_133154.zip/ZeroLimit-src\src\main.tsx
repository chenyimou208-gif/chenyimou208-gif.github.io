﻿import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import '@/i18n'
import './index.css'
import { migrateLegacyQuotaStorage } from '@/services/tauri/legacyStorage.service'

async function bootstrap() {
  await migrateLegacyQuotaStorage()
  const { default: App } = await import('./App.tsx')

  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </StrictMode>,
  )
}

void bootstrap()
