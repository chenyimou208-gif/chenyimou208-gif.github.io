import type { AuthFile } from './authFile';

export interface QuotaModel {
  name: string;
  percentage: number;
  resetTime?: string;
  resetAt?: number;
  resetReady?: boolean;
  displayValue?: string;
}

export interface AntigravityQuotaResult {
  models: QuotaModel[];
  error?: string;
}

export interface ClaudeQuotaResult {
  models: QuotaModel[];
  email?: string;
  error?: string;
}

export interface CodexQuotaResult {
  plan?: string;
  limits: QuotaModel[];
  error?: string;
}

export interface GeminiCliQuotaResult {
  buckets: Array<{ modelId: string; percentage: number; resetTime?: string }>;
  error?: string;
}

export interface KiroQuotaResult {
  models: QuotaModel[];
  plan?: string;
  email?: string;
  tokenExpiresAt?: string;
  error?: string;
}

export interface CopilotQuotaResult {
  models: QuotaModel[];
  plan?: string;
  username?: string;
  error?: string;
}

export interface FileQuota {
  fileId: string;
  filename: string;
  provider: string;
  providerKey: string;
  loading: boolean;
  quotaChecked?: boolean;
  error?: string;
  originalFile?: AuthFile;
  models?: QuotaModel[];
  plan?: string;
  limits?: QuotaModel[];
  email?: string;
  importOrder?: number;
  importedAt?: string;
  nodeId?: string;
  nodeName?: string;
}

export interface ProviderSection {
  provider: string;
  displayName: string;
  files: FileQuota[];
}
