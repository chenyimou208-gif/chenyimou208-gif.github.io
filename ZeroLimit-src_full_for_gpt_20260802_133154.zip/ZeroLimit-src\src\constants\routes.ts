import {
  LayoutDashboard,
  BarChart3,
  Gauge,
  Activity,
  CalendarClock,
  Network,
  Users,
  Settings,
  Info,
  FileText,
} from 'lucide-react';

export const NAV_ITEMS = [
  { path: '/quota', icon: BarChart3, labelKey: 'nav.quota' },
  { path: '/dashboard', icon: LayoutDashboard, labelKey: 'nav.dashboard' },
  { path: '/codex-usage', icon: Gauge, labelKey: 'nav.codexUsage' },
  { path: '/availability-test', icon: Activity, labelKey: 'nav.availabilityTest' },
  { path: '/zero-quota', icon: CalendarClock, labelKey: 'nav.zeroQuota' },
  { path: '/sub2api', icon: Network, labelKey: 'nav.sub2api' },
  { path: '/providers', icon: Users, labelKey: 'providers.title' },
  { path: '/logs', icon: FileText, labelKey: 'nav.logs' },
  { path: '/settings', icon: Settings, labelKey: 'nav.settings' },
  { path: '/about', icon: Info, labelKey: 'nav.about' },
] as const;

export const ROUTE_PATHS = {
  DASHBOARD: '/dashboard',
  CODEX_USAGE: '/codex-usage',
  AVAILABILITY_TEST: '/availability-test',
  ZERO_QUOTA: '/zero-quota',
  QUOTA: '/quota',
  SUB2API: '/sub2api',
  PROVIDERS: '/providers',
  LOGS: '/logs',
  SETTINGS: '/settings',
  ABOUT: '/about',
  LOGIN: '/login',
} as const;
