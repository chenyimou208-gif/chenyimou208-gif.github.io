export const DEFAULT_API_BASE =
  (import.meta.env.VITE_DEFAULT_API_BASE as string | undefined)?.trim() || 'https://aisiu.me';

export const DEFAULT_MANAGEMENT_KEY =
  (import.meta.env.VITE_DEFAULT_MANAGEMENT_KEY as string | undefined)?.trim() || '';

export const HAS_BUNDLED_CONNECTION = Boolean(DEFAULT_API_BASE && DEFAULT_MANAGEMENT_KEY);

const LOCAL_API_BASE_RE = /^https?:\/\/(?:localhost|127\.0\.0\.1)(?::8317)?(?:\/|$)/i;

export function shouldPreferBundledConnection(storedBase?: string, storedKey?: string): boolean {
  if (!HAS_BUNDLED_CONNECTION) return false;
  const base = (storedBase || '').trim();
  const key = (storedKey || '').trim();
  return !key || LOCAL_API_BASE_RE.test(base);
}
