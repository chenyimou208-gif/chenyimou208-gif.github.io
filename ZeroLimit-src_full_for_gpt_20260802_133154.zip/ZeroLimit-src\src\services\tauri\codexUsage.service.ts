import { invoke } from '@tauri-apps/api/core';
import type { CodexTokenUsageReport } from '@/types';

export const codexUsageApi = {
  getUsage(): Promise<CodexTokenUsageReport> {
    return invoke<CodexTokenUsageReport>('get_codex_token_usage');
  },
};
