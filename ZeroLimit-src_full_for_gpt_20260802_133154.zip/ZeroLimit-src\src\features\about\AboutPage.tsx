/**
 * About Page
 */

import { motion } from 'motion/react';
import { Badge } from '@/shared/components/ui/badge';
import { useAppVersion } from '@/shared/hooks';

export function AboutPage() {
  const version = useAppVersion();

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col items-center justify-center min-h-[80vh] space-y-8"
    >
      <div className="flex flex-col items-center space-y-4">
        <img
          src="/icon.png"
          alt="ZeroLimit"
          className="h-24 w-24 rounded-2xl shadow-lg"
        />
        <h1 className="text-3xl font-bold">ZeroLimit</h1>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-sm">v{version}</Badge>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Badge variant="outline">Tauri v2</Badge>
        <Badge variant="outline">React 19</Badge>
        <Badge variant="outline">TypeScript</Badge>
      </div>
    </motion.div>
  );
}
