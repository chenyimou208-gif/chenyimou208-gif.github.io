export interface Sub2ApiConfig {
  baseUrl: string;
  email: string;
  password: string;
  gatewayKey?: string;
  rememberPassword: boolean;
}

export interface Sub2ApiLoginResponse {
  access_token: string;
  refresh_token?: string;
  expires_in?: number;
  user?: Sub2ApiUser;
}

export interface Sub2ApiUser {
  id?: number | string;
  email?: string;
  username?: string;
  role?: string;
  status?: string;
  [key: string]: unknown;
}

export interface Sub2ApiPagedResponse<T> {
  items?: T[];
  records?: T[];
  list?: T[];
  data?: T[];
  total?: number;
  page?: number;
  page_size?: number;
  pages?: number;
  [key: string]: unknown;
}

export interface Sub2ApiAccount {
  id: number | string;
  name?: string;
  email?: string;
  username?: string;
  account?: string;
  platform?: string;
  provider?: string;
  type?: string;
  status?: string;
  schedulable?: boolean;
  enabled?: boolean;
  disabled?: boolean;
  error?: string | null;
  error_message?: string | null;
  last_error?: string | null;
  quota?: unknown;
  openai_quota?: unknown;
  group_ids?: Array<number | string>;
  group_names?: string[];
  created_at?: string;
  updated_at?: string;
  last_test_at?: string;
  [key: string]: unknown;
}

export interface Sub2ApiBatchResult {
  success?: number;
  failed?: number;
  success_ids?: Array<number | string>;
  failed_ids?: Array<number | string>;
  errors?: unknown[];
  warnings?: unknown[];
  [key: string]: unknown;
}

export interface Sub2ApiImportResult extends Sub2ApiBatchResult {
  created?: number;
  updated?: number;
  skipped?: number;
}

export interface Sub2ApiKey {
  id: number | string;
  name?: string;
  key?: string;
  token?: string;
  status?: string;
  created_at?: string;
  [key: string]: unknown;
}

export interface Sub2ApiQuotaResult {
  limits?: unknown[];
  quota?: unknown;
  usage?: unknown;
  reset_at?: string;
  [key: string]: unknown;
}
