/**
 * Settings Page
 */

import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { useThemeStore } from '@/features/settings/theme.store';
import { useLanguageStore } from '@/features/settings/language.store';
import { useAuthStore } from '@/features/auth/auth.store';
import { useCliProxyStore } from '@/features/settings/cliProxy.store';
import { useConfigStore } from '@/features/settings/config.store';
import { useIntegrationStore } from '@/features/integrations/integration.store';
import { serverMonitorApi } from '@/services/api/serverMonitor.service';
import { CpaNodesSettings } from '@/features/nodes/CpaNodesSettings';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/shared/components/ui/card';
import { Button } from '@/shared/components/ui/button';
import { Label } from '@/shared/components/ui/label';
import { Input } from '@/shared/components/ui/input';
import { Sun, Moon, Monitor, LogOut, Globe, Server, FolderOpen, Play, Square, CheckCircle2, Loader2, FileText, RefreshCw, Download, ArrowLeftRight, Bell, RadioTower } from 'lucide-react';
import { toast } from 'sonner';

export function SettingsPage() {
  const { t } = useTranslation();
  const { theme, setTheme } = useThemeStore();
  const { language, setLanguage } = useLanguageStore();
  const { logout, connectionStatus } = useAuthStore();
  const {
    monitorUrl, monitorToken, notifyUrl,
    setMonitorUrl, setMonitorToken, setNotifyUrl,
  } = useIntegrationStore();
  const {
    exePath, autoStart, runInBackground, isServerRunning,
    setAutoStart, setRunInBackground, browseForExe, startServer, stopServer,
    cliProxyLatestVersion, latestRemoteVersion, updateAvailable,
    isCheckingUpdate, isUpdating, isSwitchingVersion, checkForProxyUpdate, updateProxy, switchVersion,
    currentInstalledVersion, serverBuildDate,
  } = useCliProxyStore();
  const { config, fetchConfig, updateLoggingToFile, updatingLogging } = useConfigStore();
  const [testingMonitor, setTestingMonitor] = useState(false);
  const [testingNotify, setTestingNotify] = useState(false);

  useEffect(() => {
    if (connectionStatus === 'connected' && !config) {
      fetchConfig();
    }
  }, [connectionStatus, config, fetchConfig]);

  const loggingToFileEnabled = Boolean(config?.['logging-to-file'] ?? false);

  const handleToggleLogging = async () => {
    try {
      await updateLoggingToFile(!loggingToFileEnabled);
    } catch {
      toast.error(t('logging.error'));
    }
  };

  const handleTestMonitor = async () => {
    setTestingMonitor(true);
    try {
      await serverMonitorApi.getStatus(monitorUrl, monitorToken);
      toast.success('服务器监控连接正常');
    } catch (error) {
      toast.error(`服务器监控连接失败：${(error as Error).message}`);
    } finally {
      setTestingMonitor(false);
    }
  };

  const handleTestNotify = async () => {
    setTestingNotify(true);
    try {
      await serverMonitorApi.sendDingTalkReport(notifyUrl, monitorToken);
      toast.success('钉钉推送成功');
    } catch (error) {
      toast.error(`钉钉推送失败：${(error as Error).message}`);
    } finally {
      setTestingNotify(false);
    }
  };

  const formatBuildDate = (dateStr: string | null) => {
    if (!dateStr) return null;
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
    } catch { return dateStr; }
  };

  const themeOptions = [
    { value: 'light', label: t('settings.light'), icon: Sun },
    { value: 'dark', label: t('settings.dark'), icon: Moon },
    { value: 'system', label: t('settings.system'), icon: Monitor },
  ] as const;

  const languageOptions = [
    { value: 'en', label: 'English' },
    { value: 'zh-CN', label: '中文' },
    { value: 'id', label: 'Indonesia' },
    { value: 'ja', label: '日本語' },
    { value: 'ko', label: '한국어' },
    { value: 'vi', label: 'Tiếng Việt' },
    { value: 'th', label: 'ไทย' },
  ] as const;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6"
    >
      <div>
        <h1 className="text-3xl font-bold">{t('settings.title')}</h1>
      </div>

      <CpaNodesSettings />

      {/* CLI Proxy Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="h-5 w-5" />
            {t('cliProxy.title')}
          </CardTitle>
          <CardDescription>{t('cliProxy.description')}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Exe Path */}
          <div className="space-y-2">
            <Label>{t('cliProxy.executablePath')}</Label>
            <div className="flex items-center gap-2">
              <div className="flex-1 rounded-md border bg-muted px-3 py-2 text-sm truncate">
                {exePath || t('cliProxy.noPathConfigured')}
              </div>
              <Button variant="outline" size="sm" onClick={browseForExe}>
                <FolderOpen className="mr-2 h-4 w-4" />
                {t('cliProxy.browse')}
              </Button>
            </div>
          </div>

          {/* Auto Start Toggle */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>{t('cliProxy.autoStart')}</Label>
              <p className="text-xs text-muted-foreground">
                {t('cliProxy.autoStartDesc')}
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={autoStart}
              onClick={() => setAutoStart(!autoStart)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                autoStart ? 'bg-primary' : 'bg-muted'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  autoStart ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Run in Background Toggle */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>{t('cliProxy.runInBackground')}</Label>
              <p className="text-xs text-muted-foreground">
                {t('cliProxy.runInBackgroundDesc')}
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={runInBackground}
              onClick={() => setRunInBackground(!runInBackground)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                runInBackground ? 'bg-primary' : 'bg-muted'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  runInBackground ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Server Status & Controls */}
          <div className="flex items-center justify-between pt-2 border-t">
            <div className="flex items-center gap-2">
              <span className="text-sm">{t('cliProxy.status')}:</span>
              {isServerRunning ? (
                <span className="flex items-center gap-1 text-sm text-green-500">
                  <CheckCircle2 className="h-4 w-4" />
                  {t('cliProxy.running')}
                </span>
              ) : (
                <span className="text-sm text-muted-foreground">{t('cliProxy.stopped')}</span>
              )}
            </div>
            {exePath && (
              isServerRunning ? (
                <Button variant="destructive" size="sm" onClick={stopServer}>
                  <Square className="mr-2 h-4 w-4" />
                  {t('cliProxy.stop')}
                </Button>
              ) : (
                <Button variant="default" size="sm" onClick={startServer}>
                  <Play className="mr-2 h-4 w-4" />
                  {t('cliProxy.start')}
                </Button>
              )
            )}
          </div>

          {/* Version & Update */}
          {exePath && (
            <div className="space-y-3 pt-2 border-t">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>{t('cliProxy.version', 'Version')}</Label>
                  <p className="text-xs text-muted-foreground">
                    {currentInstalledVersion ? `v${currentInstalledVersion}` : (cliProxyLatestVersion || 'Unknown')}
                    {serverBuildDate && (
                      <span className="ml-1 opacity-60">({formatBuildDate(serverBuildDate)})</span>
                    )}
                    {latestRemoteVersion && updateAvailable && (
                      <span className="ml-2 text-green-500">&rarr; {latestRemoteVersion}</span>
                    )}
                  </p>
                </div>
                <div className="flex gap-2">
                  {updateAvailable ? (
                    <Button
                      variant="default"
                      size="sm"
                      onClick={async () => {
                        try {
                          toast.info('Updating CLI Proxy...');
                          await updateProxy();
                          toast.success('CLI Proxy updated and restarted!');
                        } catch (err: any) {
                          toast.error(`Update failed: ${err?.message || 'Unknown error'}`);
                        }
                      }}
                      disabled={isUpdating}
                    >
                      {isUpdating ? (
                        <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Updating...</>
                      ) : (
                        <><Download className="mr-2 h-4 w-4" />Update Now</>
                      )}
                    </Button>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={async () => {
                        try {
                          const hasUpdate = await checkForProxyUpdate();
                          if (hasUpdate) {
                            toast.success('Update available!');
                          } else {
                            toast.info('Already on the latest version.');
                          }
                        } catch (err: any) {
                          toast.error(`Update check failed: ${err?.message || 'Unknown error'}`);
                        }
                      }}
                      disabled={isCheckingUpdate}
                    >
                      {isCheckingUpdate ? (
                        <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Checking...</>
                      ) : (
                        <><RefreshCw className="mr-2 h-4 w-4" />Check for Update</>
                      )}
                    </Button>
                  )}
                </div>
              </div>

              {/* Version Switch */}
              <div className="flex items-center justify-between pt-2 border-t">
                <div className="space-y-0.5">
                  <Label>Switch Version</Label>
                  <p className="text-xs text-muted-foreground">
                    {exePath?.toLowerCase().includes('plus')
                      ? 'Currently using Plus version'
                      : 'Currently using Standard version'
                    }
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={async () => {
                    try {
                      const targetLabel = exePath?.toLowerCase().includes('plus') ? 'Standard' : 'Plus';
                      toast.info(`Switching to ${targetLabel} version...`);
                      await switchVersion();
                      toast.success(`Switched to ${targetLabel} version!`);
                    } catch (err: any) {
                      toast.error(`Switch failed: ${err?.message || 'Unknown error'}`);
                    }
                  }}
                  disabled={isSwitchingVersion || isUpdating}
                >
                  {isSwitchingVersion ? (
                    <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Switching...</>
                  ) : (
                    <>
                      <ArrowLeftRight className="mr-2 h-4 w-4" />
                      {exePath?.toLowerCase().includes('plus') ? 'Switch to Standard' : 'Switch to Plus'}
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Logging Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            {t('logging.title')}
          </CardTitle>
          <CardDescription>{t('logging.description')}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>{t('logging.enabled')}</Label>
              <p className="text-xs text-muted-foreground">
                {t('logging.enabledDesc')}
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={loggingToFileEnabled}
              onClick={handleToggleLogging}
              disabled={updatingLogging || connectionStatus !== 'connected'}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                loggingToFileEnabled ? 'bg-primary' : 'bg-muted'
              }`}
            >
              {updatingLogging ? (
                <Loader2 className="h-4 w-4 animate-spin mx-auto text-muted-foreground" />
              ) : (
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    loggingToFileEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              )}
            </button>
          </div>
        </CardContent>
      </Card>

      {/* Server Monitor & DingTalk */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RadioTower className="h-5 w-5" />
            服务器监控
          </CardTitle>
          <CardDescription>把服务器状态接到仪表盘，并支持钉钉随时查看。</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="monitorUrl">监控服务地址</Label>
            <div className="flex gap-2">
              <Input
                id="monitorUrl"
                type="url"
                placeholder="例如：http://186.241.90.108:8787"
                value={monitorUrl}
                onChange={(event) => setMonitorUrl(event.target.value)}
              />
              <Button
                type="button"
                variant="outline"
                onClick={handleTestMonitor}
                disabled={!monitorUrl || testingMonitor}
              >
                {testingMonitor ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
                测试
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              部署我给你的监控脚本后，填脚本监听的地址。
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="monitorToken">访问令牌</Label>
            <Input
              id="monitorToken"
              type="password"
              placeholder="和服务器脚本里的 MONITOR_TOKEN 保持一致"
              value={monitorToken}
              onChange={(event) => setMonitorToken(event.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notifyUrl">钉钉推送地址</Label>
            <div className="flex gap-2">
              <Input
                id="notifyUrl"
                type="url"
                placeholder="通常是：监控服务地址/notify"
                value={notifyUrl}
                onChange={(event) => setNotifyUrl(event.target.value)}
              />
              <Button
                type="button"
                variant="outline"
                onClick={handleTestNotify}
                disabled={!notifyUrl || testingNotify}
              >
                {testingNotify ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Bell className="mr-2 h-4 w-4" />}
                推送测试
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              想在钉钉里发数字就收到报表，需要同时把钉钉机器人回调地址配置为：监控服务地址/dingtalk/callback。
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Theme Settings */}
      <Card>
        <CardHeader>
          <CardTitle>{t('settings.theme')}</CardTitle>
          <CardDescription>{t('settings.themeDesc')}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            {themeOptions.map((option) => (
              <Button
                key={option.value}
                variant={theme === option.value ? 'default' : 'outline'}
                onClick={() => setTheme(option.value)}
                className="flex items-center gap-2"
              >
                <option.icon className="h-4 w-4" />
                {option.label}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Language Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            {t('settings.language')}
          </CardTitle>
          <CardDescription>{t('settings.languageDesc')}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 flex-wrap">
            {languageOptions.map((option) => (
              <Button
                key={option.value}
                variant={language === option.value ? 'default' : 'outline'}
                onClick={() => setLanguage(option.value)}
              >
                {option.label}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Account */}
      <Card>
        <CardHeader>
          <CardTitle>{t('account.title')}</CardTitle>
          <CardDescription>{t('account.manageSession')}</CardDescription>
        </CardHeader>
        <CardContent>
          <Button variant="destructive" onClick={() => logout()} className="flex items-center gap-2">
            <LogOut className="h-4 w-4" />
            {t('auth.logout')}
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}
