/**
 * Config API
 */

import { apiClient } from './client';
import type { Config, CpaNodeConnectionConfig } from '@/types';

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function upsertBooleanSetting(yamlContent: string, key: string, enabled: boolean): string {
  const line = `${key}: ${enabled}`;
  const pattern = new RegExp(`^(${escapeRegExp(key)}\\s*:\\s*)(true|false)(\\s*(?:#.*)?)?$`, 'm');

  if (pattern.test(yamlContent)) {
    return yamlContent.replace(pattern, `$1${enabled}$3`);
  }

  const trimmed = yamlContent.replace(/\s*$/, '');
  return `${trimmed}${trimmed ? '\n' : ''}${line}\n`;
}

export const configApi = {
  /**
   * Get configuration (JSON)
   */
  async getConfig(nodeConfig?: CpaNodeConnectionConfig): Promise<Config> {
    const raw = await apiClient.get<Record<string, unknown>>('/config', { nodeConfig });
    return { ...raw, raw };
  },

  /**
   * Get YAML configuration for editing
   */
  async getConfigYaml(nodeConfig?: CpaNodeConnectionConfig): Promise<string> {
    return await apiClient.get<string>('/config.yaml', {
      nodeConfig,
      headers: { 'Accept': 'application/yaml, text/yaml, text/plain' },
      responseType: 'text',
    });
  },

  /**
   * Update configuration via YAML
   */
  async updateConfigYaml(yamlContent: string, nodeConfig?: CpaNodeConnectionConfig): Promise<{ ok: boolean; changed?: string[] }> {
    return await apiClient.put<{ ok: boolean; changed?: string[] }>('/config.yaml', yamlContent, {
      nodeConfig,
      headers: { 'Content-Type': 'application/yaml' },
    });
  },

  /**
   * Update logging-to-file setting
   */
  async updateLoggingToFile(enabled: boolean, nodeConfig?: CpaNodeConnectionConfig): Promise<{ ok: boolean; changed?: string[] }> {
    const yamlContent = await this.getConfigYaml(nodeConfig);
    const updatedYaml = upsertBooleanSetting(yamlContent, 'logging-to-file', enabled);
    return await this.updateConfigYaml(updatedYaml, nodeConfig);
  },
};