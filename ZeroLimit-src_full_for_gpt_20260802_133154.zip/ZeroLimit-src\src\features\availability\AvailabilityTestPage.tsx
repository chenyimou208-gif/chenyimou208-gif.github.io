import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import {
  Activity,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  FileJson,
  Loader2,
  Play,
  RefreshCw,
  Search,
  ShieldCheck,
  ShieldAlert,
  Trash2,
  Upload,
  XCircle,
} from 'lucide-react';
import { authFilesApi } from '@/services/api/auth.service';
import { apiCallApi, getApiCallErrorMessage } from '@/services/api/apiCall';
import type { ApiCallResult, AuthFile } from '@/types';
import { CODEX_HEADERS } from '@/constants';
import { resolveCodexChatgptAccountId } from '@/shared/utils/quota.helpers';
import { maskEmail } from '@/shared/utils/privacy';
import { Button } from '@/shared/components/ui/button';
import { Badge } from '@/shared/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/shared/components/ui/card';
import { Input } from '@/shared/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/shared/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/shared/components/ui/table';

type TestMode = 'codex-backend' | 'responses-api' | 'chat-completions';
type TestStatus = 'untested' | 'testing' | 'available' | 'failed';
type ResultFilter = 'all' | 'available' | 'failed' | 'untested';

interface AvailabilityAccount {
  key: string;
  name: string;
  filename: string;
  email: string;
  provider: string;
  disabled: boolean;
  authIndex: string;
  originalFile: AuthFile;
  status: TestStatus;
  statusCode?: number;
  message?: string;
  responseText?: string;
  testedAt?: string;
  durationMs?: number;
}

interface TestModeDefinition {
  value: TestMode;
  label: string;
  description: string;
}

interface TestOutcome {
  status: Extract<TestStatus, 'available' | 'failed'>;
  statusCode?: number;
  message: string;
  responseText?: string;
  testedAt: string;
  durationMs: number;
}

interface NewAuthTestResult extends TestOutcome {
  filename: string;
  email: string;
  kept: boolean;
}

const TEST_MODES: TestModeDefinition[] = [
  {
    value: 'codex-backend',
    label: 'Codex 专用入口',
    description: '测试 chatgpt.com/backend-api/codex/responses，最接近 Codex OAuth 账号真实使用。',
  },
  {
    value: 'responses-api',
    label: 'Responses API',
    description: '测试 api.openai.com/v1/responses，可识别缺少 responses 写权限的账号。',
  },
  {
    value: 'chat-completions',
    label: 'Chat Completions',
    description: '测试 api.openai.com/v1/chat/completions，可识别没有 active billing 的账号。',
  },
];

const TEST_MODELS = [
  { value: 'gpt-5.5', label: 'GPT-5.5' },
  { value: 'gpt-5.4-mini', label: 'GPT-5.4 Mini' },
  { value: 'gpt-5.4', label: 'GPT-5.4' },
  { value: 'gpt-4.1-mini', label: 'GPT-4.1 Mini' },
];

const BATCH_CONCURRENCY = 4;

function getAuthFileName(file: AuthFile, fallback = ''): string {
  return String(file.name || file.filename || file.id || fallback);
}

function getAuthFileStorageName(file: AuthFile, fallback = ''): string {
  const name = getAuthFileName(file, fallback);
  if (!name) return '';
  return name.toLowerCase().endsWith('.json') ? name : `${name}.json`;
}

function getAuthIndex(file: AuthFile, fallback = ''): string {
  return String(file.auth_index || file.authIndex || file.id || file.filename || file.name || fallback);
}

function getAccountEmail(file: AuthFile, fallback = ''): string {
  const value = file.account || file.email || file.label || file.name || file.filename || fallback;
  return String(value || fallback).replace(/\.json$/i, '');
}

function sanitizeFilenamePart(value: string): string {
  return value
    .trim()
    .replace(/\.json$/i, '')
    .replace(/[^a-zA-Z0-9@._-]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 80) || 'account';
}

function buildTempAuthFilename(file: AuthFile, sourceName = ''): string {
  const email = getAccountEmail(file, sourceName || 'account');
  const safeEmail = sanitizeFilenamePart(email);
  return `zerolimit-test-${Date.now()}-${safeEmail}.json`;
}

function isAuthFileDisabled(file: AuthFile): boolean {
  const value = file.disabled ?? file.is_disabled ?? file.isDisabled;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value === 1;
  if (typeof value === 'string') {
    return ['true', '1', 'yes', 'on'].includes(value.trim().toLowerCase());
  }
  return false;
}

function isCodexAuthFile(file: AuthFile): boolean {
  const provider = String(file.provider || file.type || '').toLowerCase();
  const name = getAuthFileName(file).toLowerCase();
  const account = String(file.account || file.email || '').toLowerCase();

  return (
    provider.includes('codex') ||
    name.includes('codex') ||
    name.endsWith('@outlook.com.json') ||
    account.endsWith('@outlook.com') ||
    String(file.type || '').toLowerCase() === 'codex'
  );
}

function extractAuthFiles(body: unknown): AuthFile[] {
  if (Array.isArray(body)) return body as AuthFile[];
  if (!body || typeof body !== 'object') return [];

  const record = body as Record<string, unknown>;
  for (const key of ['files', 'items', 'data', 'auth_files', 'authFiles']) {
    const value = record[key];
    if (Array.isArray(value)) return value as AuthFile[];
    if (value && typeof value === 'object') {
      const nested = value as Record<string, unknown>;
      for (const nestedKey of ['files', 'items', 'data']) {
        if (Array.isArray(nested[nestedKey])) return nested[nestedKey] as AuthFile[];
      }
    }
  }

  return [];
}

function normalizeDownloadedAuth(data: unknown): AuthFile | null {
  if (!data) return null;
  if (typeof data === 'string') {
    try {
      return JSON.parse(data) as AuthFile;
    } catch {
      return null;
    }
  }
  if (typeof data === 'object' && !Array.isArray(data)) return data as AuthFile;
  return null;
}

function parseAuthJson(content: string): AuthFile {
  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    throw new Error('不是有效 JSON。请使用 CPA/sub2api 导出的授权 JSON 文件。');
  }

  if (Array.isArray(parsed)) {
    if (parsed.length !== 1) {
      throw new Error('新号测试一次只支持 1 个 JSON。多个账号请分开测试。');
    }
    parsed = parsed[0];
  }

  if (!parsed || typeof parsed !== 'object') {
    throw new Error('JSON 内容不是账号授权对象。');
  }

  const record = parsed as Record<string, unknown>;
  const hasToken =
    typeof record.access_token === 'string' ||
    typeof record.refresh_token === 'string' ||
    typeof record.id_token === 'string';

  if (!hasToken) {
    throw new Error('没有找到 access_token / refresh_token / id_token，不能作为 CPA 授权 JSON 测试。');
  }

  return parsed as AuthFile;
}

function createAuthUploadForm(content: string, filename: string): FormData {
  const blob = new Blob([content], { type: 'application/json' });
  const formData = new FormData();
  formData.append('file', blob, filename);
  return formData;
}

function compactText(value: unknown, limit = 220): string {
  if (value === undefined || value === null) return '';
  const text = typeof value === 'string' ? value : JSON.stringify(value);
  return text.replace(/\s+/g, ' ').trim().slice(0, limit);
}

function walkText(value: unknown, depth = 0): string {
  if (depth > 4 || value === undefined || value === null) return '';

  if (typeof value === 'string') {
    return value.length > 0 && value.length < 500 ? value : '';
  }

  if (Array.isArray(value)) {
    return value.map(item => walkText(item, depth + 1)).filter(Boolean).join('');
  }

  if (typeof value === 'object') {
    const record = value as Record<string, unknown>;
    const type = String(record.type || '');
    if (['output_text', 'text_delta', 'response.output_text.delta'].includes(type)) {
      return compactText(record.text ?? record.delta, 500);
    }
    if (typeof record.text === 'string' && ['message', 'output_text'].includes(type)) {
      return record.text;
    }
    if (typeof record.content === 'string' && type === 'message') {
      return record.content;
    }

    for (const key of ['output_text', 'text', 'content', 'delta', 'message', 'output', 'choices']) {
      const text = walkText(record[key], depth + 1);
      if (text) return text;
    }
  }

  return '';
}

function extractResponseText(result: ApiCallResult): string {
  const body = result.body;

  if (body && typeof body === 'object') {
    const record = body as Record<string, unknown>;
    const choices = record.choices;
    if (Array.isArray(choices) && choices.length > 0) {
      const message = (choices[0] as Record<string, unknown>)?.message;
      const content = message && typeof message === 'object'
        ? (message as Record<string, unknown>).content
        : undefined;
      const text = walkText(content);
      if (text) return text;
    }

    const output = record.output;
    const outputText = walkText(output);
    if (outputText) return outputText;
  }

  const bodyText = result.bodyText || '';
  if (bodyText.includes('data:')) {
    const pieces: string[] = [];
    for (const line of bodyText.split(/\r?\n/)) {
      const trimmed = line.trim();
      if (!trimmed.startsWith('data:')) continue;
      const payload = trimmed.slice(5).trim();
      if (!payload || payload === '[DONE]') continue;
      try {
        const parsed = JSON.parse(payload);
        const text = walkText(parsed);
        if (text) pieces.push(text);
      } catch {
        // Ignore malformed SSE fragments.
      }
    }
    if (pieces.length > 0) return pieces.join('').trim();
  }

  return walkText(body);
}

function isCodexBackendSuccess(result: ApiCallResult, responseText: string): boolean {
  if (result.statusCode < 200 || result.statusCode >= 300) return false;
  if (responseText.trim()) return true;

  const bodyText = result.bodyText || '';
  if (bodyText.includes('response.failed') || bodyText.includes('response.incomplete')) return false;
  return bodyText.includes('response.completed');
}

function classifyMessage(result: ApiCallResult): string {
  const status = result.statusCode;
  const raw = getApiCallErrorMessage(result);
  const text = raw || compactText(result.bodyText || result.body);

  if (status === 401) {
    if (/scope|permission|permissions/i.test(text)) return `401 权限不足：${text}`;
    return `401 token 失效或未授权：${text}`;
  }
  if (status === 403) return `403 IP/权限被拒绝：${text}`;
  if (status === 429) return `429 额度或账号状态限制：${text}`;
  if (status >= 500) return `${status} 上游服务异常：${text}`;
  if (status > 0) return text || `HTTP ${status}`;
  return text || '请求失败';
}

function buildTestPayload(
  mode: TestMode,
  account: AvailabilityAccount,
  accountId: string | null,
  model: string,
  prompt: string,
) {
  if (mode === 'chat-completions') {
    return {
      authIndex: account.authIndex,
      method: 'POST',
      url: 'https://api.openai.com/v1/chat/completions',
      header: {
        Authorization: 'Bearer $TOKEN$',
        'Content-Type': 'application/json',
      },
      data: JSON.stringify({
        model,
        messages: [{ role: 'user', content: prompt }],
        stream: false,
      }),
    };
  }

  if (mode === 'responses-api') {
    return {
      authIndex: account.authIndex,
      method: 'POST',
      url: 'https://api.openai.com/v1/responses',
      header: {
        Authorization: 'Bearer $TOKEN$',
        'Content-Type': 'application/json',
      },
      data: JSON.stringify({
        model,
        input: prompt,
        stream: false,
      }),
    };
  }

  const headers: Record<string, string> = {
    ...CODEX_HEADERS,
    Accept: 'text/event-stream',
    Originator: 'codex_cli_rs',
    'X-Client-Request-Id': `zerolimit-availability-${Date.now()}`,
  };
  if (accountId) {
    headers['Chatgpt-Account-Id'] = accountId;
  }

  return {
    authIndex: account.authIndex,
    method: 'POST',
    url: 'https://chatgpt.com/backend-api/codex/responses',
    header: headers,
    data: JSON.stringify({
      model,
      input: [{ role: 'user', content: prompt }],
      store: false,
      stream: true,
    }),
  };
}

async function runWithConcurrency<T>(
  items: T[],
  limit: number,
  worker: (item: T) => Promise<void>,
) {
  let nextIndex = 0;
  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (nextIndex < items.length) {
      const item = items[nextIndex++];
      await worker(item);
    }
  });
  await Promise.all(runners);
}

export function AvailabilityTestPage() {
  const { t } = useTranslation();
  const [accounts, setAccounts] = useState<AvailabilityAccount[]>([]);
  const [loading, setLoading] = useState(false);
  const [testingAll, setTestingAll] = useState(false);
  const [deletingFailed, setDeletingFailed] = useState(false);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<ResultFilter>('all');
  const [mode, setMode] = useState<TestMode>('codex-backend');
  const [model, setModel] = useState('gpt-5.5');
  const [prompt, setPrompt] = useState('hi');
  const [isPrivacyMode, setIsPrivacyMode] = useState(false);
  const [newAuthText, setNewAuthText] = useState('');
  const [testingNewAuth, setTestingNewAuth] = useState(false);
  const [keepNewAuthIfAvailable, setKeepNewAuthIfAvailable] = useState(false);
  const [newAuthResult, setNewAuthResult] = useState<NewAuthTestResult | null>(null);
  const runningRef = useRef(false);

  const updateAccount = useCallback((key: string, patch: Partial<AvailabilityAccount>) => {
    setAccounts(prev => prev.map(account => (
      account.key === key ? { ...account, ...patch } : account
    )));
  }, []);

  const loadAccounts = useCallback(async () => {
    setLoading(true);
    try {
      const resp = await authFilesApi.list();
      const files = extractAuthFiles(resp)
        .filter(isCodexAuthFile)
        .map((file, index): AvailabilityAccount => {
          const name = getAuthFileName(file, String(index));
          const filename = getAuthFileStorageName(file, name);
          const email = getAccountEmail(file, filename);
          return {
            key: getAuthIndex(file, filename) || filename || String(index),
            name,
            filename,
            email,
            provider: String(file.provider || file.type || 'codex'),
            disabled: isAuthFileDisabled(file),
            authIndex: getAuthIndex(file, filename),
            originalFile: file,
            status: 'untested',
          };
        })
        .sort((a, b) => a.email.localeCompare(b.email));

      setAccounts(files);
    } catch (error) {
      toast.error(`加载账号失败：${(error as Error).message}`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadAccounts();
  }, [loadAccounts]);

  const getFullAuthFile = useCallback(async (account: AvailabilityAccount): Promise<AuthFile> => {
    const downloaded = await authFilesApi.download(account.filename);
    return normalizeDownloadedAuth(downloaded) || account.originalFile;
  }, []);

  const runAvailabilityTest = useCallback(async (account: AvailabilityAccount): Promise<TestOutcome> => {
    const startedAt = performance.now();
    try {
      const fullAuthFile = await getFullAuthFile(account);
      const accountId = resolveCodexChatgptAccountId(fullAuthFile) || resolveCodexChatgptAccountId(account.originalFile);
      const result = await apiCallApi.request(
        buildTestPayload(mode, account, accountId, model, prompt.trim() || 'hi'),
        { timeout: 120000 },
      );
      const responseText = extractResponseText(result);
      const ok = mode === 'codex-backend'
        ? isCodexBackendSuccess(result, responseText)
        : result.statusCode >= 200 && result.statusCode < 300 && Boolean(responseText.trim());
      const durationMs = Math.round(performance.now() - startedAt);

      return {
        status: ok ? 'available' : 'failed',
        statusCode: result.statusCode,
        responseText: responseText ? compactText(responseText, 180) : (ok ? 'HTTP 200 / response.completed' : undefined),
        message: ok ? '测试完成' : classifyMessage(result),
        testedAt: new Date().toLocaleString('zh-CN', { hour12: false }),
        durationMs,
      };
    } catch (error) {
      return {
        status: 'failed',
        message: (error as Error).message || '测试失败',
        testedAt: new Date().toLocaleString('zh-CN', { hour12: false }),
        durationMs: Math.round(performance.now() - startedAt),
      };
    }
  }, [getFullAuthFile, mode, model, prompt]);

  const testAccount = useCallback(async (account: AvailabilityAccount) => {
    if (!account.authIndex || account.disabled) return;

    updateAccount(account.key, {
      status: 'testing',
      statusCode: undefined,
      message: undefined,
      responseText: undefined,
      durationMs: undefined,
    });

    const outcome = await runAvailabilityTest(account);
    updateAccount(account.key, outcome);
  }, [runAvailabilityTest, updateAccount]);

  const findImportedAccount = useCallback(async (
    filename: string,
    originalFile: AuthFile,
  ): Promise<AvailabilityAccount> => {
    const resp = await authFilesApi.list();
    const normalizedFilename = filename.toLowerCase();
    const file = extractAuthFiles(resp).find(item => {
      const storageName = getAuthFileStorageName(item, getAuthFileName(item));
      return storageName.toLowerCase() === normalizedFilename ||
        getAuthFileName(item).toLowerCase() === normalizedFilename;
    });

    if (!file) {
      throw new Error('临时导入成功，但 CPA 列表里没有找到这个账号，请刷新后再试。');
    }

    const name = getAuthFileName(file, filename);
    const storageName = getAuthFileStorageName(file, filename);
    const email = getAccountEmail(file, storageName);

    return {
      key: getAuthIndex(file, storageName) || storageName,
      name,
      filename: storageName,
      email,
      provider: String(file.provider || file.type || originalFile.provider || originalFile.type || 'codex'),
      disabled: isAuthFileDisabled(file),
      authIndex: getAuthIndex(file, storageName),
      originalFile: file,
      status: 'untested',
    };
  }, []);

  const testNewAuthContent = useCallback(async (content: string, sourceName = '粘贴 JSON') => {
    const trimmed = content.trim();
    if (!trimmed) {
      toast.info('请先选择或粘贴一个 CPA 授权 JSON');
      return;
    }

    setTestingNewAuth(true);
    setNewAuthResult(null);

    let tempFilename = '';
    try {
      const parsedAuth = parseAuthJson(trimmed);
      const uploadAuth = {
        ...parsedAuth,
        disabled: false,
        source: '新号测试',
      } as AuthFile;
      tempFilename = buildTempAuthFilename(uploadAuth, sourceName);
      const uploadContent = JSON.stringify(uploadAuth, null, 2);

      await authFilesApi.upload(createAuthUploadForm(uploadContent, tempFilename));
      const account = await findImportedAccount(tempFilename, uploadAuth);
      const outcome = await runAvailabilityTest(account);
      const kept = outcome.status === 'available' && keepNewAuthIfAvailable;

      if (!kept) {
        await authFilesApi.deleteFile(tempFilename);
      }

      setNewAuthResult({
        ...outcome,
        filename: tempFilename,
        email: account.email,
        kept,
      });

      if (outcome.status === 'available') {
        toast.success(kept ? '新号可用，已保留到 CPA' : '新号可用，临时文件已删除');
      } else {
        toast.error('新号不可用，临时文件已删除');
      }

      await loadAccounts();
    } catch (error) {
      if (tempFilename) {
        try {
          await authFilesApi.deleteFile(tempFilename);
        } catch (deleteError) {
          console.warn('Failed to clean temporary auth file:', deleteError);
        }
      }

      const message = (error as Error).message || '新号测试失败';
      setNewAuthResult({
        status: 'failed',
        message,
        testedAt: new Date().toLocaleString('zh-CN', { hour12: false }),
        durationMs: 0,
        filename: tempFilename || sourceName,
        email: '-',
        kept: false,
      });
      toast.error(message);
      await loadAccounts();
    } finally {
      setTestingNewAuth(false);
    }
  }, [findImportedAccount, keepNewAuthIfAvailable, loadAccounts, runAvailabilityTest]);

  const chooseAndTestNewAuthFile = useCallback(async () => {
    try {
      const { open } = await import('@tauri-apps/plugin-dialog');
      const { readTextFile } = await import('@tauri-apps/plugin-fs');
      const { basename } = await import('@tauri-apps/api/path');

      const selectedPath = await open({
        multiple: false,
        filters: [{ name: 'CPA JSON', extensions: ['json'] }],
      });
      if (!selectedPath || Array.isArray(selectedPath)) return;

      const content = await readTextFile(selectedPath);
      const name = await basename(selectedPath);
      setNewAuthText(content);
      await testNewAuthContent(content, name);
    } catch (error) {
      toast.error(`读取 JSON 失败：${(error as Error).message}`);
    }
  }, [testNewAuthContent]);

  const testEnabledAccounts = useCallback(async () => {
    const targets = accounts.filter(account => !account.disabled);
    if (targets.length === 0) {
      toast.info('没有已启用账号可测试');
      return;
    }

    runningRef.current = true;
    setTestingAll(true);
    try {
      await runWithConcurrency(targets, BATCH_CONCURRENCY, async (account) => {
        if (!runningRef.current) return;
        await testAccount(account);
      });
      toast.success('可用性测试完成');
    } finally {
      runningRef.current = false;
      setTestingAll(false);
    }
  }, [accounts, testAccount]);

  const stopBatch = useCallback(() => {
    runningRef.current = false;
    setTestingAll(false);
  }, []);

  const deleteAccount = useCallback(async (account: AvailabilityAccount) => {
    if (!account.filename) return;
    await authFilesApi.deleteFile(account.filename);
    setAccounts(prev => prev.filter(item => item.key !== account.key));
    toast.success('账号已删除');
  }, []);

  const deleteFailedAccounts = useCallback(async () => {
    const targets = accounts.filter(account => account.status === 'failed');
    if (targets.length === 0) {
      toast.info('没有失败账号可删除');
      return;
    }
    if (!window.confirm(`确定删除 ${targets.length} 个可用性测试失败账号吗？此操作无法撤销。`)) return;

    setDeletingFailed(true);
    let deletedCount = 0;
    try {
      for (const account of targets) {
        try {
          await authFilesApi.deleteFile(account.filename);
          deletedCount++;
        } catch (error) {
          console.error('Failed to delete unavailable account:', account.filename, error);
        }
      }
      setAccounts(prev => prev.filter(account => account.status !== 'failed'));
      toast.success(`已删除 ${deletedCount} 个失败账号`);
    } finally {
      setDeletingFailed(false);
    }
  }, [accounts]);

  const stats = useMemo(() => {
    return accounts.reduce(
      (acc, account) => {
        acc.total++;
        acc[account.status]++;
        if (account.disabled) acc.disabled++;
        return acc;
      },
      { total: 0, available: 0, failed: 0, testing: 0, untested: 0, disabled: 0 },
    );
  }, [accounts]);

  const filteredAccounts = useMemo(() => {
    const term = search.trim().toLowerCase();
    return accounts.filter(account => {
      if (filter !== 'all' && account.status !== filter) return false;
      if (!term) return true;
      return (
        account.email.toLowerCase().includes(term) ||
        account.filename.toLowerCase().includes(term) ||
        account.message?.toLowerCase().includes(term)
      );
    });
  }, [accounts, filter, search]);

  const modeDescription = TEST_MODES.find(item => item.value === mode)?.description || '';

  const renderStatusBadge = (account: AvailabilityAccount) => {
    if (account.disabled) {
      return <Badge variant="outline" className="border-yellow-500/40 bg-yellow-500/10 text-yellow-700">已停用</Badge>;
    }
    if (account.status === 'available') {
      return <Badge className="bg-green-600 text-white"><CheckCircle2 className="mr-1 h-3 w-3" />可用</Badge>;
    }
    if (account.status === 'failed') {
      return <Badge variant="destructive"><XCircle className="mr-1 h-3 w-3" />失败</Badge>;
    }
    if (account.status === 'testing') {
      return <Badge variant="secondary"><Loader2 className="mr-1 h-3 w-3 animate-spin" />测试中</Badge>;
    }
    return <Badge variant="outline"><Clock className="mr-1 h-3 w-3" />未测试</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">{t('availability.title', '可用性测试')}</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            对 CPA 账号发起一条极短真实请求，判断账号能不能正常返回。
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" onClick={() => setIsPrivacyMode(value => !value)}>
            {isPrivacyMode ? '显示邮箱' : '隐藏邮箱'}
          </Button>
          <Button variant="outline" onClick={loadAccounts} disabled={loading || testingAll}>
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            刷新账号
          </Button>
          {testingAll ? (
            <Button variant="outline" onClick={stopBatch}>
              停止批量
            </Button>
          ) : (
            <Button onClick={testEnabledAccounts} disabled={loading || accounts.length === 0}>
              <Play className="mr-2 h-4 w-4" />
              测试已导入启用
            </Button>
          )}
          <Button
            variant="outline"
            className="text-destructive hover:bg-destructive/10 hover:text-destructive"
            onClick={deleteFailedAccounts}
            disabled={deletingFailed || stats.failed === 0 || testingAll}
          >
            {deletingFailed ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
            删除已导入失败（{stats.failed}）
          </Button>
        </div>
      </div>

      <Card className="border">
        <CardHeader className="border-b p-4">
          <CardTitle className="flex items-center gap-2 text-lg">
            <ShieldCheck className="h-5 w-5" />
            新号测试
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 p-4 lg:grid-cols-[minmax(0,1fr)_360px]">
          <div className="space-y-3">
            <textarea
              value={newAuthText}
              onChange={(event) => setNewAuthText(event.target.value)}
              placeholder="粘贴单个 CPA 授权 JSON"
              className="min-h-[132px] w-full resize-y rounded-md border border-input bg-background px-3 py-2 font-mono text-xs outline-none transition-colors placeholder:text-muted-foreground focus:border-ring focus:ring-[3px] focus:ring-ring/20"
              disabled={testingNewAuth}
            />
            <div className="flex flex-wrap items-center gap-2">
              <Button onClick={chooseAndTestNewAuthFile} disabled={testingNewAuth || testingAll}>
                {testingNewAuth ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
                选择 JSON 并测试
              </Button>
              <Button
                variant="outline"
                onClick={() => void testNewAuthContent(newAuthText)}
                disabled={testingNewAuth || testingAll || !newAuthText.trim()}
              >
                {testingNewAuth ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ClipboardCheck className="mr-2 h-4 w-4" />}
                测试粘贴内容
              </Button>
              <label className="flex cursor-pointer items-center gap-2 text-sm text-muted-foreground">
                <input
                  type="checkbox"
                  checked={keepNewAuthIfAvailable}
                  onChange={(event) => setKeepNewAuthIfAvailable(event.target.checked)}
                  className="h-4 w-4 rounded border-input"
                  disabled={testingNewAuth}
                />
                可用就保留到 CPA
              </label>
            </div>
          </div>
          <div className="rounded-md border bg-muted/20 p-4">
            {newAuthResult ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2 font-medium">
                    <FileJson className="h-4 w-4" />
                    {isPrivacyMode ? maskEmail(newAuthResult.email) : newAuthResult.email}
                  </div>
                  {newAuthResult.status === 'available' ? (
                    <Badge className="bg-green-600 text-white">
                      <CheckCircle2 className="mr-1 h-3 w-3" />
                      可用
                    </Badge>
                  ) : (
                    <Badge variant="destructive">
                      <XCircle className="mr-1 h-3 w-3" />
                      失败
                    </Badge>
                  )}
                </div>
                <div className="text-sm">{newAuthResult.message}</div>
                {newAuthResult.responseText && (
                  <div className="rounded bg-background px-2 py-1 font-mono text-xs text-green-700 dark:text-green-300">
                    {newAuthResult.responseText}
                  </div>
                )}
                <div className="space-y-1 text-xs text-muted-foreground">
                  {newAuthResult.statusCode !== undefined && <div>HTTP {newAuthResult.statusCode}</div>}
                  <div>{newAuthResult.testedAt}</div>
                  <div>{newAuthResult.durationMs} ms</div>
                  <div>{newAuthResult.kept ? `已保留：${newAuthResult.filename}` : '临时测试文件已删除'}</div>
                </div>
              </div>
            ) : (
              <div className="flex h-full min-h-[132px] flex-col items-center justify-center text-center text-sm text-muted-foreground">
                <ShieldCheck className="mb-3 h-8 w-8" />
                默认临时导入测试，测完自动删除
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="border">
        <CardContent className="grid gap-4 p-4 md:grid-cols-2 xl:grid-cols-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">选择测试模型</label>
            <Select value={model} onValueChange={setModel} disabled={testingAll}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TEST_MODELS.map(item => (
                  <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">测试模式</label>
            <Select value={mode} onValueChange={(value) => setMode(value as TestMode)} disabled={testingAll}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TEST_MODES.map(item => (
                  <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">提示词</label>
            <Input value={prompt} onChange={(event) => setPrompt(event.target.value)} disabled={testingAll} />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">筛选</label>
            <Select value={filter} onValueChange={(value) => setFilter(value as ResultFilter)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部</SelectItem>
                <SelectItem value="available">可用</SelectItem>
                <SelectItem value="failed">失败</SelectItem>
                <SelectItem value="untested">未测试</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="md:col-span-2 xl:col-span-4">
            <div className="flex items-center gap-2 rounded-md bg-muted/40 px-3 py-2 text-sm text-muted-foreground">
              <Activity className="h-4 w-4" />
              <span>{modeDescription}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <Card className="border"><CardContent className="p-4"><div className="text-2xl font-bold">{stats.total}</div><div className="text-sm text-muted-foreground">已导入账号总数</div></CardContent></Card>
        <Card className="border"><CardContent className="p-4"><div className="text-2xl font-bold text-green-600">{stats.available}</div><div className="text-sm text-muted-foreground">可用</div></CardContent></Card>
        <Card className="border"><CardContent className="p-4"><div className="text-2xl font-bold text-destructive">{stats.failed}</div><div className="text-sm text-muted-foreground">失败</div></CardContent></Card>
        <Card className="border"><CardContent className="p-4"><div className="text-2xl font-bold">{stats.untested}</div><div className="text-sm text-muted-foreground">未测试</div></CardContent></Card>
        <Card className="border"><CardContent className="p-4"><div className="text-2xl font-bold text-yellow-700">{stats.disabled}</div><div className="text-sm text-muted-foreground">已停用</div></CardContent></Card>
      </div>

      <Card className="border">
        <CardHeader className="border-b p-4">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <CardTitle className="text-lg">账号列表</CardTitle>
            <div className="relative w-full lg:w-[360px]">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="搜索邮箱/文件名/错误"
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[260px]">账号</TableHead>
                <TableHead>状态</TableHead>
                <TableHead>结果</TableHead>
                <TableHead>响应</TableHead>
                <TableHead className="w-[180px]">时间</TableHead>
                <TableHead className="w-[170px] text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAccounts.map(account => (
                <TableRow key={account.key}>
                  <TableCell>
                    <div className="font-medium">{isPrivacyMode ? maskEmail(account.email) : account.email}</div>
                    <div className="text-xs text-muted-foreground">{account.filename}</div>
                  </TableCell>
                  <TableCell>{renderStatusBadge(account)}</TableCell>
                  <TableCell className="max-w-[360px] whitespace-normal">
                    <div className="text-sm">{account.message || '-'}</div>
                    {account.statusCode !== undefined && (
                      <div className="mt-1 text-xs text-muted-foreground">HTTP {account.statusCode}</div>
                    )}
                  </TableCell>
                  <TableCell className="max-w-[260px] whitespace-normal">
                    {account.responseText ? (
                      <span className="font-mono text-xs text-green-700 dark:text-green-300">{account.responseText}</span>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="text-xs text-muted-foreground">{account.testedAt || '-'}</div>
                    {account.durationMs !== undefined && (
                      <div className="text-xs text-muted-foreground">{account.durationMs} ms</div>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => void testAccount(account)}
                        disabled={testingAll || account.disabled || account.status === 'testing'}
                        title={account.disabled ? '已停用账号不参与测试' : '可用性测试'}
                      >
                        {account.status === 'testing' ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Play className="h-4 w-4" />
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                        onClick={() => {
                          if (window.confirm(`确定删除 ${account.filename} 吗？`)) {
                            void deleteAccount(account);
                          }
                        }}
                        disabled={account.status === 'testing'}
                        title="删除"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {!loading && filteredAccounts.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="py-12 text-center text-muted-foreground">
                    <ShieldAlert className="mx-auto mb-3 h-8 w-8" />
                    没有符合条件的账号
                  </TableCell>
                </TableRow>
              )}
              {loading && (
                <TableRow>
                  <TableCell colSpan={6} className="py-12 text-center text-muted-foreground">
                    <Loader2 className="mx-auto mb-3 h-8 w-8 animate-spin" />
                    正在加载账号
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
