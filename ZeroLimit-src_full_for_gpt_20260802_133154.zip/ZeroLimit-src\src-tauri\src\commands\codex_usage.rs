use crate::error::{CommandError, CommandResult};
use serde::Serialize;
use serde_json::Value;
use std::collections::HashSet;
use std::fs::{self, File};
use std::io::{BufRead, BufReader};
use std::path::{Path, PathBuf};
use std::time::{Duration, SystemTime};
use tauri::command;

const MAX_SESSION_FILES_PER_HOME: usize = 250;
const MAX_TOKEN_EVENTS_RETURNED: usize = 5000;
const SESSION_LOOKBACK_DAYS: u64 = 7;

#[derive(Debug, Default, Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct TokenUsage {
    pub input_tokens: u64,
    pub cached_input_tokens: u64,
    pub output_tokens: u64,
    pub reasoning_output_tokens: u64,
    pub total_tokens: u64,
}

#[derive(Debug, Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct CodexRateLimit {
    pub limit_id: Option<String>,
    pub plan_type: Option<String>,
    pub used_percent: Option<f64>,
    pub window_minutes: Option<u64>,
    pub resets_at: Option<u64>,
    pub rate_limit_reached_type: Option<String>,
}

#[derive(Debug, Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct CodexTokenEvent {
    pub timestamp: String,
    pub codex_home: String,
    pub codex_home_name: String,
    pub session_id: Option<String>,
    pub cwd: Option<String>,
    pub total: TokenUsage,
    pub last: TokenUsage,
    pub model_context_window: Option<u64>,
    pub rate_limit: Option<CodexRateLimit>,
}

#[derive(Debug, Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct CodexHomeSummary {
    pub name: String,
    pub path: String,
    pub sessions_scanned: usize,
    pub token_events: usize,
    pub last_updated: Option<String>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CodexTokenUsageReport {
    pub codex_home: String,
    pub codex_homes: Vec<CodexHomeSummary>,
    pub sessions_scanned: usize,
    pub token_events: usize,
    pub last_updated: Option<String>,
    pub events: Vec<CodexTokenEvent>,
}

fn number_as_u64(value: Option<&Value>) -> u64 {
    match value {
        Some(Value::Number(number)) => number
            .as_u64()
            .unwrap_or_else(|| number.as_f64().unwrap_or(0.0).max(0.0) as u64),
        Some(Value::String(text)) => text.parse::<u64>().unwrap_or(0),
        _ => 0,
    }
}

fn number_as_f64(value: Option<&Value>) -> Option<f64> {
    match value {
        Some(Value::Number(number)) => number.as_f64(),
        Some(Value::String(text)) => text.parse::<f64>().ok(),
        _ => None,
    }
}

fn string_value(value: Option<&Value>) -> Option<String> {
    value.and_then(|item| item.as_str().map(|text| text.to_string()))
}

fn parse_token_usage(value: Option<&Value>) -> TokenUsage {
    let Some(value) = value else {
        return TokenUsage::default();
    };

    TokenUsage {
        input_tokens: number_as_u64(
            value
                .get("input_tokens")
                .or_else(|| value.get("inputTokens")),
        ),
        cached_input_tokens: number_as_u64(
            value
                .get("cached_input_tokens")
                .or_else(|| value.get("cachedInputTokens")),
        ),
        output_tokens: number_as_u64(
            value
                .get("output_tokens")
                .or_else(|| value.get("outputTokens")),
        ),
        reasoning_output_tokens: number_as_u64(
            value
                .get("reasoning_output_tokens")
                .or_else(|| value.get("reasoningOutputTokens")),
        ),
        total_tokens: number_as_u64(
            value
                .get("total_tokens")
                .or_else(|| value.get("totalTokens")),
        ),
    }
}

fn parse_rate_limit(value: Option<&Value>) -> Option<CodexRateLimit> {
    let value = value?;
    let primary = value.get("primary");

    Some(CodexRateLimit {
        limit_id: string_value(value.get("limit_id").or_else(|| value.get("limitId"))),
        plan_type: string_value(value.get("plan_type").or_else(|| value.get("planType"))),
        used_percent: number_as_f64(
            primary.and_then(|item| item.get("used_percent").or_else(|| item.get("usedPercent"))),
        ),
        window_minutes: primary
            .and_then(|item| {
                item.get("window_minutes")
                    .or_else(|| item.get("windowMinutes"))
            })
            .map(|item| number_as_u64(Some(item))),
        resets_at: primary
            .and_then(|item| item.get("resets_at").or_else(|| item.get("resetsAt")))
            .map(|item| number_as_u64(Some(item))),
        rate_limit_reached_type: string_value(
            value
                .get("rate_limit_reached_type")
                .or_else(|| value.get("rateLimitReachedType")),
        ),
    })
}

fn visit_jsonl_files(dir: &Path, output: &mut Vec<PathBuf>) -> std::io::Result<()> {
    if !dir.exists() {
        return Ok(());
    }

    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let path = entry.path();
        if path.is_dir() {
            visit_jsonl_files(&path, output)?;
        } else if path.extension().and_then(|ext| ext.to_str()) == Some("jsonl") {
            output.push(path);
        }
    }

    Ok(())
}

fn get_modified_time(path: &Path) -> Option<SystemTime> {
    fs::metadata(path)
        .and_then(|metadata| metadata.modified())
        .ok()
}

fn is_active_codex_home_name(name: &str) -> bool {
    name == ".codex"
        || name
            .strip_prefix(".codex-")
            .map(|suffix| !suffix.is_empty() && suffix.chars().all(|ch| ch.is_ascii_digit()))
            .unwrap_or(false)
}

fn add_codex_home(path: PathBuf, homes: &mut Vec<PathBuf>, seen: &mut HashSet<String>) {
    if !path.join("sessions").is_dir() {
        return;
    }

    let key = path.to_string_lossy().to_lowercase();
    if seen.insert(key) {
        homes.push(path);
    }
}

fn find_codex_homes(user_home: &Path) -> Vec<PathBuf> {
    let mut homes = Vec::new();
    let mut seen = HashSet::new();

    add_codex_home(user_home.join(".codex"), &mut homes, &mut seen);

    if let Ok(value) = std::env::var("CODEX_HOME") {
        add_codex_home(PathBuf::from(value), &mut homes, &mut seen);
    }

    if let Ok(entries) = fs::read_dir(user_home) {
        let mut siblings = entries
            .flatten()
            .filter_map(|entry| {
                let name = entry.file_name().to_string_lossy().to_string();
                is_active_codex_home_name(&name).then_some((name, entry.path()))
            })
            .collect::<Vec<_>>();

        siblings.sort_by(|a, b| a.0.cmp(&b.0));

        for (_, path) in siblings {
            add_codex_home(path, &mut homes, &mut seen);
        }
    }

    homes
}

fn select_recent_session_files(mut files: Vec<PathBuf>) -> Vec<PathBuf> {
    let now = SystemTime::now();
    let lookback = Duration::from_secs(SESSION_LOOKBACK_DAYS * 24 * 60 * 60);

    files.sort_by(|a, b| get_modified_time(b).cmp(&get_modified_time(a)));

    let recent = files
        .iter()
        .filter(|path| {
            get_modified_time(path)
                .and_then(|modified| now.duration_since(modified).ok())
                .map(|age| age <= lookback)
                .unwrap_or(true)
        })
        .take(MAX_SESSION_FILES_PER_HOME)
        .cloned()
        .collect::<Vec<_>>();

    if recent.is_empty() {
        files.into_iter().take(MAX_SESSION_FILES_PER_HOME).collect()
    } else {
        recent
    }
}

fn parse_session_file(
    path: &Path,
    codex_home: &Path,
    codex_home_name: &str,
    events: &mut Vec<CodexTokenEvent>,
) -> std::io::Result<usize> {
    let file = File::open(path)?;
    let reader = BufReader::new(file);
    let mut session_id: Option<String> = None;
    let mut cwd: Option<String> = None;
    let start_len = events.len();

    for line in reader.lines() {
        let line = line?;
        if !line.contains("token_count") && !line.contains("session_meta") {
            continue;
        }

        let Ok(record) = serde_json::from_str::<Value>(&line) else {
            continue;
        };
        let record_type = record.get("type").and_then(Value::as_str);
        let payload = record.get("payload").unwrap_or(&Value::Null);

        if record_type == Some("session_meta") {
            session_id = string_value(payload.get("id"));
            cwd = string_value(payload.get("cwd"));
            continue;
        }

        if record_type != Some("event_msg")
            || payload.get("type").and_then(Value::as_str) != Some("token_count")
        {
            continue;
        }

        let info = payload.get("info").unwrap_or(&Value::Null);
        let timestamp = record
            .get("timestamp")
            .and_then(Value::as_str)
            .unwrap_or_default()
            .to_string();

        events.push(CodexTokenEvent {
            timestamp,
            codex_home: codex_home.to_string_lossy().to_string(),
            codex_home_name: codex_home_name.to_string(),
            session_id: session_id.clone(),
            cwd: cwd.clone(),
            total: parse_token_usage(
                info.get("total_token_usage")
                    .or_else(|| info.get("totalTokenUsage")),
            ),
            last: parse_token_usage(
                info.get("last_token_usage")
                    .or_else(|| info.get("lastTokenUsage")),
            ),
            model_context_window: info
                .get("model_context_window")
                .or_else(|| info.get("modelContextWindow"))
                .map(|item| number_as_u64(Some(item))),
            rate_limit: parse_rate_limit(
                payload
                    .get("rate_limits")
                    .or_else(|| payload.get("rateLimits")),
            ),
        });
    }

    Ok(events.len() - start_len)
}

#[command]
pub async fn get_codex_token_usage() -> CommandResult<CodexTokenUsageReport> {
    let user_home =
        dirs::home_dir().ok_or_else(|| CommandError::General("无法定位用户目录".to_string()))?;
    let codex_homes = find_codex_homes(&user_home);
    let mut events = Vec::new();
    let mut home_summaries = Vec::new();

    for codex_home in codex_homes {
        let sessions_dir = codex_home.join("sessions");
        let home_name = codex_home
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or("Codex")
            .to_string();

        let mut files = Vec::new();
        visit_jsonl_files(&sessions_dir, &mut files)
            .map_err(|err| CommandError::General(format!("读取 Codex sessions 失败: {}", err)))?;

        let selected_files = select_recent_session_files(files);
        let start_len = events.len();
        let mut sessions_scanned = 0usize;

        for path in selected_files {
            if parse_session_file(&path, &codex_home, &home_name, &mut events).is_ok() {
                sessions_scanned += 1;
            }
        }

        let mut home_events = events[start_len..].to_vec();
        home_events.sort_by(|a, b| a.timestamp.cmp(&b.timestamp));

        home_summaries.push(CodexHomeSummary {
            name: home_name,
            path: codex_home.to_string_lossy().to_string(),
            sessions_scanned,
            token_events: home_events.len(),
            last_updated: home_events.last().map(|event| event.timestamp.clone()),
        });
    }

    events.sort_by(|a, b| a.timestamp.cmp(&b.timestamp));
    let token_events = events.len();
    let last_updated = events.last().map(|event| event.timestamp.clone());
    let sessions_scanned = home_summaries
        .iter()
        .map(|home| home.sessions_scanned)
        .sum();

    if events.len() > MAX_TOKEN_EVENTS_RETURNED {
        events = events.split_off(events.len() - MAX_TOKEN_EVENTS_RETURNED);
    }

    Ok(CodexTokenUsageReport {
        codex_home: home_summaries
            .first()
            .map(|home| home.path.clone())
            .unwrap_or_else(|| user_home.join(".codex").to_string_lossy().to_string()),
        codex_homes: home_summaries,
        sessions_scanned,
        token_events,
        last_updated,
        events,
    })
}
