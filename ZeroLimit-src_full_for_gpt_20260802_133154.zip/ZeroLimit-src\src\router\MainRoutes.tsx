/**
 * Main Routes Definition
 */

import { Navigate, useRoutes, type Location } from 'react-router-dom';
import { DashboardPage } from '@/features/dashboard/DashboardPage';
import { SettingsPage } from '@/features/settings/SettingsPage';
import { ProvidersPage } from '@/features/providers/ProvidersPage';
import { QuotaPage } from '@/features/quota/QuotaPage';
import { CodexUsagePage } from '@/features/codex-usage/CodexUsagePage';
import { AvailabilityTestPage } from '@/features/availability/AvailabilityTestPage';
import { ZeroQuotaPage } from '@/features/zero-quota/ZeroQuotaPage';
import { Sub2ApiPage } from '@/features/sub2api/Sub2ApiPage';
import { AboutPage } from '@/features/about/AboutPage';
import { LogsPage } from '@/features/logs/LogsPage';

const mainRoutes = [
  { path: '/', element: <QuotaPage /> },
  { path: '/dashboard', element: <DashboardPage /> },
  { path: '/codex-usage', element: <CodexUsagePage /> },
  { path: '/availability-test', element: <AvailabilityTestPage /> },
  { path: '/zero-quota', element: <ZeroQuotaPage /> },
  { path: '/sub2api', element: <Sub2ApiPage /> },
  { path: '/settings', element: <SettingsPage /> },
  { path: '/providers', element: <ProvidersPage /> },
  { path: '/quota', element: <QuotaPage /> },
  { path: '/logs', element: <LogsPage /> },
  { path: '/about', element: <AboutPage /> },
  { path: '*', element: <Navigate to="/" replace /> },
];

export function MainRoutes({ location }: { location?: Location }) {
  return useRoutes(mainRoutes, location);
}
