import { useEffect, useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { Activity, BarChart3, Calculator, Clock, FolderOpen, Gauge, Layers3, Loader2, RefreshCw, Timer, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/shared/components/ui/card';
import { Button } from '@/shared/components/ui/button';
import { Badge } from '@/shared/components/ui/badge';
import { Progress } from '@/shared/components/ui/progress';
import { Input } from '@/shared/components/ui/input';
import { codexUsageApi } from '@/services/tauri/codexUsage.service';
import { authFilesApi } from '@/services/api/auth.service';
import type { AuthFile, AuthFilesResponse, CodexTokenEvent, CodexTokenUsageReport } from '@/types';

const ONE_HOUR_MS = 60 * 60 * 1000;
const THREE_HOURS_MS = 3 * 60 * 60 * 1000;
const DAY_MS = 24 * 60 * 60 * 1000;
const CODEX_ACCOUNT_BUDGET_USD = 4;
const AUTO_REFRESH_MS = 60 * 1000;
const BUDGET_MODEL_STORAGE_KEY = 'zerolimit.codexUsage.budgetModel.v1';
const TOKEN_BASELINE_STORAGE_KEY = 'zerolimit.codexUsage.tokenBaseline.v1';
const DISABLED_OVERRIDES_STORAGE_KEY = 'zerolimit.quota.disabledOverrides.v1';

type BudgetModelKey = 'gpt55' | 'sol' | 'terra' | 'luna';

const BUDGET_MODELS: Record<BudgetModelKey, {
  label: string;
  shortLabel: string;
  normalInputPerAccount: number;
  cachedInputPerAccount: number;
  outputPerAccount: number;
}> = {
  gpt55: {
    label: 'GPT-5.5',
    shortLabel: '5.5',
    normalInputPerAccount: 1_000_000,
    cachedInputPerAccount: 10_000_000,
    outputPerAccount: 166_700,
  },
  sol: {
    label: 'GPT-5.6 Sol',
    shortLabel: 'Sol',
    normalInputPerAccount: 1_000_000,
    cachedInputPerAccount: 10_000_000,
    outputPerAccount: 166_700,
  },
  terra: {
    label: 'GPT-5.6 Terra',
    shortLabel: 'Terra',
    normalInputPerAccount: 2_000_000,
    cachedInputPerAccount: 20_000_000,
    outputPerAccount: 333_300,
  },
  luna: {
    label: 'GPT-5.6 Luna',
    shortLabel: 'Luna',
    normalInputPerAccount: 5_000_000,
    cachedInputPerAccount: 50_000_000,
    outputPerAccount: 833_300,
  },
};

function parseTime(value?: string): number | null {
  if (!value) return null;
  const timestamp = Date.parse(value);
  return Number.isFinite(timestamp) ? timestamp : null;
}

function formatCompact(value?: number): string {
  if (!Number.isFinite(value)) return '-';
  return new Intl.NumberFormat('zh-CN', {
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(Math.round(Number(value)));
}

function formatPercent(value?: number | null): string {
  if (!Number.isFinite(value)) return '-';
  return `${Math.max(0, Math.min(100, Number(value))).toFixed(1)}%`;
}

function formatMoney(value?: number | null): string {
  if (!Number.isFinite(value)) return '-';
  return `$${Number(value).toFixed(Number(value) >= 10 ? 1 : 2)}`;
}

function formatAccountCount(value?: number | null): string {
  if (!Number.isFinite(value)) return '-';
  const number = Math.max(0, Number(value));
  if (number < 0.01) return '<0.01 \u4e2a';
  return `${number.toFixed(number >= 10 ? 1 : 2)} \u4e2a`;
}

function formatDateTime(value?: string | number | null): string {
  if (!value) return '-';
  const timestamp = typeof value === 'number' ? value : parseTime(value);
  if (!timestamp) return '-';
  return new Date(timestamp).toLocaleString('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).replace(/\//g, '-');
}

function formatDuration(hours?: number | null): string {
  if (!Number.isFinite(hours) || Number(hours) <= 0) return '-';
  if (Number(hours) < 1) return `${Math.max(1, Math.round(Number(hours) * 60))} 分钟`;
  if (Number(hours) < 24) return `${Number(hours).toFixed(Number(hours) >= 10 ? 0 : 1)} 小时`;
  return `${(Number(hours) / 24).toFixed(Number(hours) >= 240 ? 0 : 1)} 天`;
}

function getLatestBySession(events: CodexTokenEvent[]) {
  const map = new Map<string, CodexTokenEvent>();
  events.forEach((event) => {
    const key = event.sessionId || event.cwd || event.timestamp;
    const existing = map.get(key);
    if (!existing || (parseTime(event.timestamp) || 0) > (parseTime(existing.timestamp) || 0)) {
      map.set(key, event);
    }
  });
  return Array.from(map.values());
}

function getDelta(events: CodexTokenEvent[], sinceMs: number, now: number) {
  const scoped = events.filter((event) => {
    const timestamp = parseTime(event.timestamp);
    return timestamp !== null && timestamp >= now - sinceMs;
  });

  const sessionKeys = new Set(scoped.map(event => event.sessionId || event.cwd || event.timestamp));
  const input = scoped.reduce((sum, event) => sum + event.last.inputTokens, 0);
  const total = scoped.reduce((sum, event) => sum + event.last.totalTokens, 0);
  const output = scoped.reduce((sum, event) => sum + event.last.outputTokens, 0);
  const reasoning = scoped.reduce((sum, event) => sum + event.last.reasoningOutputTokens, 0);
  const cached = scoped.reduce((sum, event) => sum + event.last.cachedInputTokens, 0);
  const normalInput = Math.max(0, input - cached);

  return {
    events: scoped.length,
    sessions: sessionKeys.size,
    input,
    normalInput,
    total,
    output,
    reasoning,
    cached,
    perHour: total / (sinceMs / 3600000),
  };
}

function getTokenUsage(events: CodexTokenEvent[]) {
  const input = events.reduce((sum, event) => sum + event.last.inputTokens, 0);
  const output = events.reduce((sum, event) => sum + event.last.outputTokens, 0);
  const cached = events.reduce((sum, event) => sum + event.last.cachedInputTokens, 0);
  return {
    input,
    normalInput: Math.max(0, input - cached),
    cached,
    output,
    total: events.reduce((sum, event) => sum + event.last.totalTokens, 0),
  };
}

type TokenUsageLike = ReturnType<typeof getTokenUsage>;

function calculateSpendUsd(
  usage: Pick<TokenUsageLike, 'normalInput' | 'cached' | 'output'>,
  model: typeof BUDGET_MODELS[BudgetModelKey]
) {
  return (
    usage.normalInput / model.normalInputPerAccount +
    usage.cached / model.cachedInputPerAccount +
    usage.output / model.outputPerAccount
  ) * CODEX_ACCOUNT_BUDGET_USD;
}

function calculateEquivalentAccounts(
  usage: Pick<TokenUsageLike, 'normalInput' | 'cached' | 'output'>,
  model: typeof BUDGET_MODELS[BudgetModelKey]
) {
  return calculateSpendUsd(usage, model) / CODEX_ACCOUNT_BUDGET_USD;
}

function normalizeProjectKey(cwd?: string): string {
  if (!cwd) return 'unknown';
  return cwd.replace(/\\/g, '/').replace(/\/+$/, '').toLowerCase();
}

function getProjectUsage(events: CodexTokenEvent[], model: typeof BUDGET_MODELS[BudgetModelKey]) {
  const map = new Map<string, {
    key: string;
    name: string;
    cwd?: string;
    events: CodexTokenEvent[];
  }>();

  events.forEach((event) => {
    const key = normalizeProjectKey(event.cwd);
    const existing = map.get(key);
    if (existing) {
      existing.events.push(event);
      return;
    }

    map.set(key, {
      key,
      name: getProjectName(event.cwd),
      cwd: event.cwd,
      events: [event],
    });
  });

  return Array.from(map.values())
    .map((project) => {
      const usage = getTokenUsage(project.events);
      const spendUsd = calculateSpendUsd(usage, model);
      const equivalentAccounts = spendUsd / CODEX_ACCOUNT_BUDGET_USD;
      const lastUpdated = project.events
        .map(event => parseTime(event.timestamp) || 0)
        .reduce((latest, timestamp) => Math.max(latest, timestamp), 0);

      return {
        ...project,
        usage,
        spendUsd,
        equivalentAccounts,
        sessions: new Set(project.events.map(event => event.sessionId || event.cwd || event.timestamp)).size,
        lastUpdated,
      };
    })
    .sort((a, b) => b.usage.total - a.usage.total);
}

function getProjectName(cwd?: string): string {
  if (!cwd) return '未知项目';
  const normalized = cwd.replace(/\\/g, '/').replace(/\/+$/, '');
  return normalized.split('/').pop() || cwd;
}

function getHomeLabel(name?: string, index = 0): string {
  if (!name) return `Codex ${index + 1}`;
  if (name === '.codex') return 'Codex 主窗口';
  const match = name.match(/^\.codex-(\d+)$/);
  if (match) return `Codex 窗口 ${match[1]}`;
  return name;
}

function clampPercent(value?: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, Number(value)));
}

function loadDisabledOverrides(): Record<string, boolean> {
  try {
    const raw = window.localStorage.getItem(DISABLED_OVERRIDES_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    if (!parsed || typeof parsed !== 'object') return {};
    return Object.fromEntries(
      Object.entries(parsed).filter((entry): entry is [string, boolean] => typeof entry[1] === 'boolean')
    );
  } catch {
    return {};
  }
}

function getAuthFileKey(file: AuthFile, fallback = ''): string {
  return String(
    file.auth_index ||
    file.authIndex ||
    file.id ||
    file.filename ||
    file.name ||
    fallback
  );
}

function isAuthFileDisabled(file: AuthFile, disabledOverrides: Record<string, boolean>) {
  const key = getAuthFileKey(file, file.id || file.filename);
  if (typeof disabledOverrides[key] === 'boolean') return disabledOverrides[key];

  const value = file.disabled ?? file.is_disabled ?? file.isDisabled;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value === 1;
  if (typeof value === 'string') return ['true', '1', 'yes', 'on'].includes(value.trim().toLowerCase());
  return false;
}

function isCodexAuthFile(file: AuthFile) {
  const provider = String(file.provider || '').toLowerCase();
  const name = String(file.filename || file.name || file.id || '').toLowerCase();
  return provider.includes('codex') || name.startsWith('codex-') || name.includes('codex');
}

function extractAuthFiles(response: AuthFilesResponse): AuthFile[] {
  if (Array.isArray(response)) return response as AuthFile[];
  const files = response?.files ?? response?.items;
  return Array.isArray(files) ? files as AuthFile[] : [];
}

function countEnabledCodexAccounts(files: AuthFile[]) {
  const disabledOverrides = loadDisabledOverrides();
  return files.filter(file => isCodexAuthFile(file) && !isAuthFileDisabled(file, disabledOverrides)).length;
}

function getStoredBudgetModel(): BudgetModelKey {
  try {
    const value = window.localStorage.getItem(BUDGET_MODEL_STORAGE_KEY);
    return value === 'terra' || value === 'luna' || value === 'sol' || value === 'gpt55' ? value : 'gpt55';
  } catch {
    return 'gpt55';
  }
}

function getStoredTokenBaseline(): number | null {
  try {
    const value = Number(window.localStorage.getItem(TOKEN_BASELINE_STORAGE_KEY));
    return Number.isFinite(value) && value > 0 ? value : null;
  } catch {
    return null;
  }
}

export function CodexUsagePage() {
  const [report, setReport] = useState<CodexTokenUsageReport | null>(null);
  const [codexAccountCount, setCodexAccountCount] = useState(0);
  const [budgetModelKey, setBudgetModelKey] = useState<BudgetModelKey>(() => getStoredBudgetModel());
  const [tokenBaselineInput, setTokenBaselineInput] = useState(() => {
    const stored = getStoredTokenBaseline();
    return stored ? String(stored) : '';
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const budgetModel = BUDGET_MODELS[budgetModelKey];

  const updateBudgetModel = (value: BudgetModelKey) => {
    setBudgetModelKey(value);
    try {
      window.localStorage.setItem(BUDGET_MODEL_STORAGE_KEY, value);
    } catch {
      // Selection persistence is helpful but not required for the estimate.
    }
  };

  const updateTokenBaseline = (value: string) => {
    const sanitized = value.replace(/[^\d]/g, '');
    setTokenBaselineInput(sanitized);
    try {
      if (sanitized) {
        window.localStorage.setItem(TOKEN_BASELINE_STORAGE_KEY, sanitized);
      } else {
        window.localStorage.removeItem(TOKEN_BASELINE_STORAGE_KEY);
      }
    } catch {
      // Manual baseline is optional.
    }
  };

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [data, authResponse] = await Promise.all([
        codexUsageApi.getUsage(),
        authFilesApi.list(),
      ]);
      setReport(data);
      setCodexAccountCount(countEnabledCodexAccounts(extractAuthFiles(authResponse)));
    } catch (err) {
      setError((err as Error).message || '读取 Codex token 日志失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadData();
    const intervalId = window.setInterval(() => void loadData(), AUTO_REFRESH_MS);
    return () => window.clearInterval(intervalId);
  }, []);

  const stats = useMemo(() => {
    const events = report?.events ?? [];
    const latest = events.at(-1);
    const now = Date.now();
    const oneHour = getDelta(events, ONE_HOUR_MS, now);
    const threeHour = getDelta(events, THREE_HOURS_MS, now);
    const day = getDelta(events, DAY_MS, now);
    const totalUsage = getTokenUsage(events);
    const usedBudgetUsd = calculateSpendUsd(totalUsage, budgetModel);
    const usedEquivalentAccounts = calculateEquivalentAccounts(totalUsage, budgetModel);
    const observedTokensPerAccount = usedEquivalentAccounts > 0 ? totalUsage.total / usedEquivalentAccounts : null;
    const manualTokensPerAccount = Number(tokenBaselineInput);
    const tokenBaseline = Number.isFinite(manualTokensPerAccount) && manualTokensPerAccount > 0
      ? manualTokensPerAccount
      : observedTokensPerAccount;
    const oneHourSpendUsd = calculateSpendUsd(oneHour, budgetModel);
    const threeHourSpendUsd = calculateSpendUsd(threeHour, budgetModel);
    const daySpendUsd = calculateSpendUsd(day, budgetModel);
    const budgetUsd = codexAccountCount * CODEX_ACCOUNT_BUDGET_USD;
    const budgetUsedPercent = budgetUsd > 0 ? clampPercent(usedBudgetUsd / budgetUsd * 100) : null;
    const spendPerHour = oneHourSpendUsd > 0
      ? oneHourSpendUsd
      : threeHourSpendUsd > 0 ? threeHourSpendUsd / 3 : daySpendUsd > 0 ? daySpendUsd / 24 : 0;
    const hoursToBudgetEnd = budgetUsd > 0 && spendPerHour > 0
      ? Math.max(0, budgetUsd - usedBudgetUsd) / spendPerHour
      : null;
    const budgetProjectedAt = hoursToBudgetEnd ? now + hoursToBudgetEnd * 3600000 : null;
    const latestRate = [...events].reverse().find(event => Number.isFinite(event.rateLimit?.usedPercent))?.rateLimit;
    const rateEvents = events
      .filter(event => Number.isFinite(event.rateLimit?.usedPercent) && parseTime(event.timestamp))
      .map(event => ({ timestamp: parseTime(event.timestamp)!, used: Number(event.rateLimit?.usedPercent) }));
    const rateRecent = rateEvents.filter(event => event.timestamp >= now - ONE_HOUR_MS);
    const rateWindow = rateRecent.length >= 2 ? rateRecent : rateEvents.filter(event => event.timestamp >= now - DAY_MS);
    const firstRate = rateWindow.at(0);
    const lastRate = rateWindow.at(-1);
    const ratePerHour = firstRate && lastRate && lastRate.timestamp > firstRate.timestamp
      ? Math.max(0, (lastRate.used - firstRate.used) / ((lastRate.timestamp - firstRate.timestamp) / 3600000))
      : null;
    const usedPercent = Number.isFinite(latestRate?.usedPercent) ? clampPercent(latestRate?.usedPercent) : null;
    const hoursToLimit = usedPercent !== null && ratePerHour && ratePerHour > 0 ? (100 - usedPercent) / ratePerHour : null;
    const projectedAt = hoursToLimit ? now + hoursToLimit * 3600000 : null;
    const contextWindow = latest?.modelContextWindow || 0;
    const contextUsed = latest?.last.totalTokens || 0;
    const contextPercent = contextWindow > 0 ? clampPercent(contextUsed / contextWindow * 100) : 0;
    const weightedHourly = oneHour.perHour > 0
      ? oneHour.perHour
      : threeHour.perHour > 0 && day.perHour > 0 ? threeHour.perHour * 0.7 + day.perHour * 0.3 : threeHour.perHour || day.perHour;

    const projects = getLatestBySession(events)
      .sort((a, b) => (parseTime(b.timestamp) || 0) - (parseTime(a.timestamp) || 0))
      .slice(0, 8);
    const projectTotals = getProjectUsage(events, budgetModel).slice(0, 20);
    const homeStats = (report?.codexHomes ?? []).map((home, index) => {
      const homeEvents = events.filter(event => event.codexHome === home.path || event.codexHomeName === home.name);
      const homeThreeHour = getDelta(homeEvents, THREE_HOURS_MS, now);
      const homeDay = getDelta(homeEvents, DAY_MS, now);
      const homeRate = [...homeEvents].reverse().find(event => Number.isFinite(event.rateLimit?.usedPercent))?.rateLimit;
      const homeSpendUsd = calculateSpendUsd(homeThreeHour, budgetModel);

      return {
        home,
        label: getHomeLabel(home.name, index),
        threeHour: homeThreeHour,
        day: homeDay,
        threeHourSpendUsd: homeSpendUsd,
        usedPercent: Number.isFinite(homeRate?.usedPercent) ? clampPercent(homeRate?.usedPercent) : null,
      };
    });

    return {
      latest,
      oneHour,
      threeHour,
      day,
      totalUsage,
      budgetUsd,
      usedBudgetUsd,
      usedEquivalentAccounts,
      observedTokensPerAccount,
      tokenBaseline,
      oneHourSpendUsd,
      threeHourSpendUsd,
      budgetUsedPercent,
      hoursToBudgetEnd,
      budgetProjectedAt,
      spendPerHour,
      latestRate,
      usedPercent,
      ratePerHour,
      hoursToLimit,
      projectedAt,
      contextWindow,
      contextUsed,
      contextPercent,
      weightedHourly,
      projects,
      projectTotals,
      homeStats,
    };
  }, [budgetModel, codexAccountCount, report, tokenBaselineInput]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6"
    >
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Token 消耗</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            读取本机 Codex 日志，统计上下文窗口、近 3 小时消耗和限额趋势。
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-md border p-1">
            {(Object.entries(BUDGET_MODELS) as Array<[BudgetModelKey, typeof budgetModel]>).map(([key, model]) => (
              <Button
                key={key}
                type="button"
                size="sm"
                variant={budgetModelKey === key ? 'secondary' : 'ghost'}
                className="h-8 px-2"
                onClick={() => updateBudgetModel(key)}
              >
                {model.shortLabel}
              </Button>
            ))}
          </div>
          <Button variant="outline" onClick={loadData} disabled={loading} className="gap-2">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            刷新
          </Button>
        </div>
      </div>

      {error && (
        <div className="rounded-md border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-600 dark:text-red-300">
          {error}
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
        <Card className="border-border/50 py-2">
          <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">近 3 小时</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent className="px-4 pb-4 pt-0">
            <div className="text-3xl font-bold">{formatCompact(stats.threeHour.total)}</div>
            <p className="mt-1 text-xs text-muted-foreground">
              约 {formatCompact(stats.threeHour.perHour)} token/小时
            </p>
          </CardContent>
        </Card>

                <Card className="border-border/50 py-2">
          <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">{'\u5df2\u6d88\u8017\u5200\u6570'}</CardTitle>
            <Gauge className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent className="px-4 pb-4 pt-0">
            <div className="text-3xl font-bold">{formatMoney(stats.usedBudgetUsd)}</div>
            <p className="mt-1 text-xs text-muted-foreground">
              {`${codexAccountCount} \u4e2a\u8d26\u53f7 · ${budgetModel.label} · $4/\u53f7 · \u4e0a\u9650 ${formatMoney(stats.budgetUsd)}`}
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/50 py-2">
          <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">每账号约 token</CardTitle>
            <Calculator className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent className="px-4 pb-4 pt-0">
            <div className="text-3xl font-bold">{formatCompact(stats.tokenBaseline ?? undefined)}</div>
            <p className="mt-1 text-xs text-muted-foreground">
              已折算 {formatAccountCount(stats.usedEquivalentAccounts)}，可手动覆盖基准
            </p>
          </CardContent>
        </Card>
<Card className="border-border/50 py-2">
          <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">预算用完预计</CardTitle>
            <Timer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent className="px-4 pb-4 pt-0">
            <div className="text-3xl font-bold">{formatDuration(stats.hoursToBudgetEnd)}</div>
            <p className="mt-1 text-xs text-muted-foreground">
              {stats.budgetProjectedAt
                ? `${formatDateTime(stats.budgetProjectedAt)} 左右`
                : codexAccountCount === 0 ? '未找到启用的 Codex 账号' : '近 1 小时消耗不足'}
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/50 py-2">
          <CardHeader className="flex flex-row items-center justify-between p-4 pb-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">最近一轮 / 窗口</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent className="px-4 pb-4 pt-0">
            <div className="text-3xl font-bold">{formatPercent(stats.contextPercent)}</div>
            <p className="mt-1 text-xs text-muted-foreground">
              {formatCompact(stats.contextUsed)} / {formatCompact(stats.contextWindow)}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Activity className="h-4 w-4" />
            消耗趋势
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            预计值主看近 3 小时；近 24 小时只用于平滑判断，避免短时间波动太大。
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-4">
            <div className="rounded-md border p-3">
              <div className="text-sm text-muted-foreground">近 3 小时事件</div>
              <div className="mt-1 text-2xl font-semibold">{stats.threeHour.events}</div>
              <p className="mt-1 text-xs text-muted-foreground">涉及 {stats.threeHour.sessions} 个任务</p>
            </div>
            <div className="rounded-md border p-3">
              <div className="text-sm text-muted-foreground">近 24 小时</div>
              <div className="mt-1 text-2xl font-semibold">{formatCompact(stats.day.total)}</div>
              <p className="mt-1 text-xs text-muted-foreground">约 {formatCompact(stats.day.perHour)} token/小时</p>
            </div>
            <div className="rounded-md border p-3">
              <div className="text-sm text-muted-foreground">加权速度</div>
              <div className="mt-1 text-2xl font-semibold">{formatCompact(stats.weightedHourly)}</div>
              <p className="mt-1 text-xs text-muted-foreground">近 1 小时约 {formatMoney(stats.oneHourSpendUsd)}</p>
            </div>
            <div className="rounded-md border p-3">
              <div className="text-sm text-muted-foreground">每账号 token 基准</div>
              <Input
                inputMode="numeric"
                value={tokenBaselineInput}
                onChange={(event) => updateTokenBaseline(event.target.value)}
                placeholder={stats.observedTokensPerAccount ? String(Math.round(stats.observedTokensPerAccount)) : '自动估算' }
                className="mt-2 h-9"
              />
              <p className="mt-1 text-xs text-muted-foreground">留空按当前 token 结构自动估算</p>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">{'\u5f53\u524d\u5df2\u6d88\u8017 / \u603b\u4e0a\u9650'}</span>
              <span className="font-medium">{formatMoney(stats.usedBudgetUsd)} / {formatMoney(stats.budgetUsd)}</span>
            </div>
            <Progress value={stats.budgetUsedPercent ?? 0} />
            <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
              <Badge variant="secondary" className="rounded-md">日志 {report?.tokenEvents ?? 0} 条</Badge>
              <Badge variant="secondary" className="rounded-md">会话 {report?.sessionsScanned ?? 0} 个</Badge>
              <Badge variant="secondary" className="rounded-md">账号 {codexAccountCount} 个</Badge>
              <Badge variant="secondary" className="rounded-md">更新 {formatDateTime(report?.lastUpdated)}</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Layers3 className="h-4 w-4" />
            Codex 窗口
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            上面的总计已经合并所有窗口；这里单独列出每个 Codex 数据目录。
          </p>
        </CardHeader>
        <CardContent>
          {stats.homeStats.length > 0 ? (
            <div className="grid gap-3 md:grid-cols-2">
              {stats.homeStats.map((item) => (
                <div key={item.home.path} className="space-y-3 rounded-md border p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="truncate font-medium">{item.label}</div>
                      <div className="truncate text-xs text-muted-foreground" title={item.home.path}>
                        {item.home.path}
                      </div>
                    </div>
                    <Badge variant="secondary" className="shrink-0 rounded-md">
                      {item.home.sessionsScanned} 会话
                    </Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-sm">
                    <div>
                      <div className="text-xs text-muted-foreground">近 3 小时</div>
                      <div className="font-semibold">{formatCompact(item.threeHour.total)}</div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">近 24 小时</div>
                      <div className="font-semibold">{formatCompact(item.day.total)}</div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">近 3 小时花费</div>
                      <div className="font-semibold">{formatMoney(item.threeHourSpendUsd)}</div>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                    <Badge variant="outline" className="rounded-md">日志 {item.home.tokenEvents} 条</Badge>
                    <Badge variant="outline" className="rounded-md">更新 {formatDateTime(item.home.lastUpdated)}</Badge>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center justify-center rounded-md border py-10 text-sm text-muted-foreground">
              暂未发现 Codex 数据目录
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Calculator className="h-4 w-4" />
            项目总消耗
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            按项目路径汇总全部已扫描 token 日志，并按当前模型档位折算刀数和账号数。
          </p>
        </CardHeader>
        <CardContent>
          {stats.projectTotals.length > 0 ? (
            <div className="space-y-2">
              {stats.projectTotals.map((project) => {
                const baselineAccounts = stats.tokenBaseline && stats.tokenBaseline > 0
                  ? project.usage.total / stats.tokenBaseline
                  : null;

                return (
                  <div key={project.key} className="rounded-md border p-3">
                    <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                      <div className="min-w-0">
                        <div className="truncate font-medium">{project.name}</div>
                        <div className="truncate text-xs text-muted-foreground" title={project.cwd || project.key}>
                          {project.cwd || '未知路径'}
                        </div>
                      </div>
                      <div className="grid shrink-0 grid-cols-2 gap-x-6 gap-y-2 text-sm sm:grid-cols-5">
                        <div>
                          <div className="text-xs text-muted-foreground">总 token</div>
                          <div className="font-semibold">{formatCompact(project.usage.total)}</div>
                        </div>
                        <div>
                          <div className="text-xs text-muted-foreground">花费</div>
                          <div className="font-semibold">{formatMoney(project.spendUsd)}</div>
                        </div>
                        <div>
                          <div className="text-xs text-muted-foreground">折算账号</div>
                          <div className="font-semibold">{formatAccountCount(project.equivalentAccounts)}</div>
                        </div>
                        <div>
                          <div className="text-xs text-muted-foreground">按基准</div>
                          <div className="font-semibold">{formatAccountCount(baselineAccounts)}</div>
                        </div>
                        <div>
                          <div className="text-xs text-muted-foreground">任务</div>
                          <div className="font-semibold">{project.sessions}</div>
                        </div>
                      </div>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-2 text-xs text-muted-foreground">
                      <Badge variant="outline" className="rounded-md">普通输入 {formatCompact(project.usage.normalInput)}</Badge>
                      <Badge variant="outline" className="rounded-md">缓存 {formatCompact(project.usage.cached)}</Badge>
                      <Badge variant="outline" className="rounded-md">输出 {formatCompact(project.usage.output)}</Badge>
                      <Badge variant="outline" className="rounded-md">更新 {formatDateTime(project.lastUpdated)}</Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="flex items-center justify-center rounded-md border py-10 text-sm text-muted-foreground">
              暂未发现可汇总的项目 token 日志
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <FolderOpen className="h-4 w-4" />
            最近 Codex 项目
          </CardTitle>
        </CardHeader>
        <CardContent>
          {stats.projects.length > 0 ? (
            <div className="space-y-2">
              {stats.projects.map((event) => (
                <div key={`${event.sessionId}-${event.timestamp}`} className="flex flex-col gap-2 rounded-md border p-3 md:flex-row md:items-center md:justify-between">
                  <div className="min-w-0">
                    <div className="flex min-w-0 items-center gap-2">
                      <div className="truncate font-medium">{getProjectName(event.cwd)}</div>
                      <Badge variant="outline" className="shrink-0 rounded-md">
                        {getHomeLabel(event.codexHomeName)}
                      </Badge>
                    </div>
                    <div className="truncate text-xs text-muted-foreground">{event.cwd || event.sessionId || '未知路径'}</div>
                  </div>
                  <div className="flex shrink-0 items-center gap-3 text-sm">
                    <span>{formatCompact(event.last.totalTokens)} token</span>
                    <span className="text-muted-foreground">{formatDateTime(event.timestamp)}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center justify-center rounded-md border py-10 text-sm text-muted-foreground">
              暂未发现 Codex token_count 日志
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex items-start gap-2 rounded-md border bg-muted/30 p-3 text-sm text-muted-foreground">
        <Clock className="mt-0.5 h-4 w-4 shrink-0" />
        <span>
          Token 消耗来自 Codex 本地日志；预算按每个启用 Codex 账号 $4，并按所选模型档位折算。
        </span>
      </div>
    </motion.div>
  );
}
