export const ALL_CPA_NODES_ID = '__all_cpa_nodes__';

export interface CpaNodeConnectionConfig {
  apiBase: string;
  managementKey: string;
}

export interface CpaNode extends CpaNodeConnectionConfig {
  id: string;
  name: string;
  enabled: boolean;
  tags?: string;
  createdAt: string;
  lastConnectedAt?: string;
}

export interface CpaNodeInput extends CpaNodeConnectionConfig {
  name: string;
  enabled?: boolean;
  tags?: string;
}