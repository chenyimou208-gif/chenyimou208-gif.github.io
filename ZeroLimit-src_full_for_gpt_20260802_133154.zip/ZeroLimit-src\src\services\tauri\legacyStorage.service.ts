﻿import { invoke } from '@tauri-apps/api/core';

const LEGACY_STORAGE_KEYS = [
  'zerolimit-integrations',
  'zerolimit.quota.disabledOverrides.v1',
  'zerolimit.quota.zeroQuotaDisabled.v1',
  'zerolimit.quota.weeklyQuotaDisabled.v1',
  'zerolimit.quota.importTimes.v1',
  'zerolimit.quota.zeroQuotaZeroedAt.v1',
  'zerolimit.quota.weeklyQuotaZeroedAt.v1',
  'zerolimit.quota.weeklyQuotaResetAt.v1',
] as const;

const LEGACY_MIGRATION_MARKER_KEY = 'zerolimit.legacyQuotaStorageMigration.v1';

type LegacyStorage = Partial<Record<(typeof LEGACY_STORAGE_KEYS)[number], string>>;

type JsonRecord = Record<string, unknown>;

function isTauriRuntime(): boolean {
  return typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;
}

function isPlainRecord(value: unknown): value is JsonRecord {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}

function parseRecord(raw: string | null | undefined): JsonRecord {
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    return isPlainRecord(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function isEmptyCurrentValue(value: unknown): boolean {
  return value === undefined || value === null || value === '';
}

function mergeValue(legacyValue: unknown, currentValue: unknown): unknown {
  if (isPlainRecord(legacyValue) && isPlainRecord(currentValue)) {
    const keys = new Set([...Object.keys(legacyValue), ...Object.keys(currentValue)]);
    const merged: JsonRecord = {};
    keys.forEach(key => {
      merged[key] = mergeValue(legacyValue[key], currentValue[key]);
    });
    return merged;
  }

  return isEmptyCurrentValue(currentValue) ? legacyValue : currentValue;
}

function mergeLegacyRecord(key: string, legacyRaw: string | undefined): boolean {
  if (!legacyRaw) return false;

  const legacyRecord = parseRecord(legacyRaw);
  const currentRecord = parseRecord(window.localStorage.getItem(key));
  if (Object.keys(legacyRecord).length === 0) return false;

  const merged = mergeValue(legacyRecord, currentRecord) as JsonRecord;
  const changed = JSON.stringify(merged) !== JSON.stringify(currentRecord);
  if (changed) {
    window.localStorage.setItem(key, JSON.stringify(merged));
  }
  return changed;
}

export async function migrateLegacyQuotaStorage(): Promise<{ changed: boolean; migratedKeys: number }> {
  if (!isTauriRuntime()) return { changed: false, migratedKeys: 0 };

  try {
    const legacy = await invoke<LegacyStorage>('read_legacy_quota_storage');
    let changed = false;
    let migratedKeys = 0;

    for (const key of LEGACY_STORAGE_KEYS) {
      if (mergeLegacyRecord(key, legacy[key])) {
        changed = true;
        migratedKeys += 1;
      }
    }

    if (changed) {
      window.localStorage.setItem(LEGACY_MIGRATION_MARKER_KEY, JSON.stringify({
        migratedAt: new Date().toISOString(),
        migratedKeys,
      }));
    }

    return { changed, migratedKeys };
  } catch (error) {
    console.warn('Failed to migrate legacy storage:', error);
    return { changed: false, migratedKeys: 0 };
  }
}
