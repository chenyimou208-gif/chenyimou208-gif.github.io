import { useState } from 'react';
import { toast } from 'sonner';
import { CheckCircle2, Edit3, Loader2, Network, Plus, Save, Star, Tags, Trash2 } from 'lucide-react';
import { Button } from '@/shared/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/shared/components/ui/card';
import { Input } from '@/shared/components/ui/input';
import { Label } from '@/shared/components/ui/label';
import { configApi } from '@/services/api/config.service';
import { useAuthStore } from '@/features/auth/auth.store';
import { useCpaNodesStore } from '@/features/nodes/nodes.store';
import type { CpaNode, CpaNodeInput } from '@/types';

const EMPTY_FORM: CpaNodeInput = {
  name: '',
  apiBase: '',
  managementKey: '',
  enabled: true,
  tags: '',
};

function toForm(node: CpaNode): CpaNodeInput {
  return {
    name: node.name,
    apiBase: node.apiBase,
    managementKey: node.managementKey,
    enabled: node.enabled,
    tags: node.tags || '',
  };
}

function maskKey(value: string): string {
  if (!value) return '未填写';
  const suffix = value.length > 4 ? value.slice(-4) : '';
  return `${'•'.repeat(8)}${suffix}`;
}

function formatDateTime(value?: string): string {
  if (!value) return '未测试';
  const timestamp = Date.parse(value);
  if (!Number.isFinite(timestamp)) return value;
  return new Date(timestamp).toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).replace(/\//g, '-');
}

export function CpaNodesSettings() {
  const {
    nodes,
    defaultNodeId,
    addNode,
    updateNode,
    removeNode,
    setDefaultNode,
    toggleNode,
    markNodeConnected,
  } = useCpaNodesStore();
  const { checkAuth } = useAuthStore();
  const [form, setForm] = useState<CpaNodeInput>(EMPTY_FORM);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [testingNodeId, setTestingNodeId] = useState<string | null>(null);

  const isEditing = Boolean(editingId);

  const updateForm = (patch: Partial<CpaNodeInput>) => {
    setForm(current => ({ ...current, ...patch }));
  };

  const resetForm = () => {
    setForm(EMPTY_FORM);
    setEditingId(null);
  };

  const handleSave = () => {
    const saved = editingId ? updateNode(editingId, form) : addNode(form);
    if (!saved) {
      toast.error('请填写节点名称、API 地址和管理密钥');
      return;
    }
    toast.success(editingId ? '节点已更新' : '节点已添加');
    resetForm();
  };

  const handleEdit = (node: CpaNode) => {
    setEditingId(node.id);
    setForm(toForm(node));
  };

  const handleDelete = (node: CpaNode) => {
    if (nodes.length <= 1) {
      toast.error('至少保留一个 CPA 节点');
      return;
    }
    if (!window.confirm(`删除节点“${node.name}”？不会删除服务器账号，但会从 ZeroLimit 移除这个连接。`)) return;
    removeNode(node.id);
    toast.success('节点已删除');
  };

  const handleSetDefault = async (node: CpaNode) => {
    setDefaultNode(node.id);
    toast.success('默认节点已切换');
    await checkAuth().catch(() => undefined);
  };

  const handleTest = async (node: CpaNode) => {
    setTestingNodeId(node.id);
    try {
      await configApi.getConfig({ apiBase: node.apiBase, managementKey: node.managementKey });
      markNodeConnected(node.id);
      toast.success(`节点“${node.name}”连接正常`);
    } catch (error) {
      toast.error(`节点“${node.name}”连接失败：${(error as Error).message}`);
    } finally {
      setTestingNodeId(null);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Network className="h-5 w-5" />
          CPA 节点管理
        </CardTitle>
        <CardDescription>管理多个 CPA 后台连接；旧单节点配置会自动迁移为默认节点。</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3 xl:grid-cols-[1fr_1.5fr_1.5fr_1fr_auto] xl:items-end">
          <div className="space-y-2">
            <Label htmlFor="nodeName">节点名称</Label>
            <Input id="nodeName" value={form.name} onChange={(event) => updateForm({ name: event.target.value })} placeholder="主 CPA / 备用 CPA" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="nodeApiBase">API 地址</Label>
            <Input id="nodeApiBase" value={form.apiBase} onChange={(event) => updateForm({ apiBase: event.target.value })} placeholder="http://localhost:8317" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="nodeManagementKey">管理密钥</Label>
            <Input id="nodeManagementKey" type="password" value={form.managementKey} onChange={(event) => updateForm({ managementKey: event.target.value })} placeholder="Management Key" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="nodeTags">备注/标签</Label>
            <div className="relative">
              <Tags className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input id="nodeTags" value={form.tags || ''} onChange={(event) => updateForm({ tags: event.target.value })} placeholder="账号池A" className="pl-9" />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <label className="flex h-10 items-center gap-2 rounded-md border px-3 text-sm">
              <input type="checkbox" checked={form.enabled ?? true} onChange={(event) => updateForm({ enabled: event.target.checked })} />
              启用
            </label>
            <Button type="button" onClick={handleSave} className="min-w-[96px]">
              {isEditing ? <Save className="mr-2 h-4 w-4" /> : <Plus className="mr-2 h-4 w-4" />}
              {isEditing ? '保存' : '添加'}
            </Button>
            {isEditing && <Button type="button" variant="outline" onClick={resetForm}>取消</Button>}
          </div>
        </div>

        <div className="space-y-2">
          {nodes.map(node => (
            <div key={node.id} className="flex flex-col gap-3 rounded-md border p-3 xl:flex-row xl:items-center xl:justify-between">
              <div className="min-w-0 space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-medium">{node.name}</span>
                  {node.id === defaultNodeId && <span className="rounded-md bg-primary px-2 py-0.5 text-xs text-primary-foreground">默认</span>}
                  <span className={`rounded-md px-2 py-0.5 text-xs ${node.enabled ? 'bg-emerald-500/10 text-emerald-700' : 'bg-muted text-muted-foreground'}`}>
                    {node.enabled ? '启用中' : '已停用'}
                  </span>
                  {node.tags && <span className="rounded-md bg-muted px-2 py-0.5 text-xs text-muted-foreground">{node.tags}</span>}
                </div>
                <div className="truncate text-sm text-muted-foreground">{node.apiBase}</div>
                <div className="text-xs text-muted-foreground">密钥：{maskKey(node.managementKey)} · 最近连接：{formatDateTime(node.lastConnectedAt)}</div>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Button type="button" size="sm" variant="outline" onClick={() => handleTest(node)} disabled={testingNodeId === node.id}>
                  {testingNodeId === node.id ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle2 className="mr-2 h-4 w-4" />}
                  测试
                </Button>
                <Button type="button" size="sm" variant="outline" onClick={() => toggleNode(node.id, !node.enabled)}>{node.enabled ? '停用' : '启用'}</Button>
                <Button type="button" size="sm" variant="outline" onClick={() => handleSetDefault(node)} disabled={node.id === defaultNodeId}>
                  <Star className="mr-2 h-4 w-4" />
                  设默认
                </Button>
                <Button type="button" size="sm" variant="outline" onClick={() => handleEdit(node)}>
                  <Edit3 className="mr-2 h-4 w-4" />
                  编辑
                </Button>
                <Button type="button" size="sm" variant="outline" className="text-destructive hover:bg-destructive/10 hover:text-destructive" onClick={() => handleDelete(node)}>
                  <Trash2 className="mr-2 h-4 w-4" />
                  删除
                </Button>
              </div>
            </div>
          ))}
          {nodes.length === 0 && (
            <div className="rounded-md border border-dashed p-4 text-sm text-muted-foreground">暂无 CPA 节点。保存一个节点后，CPA 面板会按该节点读取账号池。</div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}