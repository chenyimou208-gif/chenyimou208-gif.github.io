﻿import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { Card, CardContent } from '@/shared/components/ui/card';
import { Button } from '@/shared/components/ui/button';
import { RefreshCw, AlertCircle, Loader2, LayoutGrid, List, Eye, EyeOff, Upload, Trash2, Power, PowerOff, ShieldAlert, Network, SlidersHorizontal } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/shared/components/ui/select';
import { ProviderFilter } from '@/features/quota/components/ProviderFilter';
import { ProviderQuotaCard } from '@/features/quota/components/ProviderQuotaCard';
import { CompactQuotaCard } from '@/features/quota/components/CompactQuotaCard';
import { QuotaSummaryCard } from '@/features/quota/components/QuotaSummaryCard';
import { useQuotaPresenter } from '@/features/quota/useQuotaPresenter';
import type { FileQuota, ProviderSection, QuotaModel } from '@/types';

function normalizeTimestamp(value: unknown): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value < 10000000000 ? value * 1000 : value;
  }

  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return null;

    const numeric = Number(trimmed);
    if (Number.isFinite(numeric)) {
      return numeric < 10000000000 ? numeric * 1000 : numeric;
    }

    const parsed = Date.parse(trimmed);
    return Number.isFinite(parsed) ? parsed : null;
  }

  return null;
}

function formatImportTime(file: FileQuota): string | undefined {
  const original = file.originalFile;
  const candidates = [
    file.importedAt,
    original?.createdAt,
    original?.created_at,
    original?.uploadedAt,
    original?.uploaded_at,
    original?.created,
    original?.ctime,
    original?.mtime,
    original?.modifiedAt,
    original?.modified_at,
  ];

  for (const candidate of candidates) {
    const timestamp = normalizeTimestamp(candidate);
    if (timestamp !== null) {
      return new Date(timestamp)
        .toLocaleString('zh-CN', {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false,
        })
        .replace(/\//g, '-');
    }
  }

  return undefined;
}

function getNestedString(record: unknown, key: string): string | undefined {
  if (!record || typeof record !== 'object') return undefined;
  const value = (record as Record<string, unknown>)[key];
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}

function getImportSource(file: FileQuota): string {
  const original = file.originalFile;
  const source =
    getNestedString(original, 'source') ||
    getNestedString(original, 'import_source') ||
    getNestedString(original, 'importSource') ||
    getNestedString(original?.metadata, 'source') ||
    getNestedString(original?.attributes, 'source');

  if (source) return source;
  if ((original?.filename || original?.name || '').toLowerCase().includes('import')) return 'JSON \u5bfc\u5165';
  return file.provider;
}

type QuotaWindowFilter = 'all' | 'hour' | 'week' | 'month';
type QuotaWindowKind = Exclude<QuotaWindowFilter, 'all'> | 'other';

const QUOTA_WINDOW_OPTIONS: Array<{ id: QuotaWindowFilter; label: string }> = [
  { id: 'all', label: '\u5168\u90e8' },
  { id: 'hour', label: '5\u5c0f\u65f6' },
  { id: 'week', label: '\u5468\u989d\u5ea6' },
  { id: 'month', label: '\u6708\u989d\u5ea6' },
];

const VISIBLE_BATCH_SIZE = 80;

function getQuotaItems(file: FileQuota): QuotaModel[] {
  return file.models || file.limits || [];
}

function getQuotaWindowKind(item: QuotaModel): QuotaWindowKind {
  const name = item.name.toLowerCase();
  if (name.includes('monthly') || name.includes('month') || name.includes('\u6708')) return 'month';
  if (name.includes('weekly') || name.includes('week') || name.includes('\u5468')) return 'week';
  if (name.includes('hour') || name.includes('5h') || name.includes('5\u5c0f\u65f6') || name.includes('\u5c0f\u65f6')) return 'hour';
  return 'other';
}

function filterQuotaItems(items: QuotaModel[], filter: QuotaWindowFilter): QuotaModel[] {
  if (filter === 'all') return items;
  return items.filter(item => getQuotaWindowKind(item) === filter);
}

function filterFileQuotaByWindow(file: FileQuota, filter: QuotaWindowFilter): FileQuota {
  if (filter === 'all') return file;
  return {
    ...file,
    models: file.models ? filterQuotaItems(file.models, filter) : file.models,
    limits: file.limits ? filterQuotaItems(file.limits, filter) : file.limits,
  };
}

function shouldKeepFilteredFile(file: FileQuota, filter: QuotaWindowFilter): boolean {
  if (filter === 'all') return true;
  return file.loading || Boolean(file.error) || getQuotaItems(file).length > 0;
}

function filterSectionsByWindow(sections: ProviderSection[], filter: QuotaWindowFilter): ProviderSection[] {
  if (filter === 'all') return sections;
  return sections.map(section => ({
    ...section,
    files: section.files
      .map(file => filterFileQuotaByWindow(file, filter))
      .filter(file => shouldKeepFilteredFile(file, filter)),
  }));
}
function getFileQuotaAverage(file: FileQuota): number | null {
  const items = getQuotaItems(file).filter(item => Number.isFinite(item.percentage));
  if (items.length === 0) return null;
  return items.reduce((sum, item) => sum + item.percentage, 0) / items.length;
}

function sortFilteredQuotaFiles(files: FileQuota[], mode: string): FileQuota[] {
  if (mode === 'newest') return files;

  return [...files].sort((a, b) => {
    const aAverage = getFileQuotaAverage(a);
    const bAverage = getFileQuotaAverage(b);

    if (aAverage === null && bAverage === null) {
      return (b.importOrder ?? 0) - (a.importOrder ?? 0);
    }
    if (aAverage === null) return 1;
    if (bAverage === null) return -1;

    return mode === 'quota-desc' ? bAverage - aAverage : aAverage - bAverage;
  });
}

export function QuotaPage() {
  const { t } = useTranslation();
  const [quotaWindowFilter, setQuotaWindowFilter] = useState<QuotaWindowFilter>('all');
  const [visibleCount, setVisibleCount] = useState(VISIBLE_BATCH_SIZE);
  const [now, setNow] = useState(() => Date.now());
  const {
    isAuthenticated,
    sections,
    loading,
    error,
    activeTab,
    setActiveTab,
    viewMode,
    setViewMode,
    sortMode,
    setSortMode,
    isPrivacyMode,
    togglePrivacyMode,
    uploadingAuthFiles,
    uploadAuthFiles,
    filterItems,
    displayedFiles,
    refreshDisplayed,
    fetchQuotaForFile,
    deleteAuthFile,
    deletingUnavailableFiles,
    deleteUnavailableAuthFiles,
    unavailableFileCount,
    deletingInvalidTokenFiles,
    deleteInvalidTokenAuthFiles,
    invalidTokenFileCount,
    disableZeroQuotaAuthFiles,
    zeroQuotaFileCount,
    preferLowQuotaAuthFiles,
    preferWatchQuotaAuthFiles,
    lowQuotaFileCount,
    watchQuotaFileCount,
    updatingDisabledFileIds,
    bulkUpdatingDisabledFiles,
    toggleAuthFileDisabled,
    enableAllAuthFiles,
    disableAllButBestAuthFile,
    isAuthFileDisabled,
    nodeOptions,
    activeNodeId,
    activeNodeName,
    setActiveNodeId,
    canWriteSelectedNode,
  } = useQuotaPresenter();

  useEffect(() => {
    const intervalId = window.setInterval(() => setNow(Date.now()), 30000);
    return () => window.clearInterval(intervalId);
  }, []);

  const filteredSections = useMemo(() => filterSectionsByWindow(sections, quotaWindowFilter), [sections, quotaWindowFilter]);
  const filteredDisplayedFiles = useMemo(() => {
    const filtered = displayedFiles
      .map(file => filterFileQuotaByWindow(file, quotaWindowFilter))
      .filter(file => shouldKeepFilteredFile(file, quotaWindowFilter));
    return sortFilteredQuotaFiles(filtered, sortMode);
  }, [displayedFiles, quotaWindowFilter, sortMode]);

  useEffect(() => {
    setVisibleCount(VISIBLE_BATCH_SIZE);
  }, [activeNodeId, activeTab, quotaWindowFilter, sortMode, viewMode]);

  const visibleDisplayedFiles = useMemo(() => {
    return filteredDisplayedFiles.slice(0, visibleCount);
  }, [filteredDisplayedFiles, visibleCount]);
  const hasMoreDisplayedFiles = visibleCount < filteredDisplayedFiles.length;



  if (!isAuthenticated) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="space-y-6"
      >
        <div>
          <h1 className="text-3xl font-bold">{t('quota.title')}</h1>
        </div>
        <Card className="border">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <AlertCircle className="mb-4 h-12 w-12 text-muted-foreground" />
            <p className="text-muted-foreground">{t('quota.connectPrompt')}</p>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="space-y-6"
      >
      {/* Header & Controls */}
      <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
        <div className="min-w-0">
          <h1 className="whitespace-nowrap text-3xl font-bold text-foreground">{t('quota.title')}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{t('quota.compactHint', '\u6309\u7a97\u53e3\u5207\u6362\u989d\u5ea6\uff0c\u6279\u91cf\u542f\u505c\u8d26\u53f7\u3002')}</p>
        </div>
        <div className="flex flex-wrap items-center justify-end gap-2">
          <Button
            variant="outline"
            onClick={togglePrivacyMode}
            title={isPrivacyMode ? "Show private info" : "Hide private info"}
          >
            {isPrivacyMode ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </Button>

          <div className="flex items-center rounded-md border p-1">
            <Button
              variant={viewMode === 'list' ? 'secondary' : 'ghost'}
              size="sm"
              className="h-8 px-2"
              onClick={() => setViewMode('list')}
            >
              <List className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === 'card' ? 'secondary' : 'ghost'}
              size="sm"
              className="h-8 px-2"
              onClick={() => setViewMode('card')}
            >
              <LayoutGrid className="h-4 w-4" />
            </Button>
          </div>

          <Select value={sortMode} onValueChange={(value) => setSortMode(value as typeof sortMode)}>
            <SelectTrigger className="h-10 w-[170px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">{t('quota.sortNewest')}</SelectItem>
              <SelectItem value="quota-desc">{t('quota.sortHighToLow')}</SelectItem>
              <SelectItem value="quota-asc">{t('quota.sortLowToHigh')}</SelectItem>
            </SelectContent>
          </Select>

          <Button
            variant="outline"
            onClick={refreshDisplayed}
            disabled={!canWriteSelectedNode || loading || uploadingAuthFiles || bulkUpdatingDisabledFiles}
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            {t('quota.refreshAll')}
          </Button>
        </div>
      </div>

      <div className="space-y-3 rounded-lg border bg-card/80 p-3 shadow-sm">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex min-w-[260px] items-center gap-2 rounded-md border bg-background px-2 py-1.5">
            <Network className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">CPA节点</span>
            <Select value={activeNodeId || ''} onValueChange={setActiveNodeId} disabled={nodeOptions.length === 0}>
              <SelectTrigger className="h-8 min-w-[170px] border-0 px-2 shadow-none focus:ring-0">
                <SelectValue placeholder="选择节点" />
              </SelectTrigger>
              <SelectContent>
                {nodeOptions.map(node => (
                  <SelectItem key={node.id} value={node.id}>
                    {node.name}{node.enabled ? '' : '（停用）'}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <span className="hidden truncate text-xs text-muted-foreground sm:inline" title={activeNodeName}>{activeNodeName}</span>
            <span className={canWriteSelectedNode ? 'text-xs text-emerald-600' : 'text-xs text-destructive'}>
              {canWriteSelectedNode ? '可用' : '不可用'}
            </span>
          </div>

          <div className="flex items-center rounded-md border p-1">
            {QUOTA_WINDOW_OPTIONS.map(option => (
              <Button
                key={option.id}
                type="button"
                size="sm"
                variant={quotaWindowFilter === option.id ? 'secondary' : 'ghost'}
                className="h-8 px-2.5"
                onClick={() => setQuotaWindowFilter(option.id)}
              >
                {option.label}
              </Button>
            ))}
          </div>

          <Button
            variant="outline"
            onClick={uploadAuthFiles}
            disabled={!canWriteSelectedNode || loading || uploadingAuthFiles || bulkUpdatingDisabledFiles}
          >
            {uploadingAuthFiles ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Upload className="mr-2 h-4 w-4" />
            )}
            {t('quota.importAuthFiles')}
          </Button>

          <Button
            variant="outline"
            onClick={enableAllAuthFiles}
            disabled={!canWriteSelectedNode || loading || uploadingAuthFiles || bulkUpdatingDisabledFiles}
            title={t('quota.enableAllAccounts')}
          >
            {bulkUpdatingDisabledFiles ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Power className="mr-2 h-4 w-4" />
            )}
            {t('quota.enableAllAccounts')}
          </Button>
        </div>

        <div className="flex flex-wrap items-center gap-2 rounded-md border bg-background/60 p-3">
          <div className="mr-1 flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <SlidersHorizontal className="h-4 w-4" />
            高级操作
          </div>
            <Button
              variant="outline"
              className="text-orange-700 hover:bg-orange-500/10 hover:text-orange-700"
              onClick={disableZeroQuotaAuthFiles}
              disabled={!canWriteSelectedNode || loading || uploadingAuthFiles || bulkUpdatingDisabledFiles || zeroQuotaFileCount === 0}
              title={t('quota.disableZeroQuotaTitle')}
            >
              {bulkUpdatingDisabledFiles ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <PowerOff className="mr-2 h-4 w-4" />
              )}
              {t('quota.disableZeroQuota', { count: zeroQuotaFileCount })}
            </Button>

            <Button
              variant="outline"
              className="text-red-700 hover:bg-red-500/10 hover:text-red-700"
              onClick={preferLowQuotaAuthFiles}
              disabled={!canWriteSelectedNode || loading || uploadingAuthFiles || bulkUpdatingDisabledFiles || lowQuotaFileCount === 0}
              title={t('quota.preferLowQuotaTitle', '只启用 0-20% 剩余的账号')}
            >
              <PowerOff className="mr-2 h-4 w-4" />
              {t('quota.preferLowQuota', '优先低额度（{{count}}）', { count: lowQuotaFileCount })}
            </Button>

            <Button
              variant="outline"
              className="text-amber-700 hover:bg-amber-500/10 hover:text-amber-700"
              onClick={preferWatchQuotaAuthFiles}
              disabled={!canWriteSelectedNode || loading || uploadingAuthFiles || bulkUpdatingDisabledFiles || watchQuotaFileCount === 0}
              title={t('quota.preferWatchQuotaTitle', '只启用 21-50% 剩余的账号')}
            >
              <PowerOff className="mr-2 h-4 w-4" />
              {t('quota.preferWatchQuota', '优先注意（{{count}}）', { count: watchQuotaFileCount })}
            </Button>

            <Button
              variant="outline"
              className="text-yellow-700 hover:bg-yellow-500/10 hover:text-yellow-700"
              onClick={disableAllButBestAuthFile}
              disabled={!canWriteSelectedNode || loading || uploadingAuthFiles || bulkUpdatingDisabledFiles}
              title={t('quota.disableAllExceptBest')}
            >
              {bulkUpdatingDisabledFiles ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <PowerOff className="mr-2 h-4 w-4" />
              )}
              {t('quota.disableAllExceptBest')}
            </Button>

            <Button
              variant="outline"
              className="text-destructive hover:bg-destructive/10 hover:text-destructive"
              onClick={() => {
                if (window.confirm(t('quota.deleteInvalidTokenConfirm', { count: invalidTokenFileCount }))) {
                  deleteInvalidTokenAuthFiles();
                }
              }}
              disabled={!canWriteSelectedNode || loading || uploadingAuthFiles || bulkUpdatingDisabledFiles || deletingInvalidTokenFiles || invalidTokenFileCount === 0}
              title={t('quota.deleteInvalidTokenTitle')}
            >
              {deletingInvalidTokenFiles ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <ShieldAlert className="mr-2 h-4 w-4" />
              )}
              {t('quota.deleteInvalidToken', { count: invalidTokenFileCount })}
            </Button>

            <Button
              variant="outline"
              className="text-destructive hover:bg-destructive/10 hover:text-destructive"
              onClick={() => {
                if (window.confirm(t('quota.deleteUnavailableConfirm', { count: unavailableFileCount }))) {
                  deleteUnavailableAuthFiles();
                }
              }}
              disabled={!canWriteSelectedNode || loading || uploadingAuthFiles || bulkUpdatingDisabledFiles || deletingUnavailableFiles || unavailableFileCount === 0}
            >
              {deletingUnavailableFiles ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Trash2 className="mr-2 h-4 w-4" />
              )}
              {t('quota.deleteUnavailable', { count: unavailableFileCount })}
            </Button>
        </div>
      </div>
      {error && (

        <div className="rounded-md bg-destructive/10 p-4 text-destructive">
          {error}
        </div>
      )}

      {/* Filter Tabs */}
      {filterItems.length > 0 && (
          <ProviderFilter
            items={filterItems}
            activeId={activeTab}
            onSelect={setActiveTab}
          />
      )}

      {filterItems.length > 0 && (
        <QuotaSummaryCard sections={filteredSections} />
      )}

      {/* Loading State */}
      {loading && sections.every(s => s.files.length === 0) && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      )}

      {/* Empty State */}
      {!loading && filterItems.length === 0 && (
          <Card className="border">
              <CardContent className="flex flex-col items-center justify-center py-12">
                  <p className="text-muted-foreground">{t('quota.noCredentials')}</p>
              </CardContent>
          </Card>
      )}

      {/* Filtered Content */}
      {viewMode === 'list' ? (
        <div className="space-y-4">
          {visibleDisplayedFiles.map(file => {
            const items = file.models || file.limits || [];
            const deleteName = (
              file.originalFile?.name ||
              file.originalFile?.filename ||
              file.originalFile?.id ||
              file.fileId
            ) as string;
            const disabled = isAuthFileDisabled(file.originalFile);
            return (
              <ProviderQuotaCard
                key={file.fileId}
                fileId={file.fileId}
                filename={file.filename}
                provider={file.provider}
                email={file.email || file.originalFile?.account || '********@*****.com'}
                loading={file.loading}
                error={file.error}
                items={items}
                plan={file.plan}
                source={getImportSource(file)}
                importedAt={formatImportTime(file)}
                disabled={disabled}
                updatingDisabled={Boolean(updatingDisabledFileIds[file.fileId])}
                onRefresh={() => fetchQuotaForFile(file.fileId, file.originalFile, { force: true })}
                onDelete={() => deleteAuthFile(deleteName)}
                onToggleDisabled={() => toggleAuthFileDisabled(file, !disabled)}
                isPrivacyMode={isPrivacyMode}
                now={now}
              />
            );
          })}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {visibleDisplayedFiles.map(file => {
            const items = file.models || file.limits || [];
            const deleteName = (
              file.originalFile?.name ||
              file.originalFile?.filename ||
              file.originalFile?.id ||
              file.fileId
            ) as string;
            const disabled = isAuthFileDisabled(file.originalFile);
            return (
              <CompactQuotaCard
                key={file.fileId}
                fileId={file.fileId}
                filename={file.filename}
                provider={file.provider}
                email={file.email || file.originalFile?.account || '********@*****.com'}
                loading={file.loading}
                error={file.error}
                items={items}
                plan={file.plan}
                source={getImportSource(file)}
                importedAt={formatImportTime(file)}
                disabled={disabled}
                updatingDisabled={Boolean(updatingDisabledFileIds[file.fileId])}
                onRefresh={() => fetchQuotaForFile(file.fileId, file.originalFile, { force: true })}
                onDelete={() => deleteAuthFile(deleteName)}
                onToggleDisabled={() => toggleAuthFileDisabled(file, !disabled)}
                isPrivacyMode={isPrivacyMode}
                now={now}
              />
            );
          })}
        </div>
      )}

      {hasMoreDisplayedFiles && (
        <div className="flex justify-center">
          <Button
            type="button"
            variant="outline"
            onClick={() => setVisibleCount(count => count + VISIBLE_BATCH_SIZE)}
          >
            加载更多（{Math.min(visibleCount, filteredDisplayedFiles.length)}/{filteredDisplayedFiles.length}）
          </Button>
        </div>
      )}
      </motion.div>

    </>
  );
}



