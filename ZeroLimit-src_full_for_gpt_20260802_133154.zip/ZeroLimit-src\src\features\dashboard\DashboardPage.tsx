import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/shared/components/ui/card';
import { Button } from '@/shared/components/ui/button';
import { Badge } from '@/shared/components/ui/badge';
import { Progress } from '@/shared/components/ui/progress';
import { Activity, Bell, Cpu, Database, HardDrive, Loader2, Network, RefreshCw, Server, Users } from 'lucide-react';
import { useDashboardPresenter } from '@/features/dashboard/useDashboardPresenter';
import { toast } from 'sonner';

function clampPercent(value?: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, Number(value)));
}

function formatBytes(value?: number): string {
  if (!Number.isFinite(value) || Number(value) <= 0) return '-';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let size = Number(value);
  let unitIndex = 0;
  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex += 1;
  }
  return `${size.toFixed(size >= 10 || unitIndex === 0 ? 0 : 1)} ${units[unitIndex]}`;
}

function formatUptime(seconds?: number): string {
  if (!Number.isFinite(seconds) || Number(seconds) < 0) return '-';
  const days = Math.floor(Number(seconds) / 86400);
  const hours = Math.floor((Number(seconds) % 86400) / 3600);
  if (days > 0) return `${days} 天 ${hours} 小时`;
  return `${hours} 小时`;
}

function formatTime(timestamp: number | null): string {
  if (!timestamp) return '未刷新';
  return new Date(timestamp).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

export function DashboardPage() {
  const { t } = useTranslation();
  const {
    connectionStatus,
    dashboardLoading,
    activeAccountsCount,
    serverStatus,
    serverStatusError,
    lastServerRefresh,
    monitorUrl,
    notifyUrl,
    notifying,
    loadData,
    sendDingTalkReport,
  } = useDashboardPresenter();

  const memoryPercent = clampPercent(serverStatus?.memory?.usagePercent);
  const cpuPercent = clampPercent(serverStatus?.cpu?.usagePercent);
  const primaryDisk = serverStatus?.disks?.[0];
  const diskPercent = clampPercent(primaryDisk?.usagePercent);
  const quotaTotal = serverStatus?.quota?.accountsTotal ?? activeAccountsCount;
  const quotaSnapshot = serverStatus?.quotaSnapshot;
  const services = serverStatus?.services ?? [];

  const handleNotify = async () => {
    try {
      await sendDingTalkReport();
      toast.success('已推送到钉钉');
    } catch (error) {
      toast.error(`钉钉推送失败：${(error as Error).message}`);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6 p-2"
    >
      <div className="mb-6 flex items-center justify-between">
        <div className="flex flex-col gap-1">
          <h1 className="text-3xl font-bold tracking-tight text-foreground">
            {t('dashboard.hello')} <span className="text-primary">User</span>
          </h1>
          <p className="text-muted-foreground">
            {t('dashboard.welcomeMessage')}
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={loadData}
          disabled={dashboardLoading}
          className="h-8 gap-2"
        >
          <RefreshCw className={`h-4 w-4 ${dashboardLoading ? 'animate-spin' : ''}`} />
          <span className="hidden sm:inline">{t('common.refresh', 'Refresh')}</span>
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="overflow-hidden border-border/50 transition-all duration-300 hover:shadow-lg gap-2 py-2">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 p-4 pb-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t('dashboard.totalAccounts')}</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent className="px-4 pb-4 pt-0">
            <div className="text-3xl font-bold text-foreground">
              {connectionStatus === 'connecting' || dashboardLoading ? (
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              ) : (
                activeAccountsCount
              )}
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              {t('dashboard.totalAccounts')}
            </p>
          </CardContent>
        </Card>

        <Card className="overflow-hidden border-border/50 transition-all duration-300 hover:shadow-lg gap-2 py-2">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 p-4 pb-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t('dashboard.systemStatus')}</CardTitle>
            <Activity className={`h-4 w-4 ${connectionStatus === 'connected' ? 'text-muted-foreground' : 'text-red-500'}`} />
          </CardHeader>
                    <CardContent className="px-4 pb-4 pt-0">
            <div className="flex items-center gap-2">
              {connectionStatus === 'connecting' ? (
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              ) : (
                <span className={`h-2.5 w-2.5 rounded-full ${connectionStatus === 'connected' ? 'bg-emerald-500' : 'bg-red-500'}`} />
              )}
              <div className="text-3xl font-bold">
                {connectionStatus === 'connected' ? '\u5728\u7ebf' : connectionStatus === 'connecting' ? '\u68c0\u67e5\u4e2d' : '\u79bb\u7ebf'}
              </div>
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <Badge variant={connectionStatus === 'connected' ? 'secondary' : 'destructive'} className="rounded-md">
                {connectionStatus === 'connected' ? '\u8fde\u63a5\u6b63\u5e38' : '\u8fde\u63a5\u5f02\u5e38'}
              </Badge>
              <span>{'\u6700\u540e\u68c0\u67e5'} {formatTime(lastServerRefresh)}</span>
              {serverStatusError && <span className="truncate text-red-600 dark:text-red-400">{serverStatusError}</span>}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-border/50">
        <CardHeader className="flex flex-row items-start justify-between space-y-0">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              <Server className="h-4 w-4" />
              服务器状态
            </CardTitle>
            <p className="mt-1 text-sm text-muted-foreground">
              {monitorUrl ? `最后更新：${formatTime(lastServerRefresh)}` : '去设置里填写监控地址后显示服务器数据'}
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleNotify}
            disabled={!notifyUrl || notifying}
            className="h-8 gap-2"
          >
            {notifying ? <Loader2 className="h-4 w-4 animate-spin" /> : <Bell className="h-4 w-4" />}
            推送钉钉
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {serverStatusError && (
            <div className="rounded-md border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-600 dark:text-red-300">
              {serverStatusError}
            </div>
          )}

          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-md border p-3">
              <div className="mb-2 flex items-center justify-between text-sm">
                <span className="flex items-center gap-2 text-muted-foreground"><Cpu className="h-4 w-4" />CPU</span>
                <span className="font-medium">{cpuPercent.toFixed(0)}%</span>
              </div>
              <Progress value={cpuPercent} />
              <p className="mt-2 text-xs text-muted-foreground">
                {serverStatus?.cpu?.cores ? `${serverStatus.cpu.cores} 核` : '等待监控数据'}
              </p>
            </div>

            <div className="rounded-md border p-3">
              <div className="mb-2 flex items-center justify-between text-sm">
                <span className="flex items-center gap-2 text-muted-foreground"><Database className="h-4 w-4" />内存</span>
                <span className="font-medium">{memoryPercent.toFixed(0)}%</span>
              </div>
              <Progress value={memoryPercent} />
              <p className="mt-2 text-xs text-muted-foreground">
                {formatBytes(serverStatus?.memory?.used)} / {formatBytes(serverStatus?.memory?.total)}
              </p>
            </div>

            <div className="rounded-md border p-3">
              <div className="mb-2 flex items-center justify-between text-sm">
                <span className="flex items-center gap-2 text-muted-foreground"><HardDrive className="h-4 w-4" />磁盘</span>
                <span className="font-medium">{diskPercent.toFixed(0)}%</span>
              </div>
              <Progress value={diskPercent} />
              <p className="mt-2 truncate text-xs text-muted-foreground" title={primaryDisk?.mount}>
                {formatBytes(primaryDisk?.used)} / {formatBytes(primaryDisk?.total)} {primaryDisk?.mount || ''}
              </p>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-md border p-3">
              <div className="text-sm text-muted-foreground">主机</div>
              <div className="mt-1 font-medium">{serverStatus?.hostname || '-'}</div>
              <p className="mt-1 text-xs text-muted-foreground">运行时间 {formatUptime(serverStatus?.uptimeSec)}</p>
            </div>
            <div className="rounded-md border p-3">
              <div className="text-sm text-muted-foreground">负载</div>
              <div className="mt-1 font-medium">
                {[serverStatus?.load?.one, serverStatus?.load?.five, serverStatus?.load?.fifteen]
                  .map((value) => Number.isFinite(value) ? Number(value).toFixed(2) : '-')
                  .join(' / ')}
              </div>
              <p className="mt-1 text-xs text-muted-foreground">1 / 5 / 15 分钟</p>
            </div>
            <div className="rounded-md border p-3">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Network className="h-4 w-4" />
                网络
              </div>
              <div className="mt-1 font-medium">
                ↓ {formatBytes(serverStatus?.network?.rxRateBps)}/s · ↑ {formatBytes(serverStatus?.network?.txRateBps)}/s
              </div>
              <p className="mt-1 text-xs text-muted-foreground">累计 ↓ {formatBytes(serverStatus?.network?.rxBytes)} · ↑ {formatBytes(serverStatus?.network?.txBytes)}</p>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-md border p-3">
              <div className="mb-3 text-sm font-medium">服务检查</div>
              {services.length > 0 ? (
                <div className="space-y-2">
                  {services.map((service) => (
                    <div key={service.name} className="flex items-center justify-between gap-3 text-sm">
                      <span className="truncate">{service.name}</span>
                      <Badge variant={service.status === 'ok' ? 'default' : 'destructive'}>
                        {service.status === 'ok' ? '正常' : '异常'}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">暂未配置服务检查</p>
              )}
            </div>

            <div className="rounded-md border p-3">
              <div className="mb-3 text-sm font-medium">ZeroLimit 核心数据</div>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div>
                  <div className="text-2xl font-bold">{quotaSnapshot ? `${quotaSnapshot.average}%` : '-'}</div>
                  <div className="text-xs text-muted-foreground">总剩余</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">{quotaTotal}</div>
                  <div className="text-xs text-muted-foreground">账号总数</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">{quotaSnapshot?.itemCount ?? '-'}</div>
                  <div className="text-xs text-muted-foreground">额度项</div>
                </div>
              </div>
              <p className="mt-3 text-xs text-muted-foreground">
                启用 {serverStatus?.quota?.accountsEnabled ?? '-'} · 停用 {serverStatus?.quota?.accountsDisabled ?? '-'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
