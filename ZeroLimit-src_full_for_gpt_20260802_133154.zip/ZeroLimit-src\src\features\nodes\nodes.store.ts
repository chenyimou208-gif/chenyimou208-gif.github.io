import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { STORAGE_KEY_CPA_NODES } from '@/constants';
import { secureStorage } from '@/services/storage/secureStorage';
import { normalizeApiBase } from '@/shared/utils/connection';
import type { CpaNode, CpaNodeConnectionConfig, CpaNodeInput } from '@/types';
export { ALL_CPA_NODES_ID } from '@/types';

const LEGACY_DEFAULT_NODE_ID = 'default';

function nowIso(): string {
  return new Date().toISOString();
}

function createNodeId(): string {
  const randomId = typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  return `node-${randomId}`;
}

function cleanInput(input: CpaNodeInput): (CpaNodeInput & { enabled: boolean }) | null {
  const rawBase = input.apiBase.trim();
  const managementKey = input.managementKey.trim();
  if (!rawBase || !managementKey) return null;

  return {
    name: input.name.trim() || 'CPA 节点',
    apiBase: normalizeApiBase(rawBase),
    managementKey,
    enabled: input.enabled ?? true,
    tags: input.tags?.trim() || undefined,
  };
}

function sameConnection(a: CpaNodeConnectionConfig, b: CpaNodeConnectionConfig): boolean {
  return normalizeApiBase(a.apiBase) === normalizeApiBase(b.apiBase) && a.managementKey === b.managementKey;
}

interface CpaNodesState {
  nodes: CpaNode[];
  defaultNodeId: string | null;
  selectedNodeId: string | null;
  addNode: (input: CpaNodeInput) => CpaNode | null;
  updateNode: (id: string, input: CpaNodeInput) => CpaNode | null;
  removeNode: (id: string) => void;
  setDefaultNode: (id: string) => void;
  setSelectedNode: (id: string | null) => void;
  toggleNode: (id: string, enabled: boolean) => void;
  markNodeConnected: (id: string) => void;
  ensureDefaultNode: (input: CpaNodeInput, options?: { name?: string; markConnected?: boolean }) => CpaNode | null;
  getDefaultNode: () => CpaNode | null;
  getSelectedNode: () => CpaNode | null;
  getEnabledNodes: () => CpaNode[];
  getNodeConfig: (id: string | null | undefined) => CpaNodeConnectionConfig | null;
}

export const useCpaNodesStore = create<CpaNodesState>()(
  persist(
    (set, get) => ({
      nodes: [],
      defaultNodeId: null,
      selectedNodeId: null,

      addNode: (input) => {
        const cleaned = cleanInput(input);
        if (!cleaned) return null;

        const existing = get().nodes.find(node => sameConnection(node, cleaned));
        if (existing) {
          const updated = { ...existing, ...cleaned, id: existing.id, createdAt: existing.createdAt };
          set(state => ({
            nodes: state.nodes.map(node => node.id === existing.id ? updated : node),
            defaultNodeId: state.defaultNodeId || updated.id,
            selectedNodeId: state.selectedNodeId || updated.id,
          }));
          return updated;
        }

        const node: CpaNode = {
          ...cleaned,
          id: get().nodes.length === 0 ? LEGACY_DEFAULT_NODE_ID : createNodeId(),
          createdAt: nowIso(),
        };

        set(state => ({
          nodes: [...state.nodes, node],
          defaultNodeId: state.defaultNodeId || node.id,
          selectedNodeId: state.selectedNodeId || node.id,
        }));
        return node;
      },

      updateNode: (id, input) => {
        const cleaned = cleanInput(input);
        if (!cleaned) return null;

        let updatedNode: CpaNode | null = null;
        set(state => ({
          nodes: state.nodes.map(node => {
            if (node.id !== id) return node;
            updatedNode = { ...node, ...cleaned };
            return updatedNode;
          }),
        }));
        return updatedNode;
      },

      removeNode: (id) => {
        set(state => {
          const nodes = state.nodes.filter(node => node.id !== id);
          const nextDefault = state.defaultNodeId === id ? (nodes[0]?.id ?? null) : state.defaultNodeId;
          const nextSelected = state.selectedNodeId === id ? nextDefault : state.selectedNodeId;
          return { nodes, defaultNodeId: nextDefault, selectedNodeId: nextSelected };
        });
      },

      setDefaultNode: (id) => {
        const exists = get().nodes.some(node => node.id === id);
        if (!exists) return;
        set({ defaultNodeId: id, selectedNodeId: id });
      },

      setSelectedNode: (id) => set({ selectedNodeId: id }),

      toggleNode: (id, enabled) => {
        set(state => ({
          nodes: state.nodes.map(node => node.id === id ? { ...node, enabled } : node),
        }));
      },

      markNodeConnected: (id) => {
        const lastConnectedAt = nowIso();
        set(state => ({
          nodes: state.nodes.map(node => node.id === id ? { ...node, lastConnectedAt, enabled: true } : node),
        }));
      },

      ensureDefaultNode: (input, options = {}) => {
        const cleaned = cleanInput({ ...input, name: options.name || input.name || '默认节点' });
        if (!cleaned) return null;

        const connectedAt = options.markConnected ? nowIso() : undefined;
        const existing = get().nodes.find(node => sameConnection(node, cleaned));
        if (existing) {
          const updated = {
            ...existing,
            ...cleaned,
            name: existing.name || cleaned.name,
            lastConnectedAt: connectedAt || existing.lastConnectedAt,
          };
          set(state => ({
            nodes: state.nodes.map(node => node.id === existing.id ? updated : node),
            defaultNodeId: state.defaultNodeId || updated.id,
            selectedNodeId: state.selectedNodeId || updated.id,
          }));
          return updated;
        }

        const id = get().nodes.length === 0 ? LEGACY_DEFAULT_NODE_ID : createNodeId();
        const node: CpaNode = {
          ...cleaned,
          id,
          createdAt: nowIso(),
          lastConnectedAt: connectedAt,
        };
        set(state => ({
          nodes: [...state.nodes, node],
          defaultNodeId: state.defaultNodeId || node.id,
          selectedNodeId: state.selectedNodeId || node.id,
        }));
        return node;
      },

      getDefaultNode: () => {
        const { nodes, defaultNodeId } = get();
        return nodes.find(node => node.id === defaultNodeId) || nodes.find(node => node.enabled) || nodes[0] || null;
      },

      getSelectedNode: () => {
        const { nodes, selectedNodeId } = get();
        return nodes.find(node => node.id === selectedNodeId) || get().getDefaultNode();
      },

      getEnabledNodes: () => get().nodes.filter(node => node.enabled),

      getNodeConfig: (id) => {
        const node = id ? get().nodes.find(item => item.id === id) : get().getDefaultNode();
        if (!node) return null;
        return { apiBase: node.apiBase, managementKey: node.managementKey };
      },
    }),
    {
      name: STORAGE_KEY_CPA_NODES,
      storage: createJSONStorage(() => ({
        getItem: (name) => {
          const data = secureStorage.getItem<Pick<CpaNodesState, 'nodes' | 'defaultNodeId' | 'selectedNodeId'>>(name);
          return data ? JSON.stringify(data) : null;
        },
        setItem: (name, value) => secureStorage.setItem(name, JSON.parse(value)),
        removeItem: (name) => secureStorage.removeItem(name),
      })),
      partialize: (state) => ({
        nodes: state.nodes,
        defaultNodeId: state.defaultNodeId,
        selectedNodeId: state.selectedNodeId,
      }),
    }
  )
);