/**
 * Compact Quota Card for Grid View
 */

import { Card } from '@/shared/components/ui/card';
import { Badge } from '@/shared/components/ui/badge';
import { Clock, RefreshCw, Eye, List, ChevronDown, Ban, Trash2, Power, Loader2 } from 'lucide-react';
import { useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/shared/components/ui/dialog'
import { maskEmail, maskFolder } from '@/shared/utils/privacy';
import { cn } from '@/shared/lib/utils';
import type { QuotaModel } from '@/types';

function isLimitQuotaName(name: string) {
  const lower = name.toLowerCase();
  return (
    lower.includes('hour') ||
    lower.includes('weekly') ||
    lower.includes('monthly') ||
    lower.includes('review') ||
    lower.includes('limit') ||
    lower.includes('\u5c0f\u65f6') ||
    lower.includes('\u5c0f\u6642') ||
    lower.includes('\u5468') ||
    lower.includes('\u6708') ||
    lower.includes('\u5ba1\u67e5') ||
    lower.includes('\u9650\u989d')
  );
}

function getEarliestResetAt(items: QuotaModel[]): number | undefined {
  const resetTimes = items
    .map(item => item.resetAt)
    .filter((value): value is number => Number.isFinite(value));
  return resetTimes.length > 0 ? Math.min(...resetTimes) : undefined;
}

function formatResetCountdown(resetAt?: number, fallback?: string, now = Date.now()): string | undefined {
  if (!Number.isFinite(resetAt)) return fallback;
  const diff = Number(resetAt) - now;
  if (diff <= 0) return 'Ready';

  const minutes = Math.max(1, Math.floor(diff / 60000));
  const days = Math.floor(minutes / 1440);
  const hours = Math.floor((minutes % 1440) / 60);
  const mins = minutes % 60;

  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${mins}m`;
  return `${mins}m`;
}

interface CompactQuotaCardProps {
  fileId: string;
  filename: string;
  provider: string;
  email?: string;
  loading: boolean;
  error?: string;
  items: QuotaModel[];
  plan?: string;
  source?: string;
  importedAt?: string;
  isCurrent?: boolean;
  disabled?: boolean;
  updatingDisabled?: boolean;
  now?: number;
  onRefresh: () => void;
  onDelete: () => void;
  onToggleDisabled: () => void;
  isPrivacyMode: boolean;
}

export function CompactQuotaCard({
  filename,
  email,
  loading,
  error,
  items,
  plan,
  source,
  importedAt,
  disabled = false,
  updatingDisabled = false,
  now = Date.now(),
  onRefresh,
  onDelete,
  onToggleDisabled,
  isPrivacyMode
}: CompactQuotaCardProps) {
  const { t } = useTranslation();
  const [isExpanded, setIsExpanded] = useState(true);

  // Check if account is suspended
  const isSuspended = plan?.toLowerCase() === 'suspended';

  // Apply masking
  const displayEmail = isPrivacyMode ? maskEmail(email || '') : (email || '********@*****.com');
  const displayFilename = isPrivacyMode ? maskFolder(filename) : filename;
  const displaySource = isPrivacyMode ? maskFolder(source || '') : (source || t('quotaCard.unknown'));

  // Group items by model type (for Antigravity) or show as-is (for Codex limits)
  const groupedItems = useMemo(() => {
    const groups: Record<string, QuotaModel[]> = {};

    items.forEach(item => {
      const name = item.name.toLowerCase();
      let groupName: string;

      // Codex limits - show each with its own name (no grouping)
      if (isLimitQuotaName(name)) {
        groupName = item.name; // Use original name as group name
      }
      // Antigravity models - group by type
      else if (name.includes('gemini') && name.includes('pro')) groupName = 'G3 Pro';
      else if (name.includes('gemini') && name.includes('flash')) groupName = 'G3 Flash';
      else if (name.includes('gemini') && name.includes('image')) groupName = 'G3 Image';
      else if (name.includes('claude')) groupName = 'Claude';
      else if (name.includes('gemini')) groupName = 'Gemini';
      else groupName = item.name; // Default: use original name

      if (!groups[groupName]) groups[groupName] = [];
      groups[groupName].push(item);
    });

    return Object.entries(groups).map(([name, groupItems]) => {
      const total = groupItems.reduce((sum, i) => sum + i.percentage, 0);
      const avg = Math.round(total / groupItems.length);
      const resetTime = groupItems.find(i => i.resetTime)?.resetTime;
      const resetAt = getEarliestResetAt(groupItems);

      return { name, percentage: avg, resetTime, resetAt, items: groupItems };
    }).sort((a, b) => a.name.localeCompare(b.name));
  }, [items]);

  const getProgressColor = (pct: number) => {
    if (pct > 50) return 'bg-green-500';
    if (pct > 20) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getPercentColor = (pct: number) => {
    if (pct > 50) return 'text-green-600';
    if (pct > 20) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Card className={cn(
      "p-4 space-y-3 hover:shadow-md transition-shadow h-full flex flex-col",
      disabled && "border-dashed opacity-70"
    )}>
      {/* Email with expand/collapse toggle */}
      <div className="flex items-center justify-between min-w-0">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-0.5 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
          >
            {isExpanded ? (
              <List className="h-4 w-4 text-green-500" />
            ) : (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            )}
          </button>
          <span className="font-semibold text-sm truncate" title={isPrivacyMode ? undefined : email}>{displayEmail}</span>
        </div>
        {disabled && (
          <Badge variant="outline" className="ml-2 border-yellow-500/40 bg-yellow-500/10 text-yellow-700 dark:text-yellow-300">
            {t('quota.disabled')}
          </Badge>
        )}
      </div>

      <div className="space-y-1 text-[11px] text-muted-foreground">
        <div className="truncate" title={isPrivacyMode ? undefined : source}>
          {t('quotaCard.source')}: <span className="font-medium text-foreground/80">{displaySource}</span>
        </div>
        <div className="truncate" title={isPrivacyMode ? undefined : filename}>
          {t('quotaCard.file')}: <span className="font-medium text-foreground/80">{displayFilename}</span>
        </div>
        {importedAt && (
          <div className="truncate">
            {t('quotaCard.importedAt')}: <span className="font-medium text-foreground/80">{importedAt}</span>
          </div>
        )}
      </div>

      {/* Error state */}
      {disabled && (
        <div className="flex items-center gap-2 rounded-md bg-yellow-500/10 px-2 py-2 text-xs text-muted-foreground">
          <Power className="h-3.5 w-3.5 text-yellow-600" />
          <span>{t('quota.disabledAccountHint')}</span>
        </div>
      )}

      {error && !loading && !disabled && (
        <div className="text-xs text-destructive truncate">{error}</div>
      )}

      {/* Suspended State - centered icon and text */}
      {!loading && !error && !disabled && isSuspended && (
        <div className="flex flex-col items-center justify-center py-6 gap-2 flex-1">
          <Ban className="h-10 w-10 text-yellow-500" />
          <span className="text-sm font-semibold text-yellow-600">Temporarily Suspended</span>
        </div>
      )}

      {/* Model badges grid with progress bars - expanded view */}
      {!loading && !error && !disabled && !isSuspended && isExpanded && (
        <div className="grid grid-cols-1 gap-2 flex-1">
          {groupedItems.map((group, idx) => (
            <div key={idx} className="space-y-1">
              {/* Model info row */}
              <div className="flex items-center gap-1 text-xs min-w-0">
                <span className="text-muted-foreground font-medium truncate flex-1" title={group.name}>{group.name}</span>
                {group.resetTime && (
                  <span className="flex items-center gap-0.5 text-muted-foreground text-[10px] flex-shrink-0">
                    <Clock className="h-3 w-3 text-orange-400" />
                    {formatResetCountdown(group.resetAt, group.resetTime, now)}
                  </span>
                )}
                <span className={`font-bold flex-shrink-0 ${getPercentColor(group.percentage)}`}>
                  {group.percentage}%
                </span>
              </div>
              {/* Progress bar */}
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${getProgressColor(group.percentage)}`}
                  style={{ width: `${group.percentage}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Collapsed compact summary view - simple inline text */}
      {!loading && !error && !disabled && !isSuspended && !isExpanded && (
        <div className="text-xs text-muted-foreground space-y-1">
          {groupedItems.map((group, idx) => (
            <div key={idx} className="flex items-center justify-between gap-2 min-w-0">
              <span className="font-medium truncate flex-1" title={group.name}>{group.name}</span>
              <div className="flex items-center gap-2 flex-shrink-0">
                <span className={`font-bold ${getPercentColor(group.percentage)}`}>
                  {group.percentage}%
                </span>
                {group.resetTime && (
                  <span className="flex items-center gap-0.5 text-[10px]">
                    <Clock className="h-2.5 w-2.5" />
                    {formatResetCountdown(group.resetAt, group.resetTime, now)}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Footer Row */}
      <div className="flex items-center justify-between pt-2 border-t text-xs text-muted-foreground mt-auto">
        <span>{importedAt || t('quotaCard.unknown')}</span>
        <div className="flex items-center gap-1">
          <button
            className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground disabled:opacity-50"
            onClick={(e) => { e.stopPropagation(); onToggleDisabled(); }}
            disabled={updatingDisabled}
            title={disabled ? t('quota.enableAccount') : t('quota.disableAccount')}
          >
            {updatingDisabled ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <Power className="h-3.5 w-3.5" />
            )}
          </button>
          {/* View Details Dialog */}
          <Dialog>
            <DialogTrigger asChild>
              <button
                className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground"
                title="View details"
              >
                <Eye className="h-3.5 w-3.5" />
              </button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto no-scrollbar">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3 text-xl">
                  <span>Quota Details</span>
                  <Badge variant="secondary" className="font-mono font-normal text-sm px-2">
                    {displayEmail}
                  </Badge>
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-4 mt-4">
                {groupedItems.map((group, groupIdx) => (
                  <div key={groupIdx} className="space-y-3">
                    <div className="flex items-center gap-2 border-b pb-2">
                      <h3 className="font-semibold text-lg">{group.name}</h3>
                      <Badge variant="outline" className="ml-auto">
                        {group.items.length} models
                      </Badge>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {group.items.map((item, idx) => (
                        <div key={idx} className="rounded-lg border bg-card p-3 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-sm truncate max-w-[180px]" title={item.name}>
                              {item.name}
                            </span>
                            <span className={`font-bold text-sm ${getPercentColor(item.percentage)}`}>
                              {item.percentage}%
                            </span>
                          </div>
                          <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                            <div
                              className={`h-full rounded-full ${getProgressColor(item.percentage)}`}
                              style={{ width: `${item.percentage}%` }}
                            />
                          </div>
                          {item.resetTime && (
                            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                              <Clock className="h-3 w-3" />
                              <span>Reset: {formatResetCountdown(item.resetAt, item.resetTime, now)}</span>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </DialogContent>
          </Dialog>

          <button
            className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground"
            onClick={(e) => { e.stopPropagation(); onRefresh(); }}
            disabled={loading || disabled}
            title="Refresh"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            className="p-1 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive"
            onClick={(e) => {
              e.stopPropagation();
              if (window.confirm(t('quota.deleteConfirm', 'Delete this auth file?'))) {
                onDelete();
              }
            }}
            title={t('common.delete')}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </Card>
  );
}
