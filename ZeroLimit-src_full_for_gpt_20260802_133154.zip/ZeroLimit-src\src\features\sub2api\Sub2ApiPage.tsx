import { useCallback, useEffect, useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { toast } from 'sonner';
import {
  AlertCircle,
  CheckCircle,
  Eye,
  EyeOff,
  FileText,
  Key,
  Loader2,
  Play,
  Power,
  PowerOff,
  RefreshCw,
  Search,
  Server,
  Trash2,
  Upload,
  XCircle,
} from 'lucide-react';
import { useSub2ApiStore } from '@/features/settings/sub2api.store';
import { sub2apiApi } from '@/services/api/sub2api.service';
import { maskEmail } from '@/shared/utils/privacy';
import { Button } from '@/shared/components/ui/button';
import { Input } from '@/shared/components/ui/input';
import { Label } from '@/shared/components/ui/label';
import { Badge } from '@/shared/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/shared/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/shared/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/shared/components/ui/table';
import type { Sub2ApiAccount, Sub2ApiBatchResult, Sub2ApiConfig, Sub2ApiQuotaResult } from '@/types';

type ImportMode = 'data' | 'codex-session';

const TOKEN_LIKE_KEYS = new Set([
  'access_token',
  'refresh_token',
  'id_token',
  'session_token',
  'token',
  'key',
  'password',
  'secret',
  'authorization',
]);

function accountId(account: Sub2ApiAccount): string {
  return String(account.id);
}

function readString(record: Record<string, unknown>, keys: string[]): string {
  for (const key of keys) {
    const value = record[key];
    if (typeof value === 'string' && value.trim()) return value.trim();
    if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  }
  return '';
}

function readBoolean(record: Record<string, unknown>, keys: string[]): boolean | null {
  for (const key of keys) {
    const value = record[key];
    if (typeof value === 'boolean') return value;
    if (typeof value === 'number') return value === 1;
    if (typeof value === 'string') {
      const normalized = value.trim().toLowerCase();
      if (['true', '1', 'yes', 'enabled', 'active'].includes(normalized)) return true;
      if (['false', '0', 'no', 'disabled', 'inactive'].includes(normalized)) return false;
    }
  }
  return null;
}

function resolveEmail(account: Sub2ApiAccount): string {
  const record = account as Record<string, unknown>;
  return (
    readString(record, ['email', 'account', 'username', 'user_email', 'name']) ||
    `account-${accountId(account)}`
  );
}

function resolveName(account: Sub2ApiAccount): string {
  const record = account as Record<string, unknown>;
  return readString(record, ['name', 'display_name', 'remark', 'notes']) || resolveEmail(account);
}

function resolvePlatform(account: Sub2ApiAccount): string {
  const record = account as Record<string, unknown>;
  return readString(record, ['platform', 'provider', 'type', 'service']) || 'unknown';
}

function resolveStatus(account: Sub2ApiAccount): string {
  const record = account as Record<string, unknown>;
  const status = readString(record, ['status', 'state']);
  if (status) return status;

  const enabled = readBoolean(record, ['enabled', 'active']);
  if (enabled !== null) return enabled ? 'active' : 'disabled';

  const disabled = readBoolean(record, ['disabled']);
  if (disabled !== null) return disabled ? 'disabled' : 'active';

  return 'unknown';
}

function resolveSchedulable(account: Sub2ApiAccount): boolean | null {
  return readBoolean(account as Record<string, unknown>, ['schedulable', 'is_schedulable', 'available']);
}

function resolveError(account: Sub2ApiAccount): string {
  const record = account as Record<string, unknown>;
  return readString(record, ['error', 'error_message', 'last_error', 'reason']);
}

function hasProblem(account: Sub2ApiAccount): boolean {
  if (resolveError(account)) return true;
  const status = resolveStatus(account).toLowerCase();
  if (['error', 'failed', 'invalid', 'expired', 'banned', 'suspended', 'unavailable'].includes(status)) {
    return true;
  }
  const available = readBoolean(account as Record<string, unknown>, ['available', 'healthy']);
  return available === false;
}

function statusBadgeClass(account: Sub2ApiAccount): string {
  const status = resolveStatus(account).toLowerCase();
  if (hasProblem(account)) return 'border-red-500/40 bg-red-500/10 text-red-600 dark:text-red-300';
  if (['active', 'enabled', 'ok', 'normal'].includes(status)) return 'border-green-500/40 bg-green-500/10 text-green-700 dark:text-green-300';
  if (['disabled', 'inactive', 'paused'].includes(status)) return 'border-yellow-500/40 bg-yellow-500/10 text-yellow-700 dark:text-yellow-300';
  return 'border-muted-foreground/30';
}

function formatDate(value: unknown): string {
  if (typeof value !== 'string' && typeof value !== 'number') return '-';
  const parsed = typeof value === 'number' ? value : Date.parse(value);
  if (!Number.isFinite(parsed)) return String(value);
  return new Date(parsed).toLocaleString('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
}

function maskDeep(value: unknown, depth = 0): unknown {
  if (depth > 4) return '[Object]';
  if (Array.isArray(value)) return value.slice(0, 20).map(item => maskDeep(item, depth + 1));
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([key, item]) => [
        key,
        TOKEN_LIKE_KEYS.has(key.toLowerCase()) ? '***' : maskDeep(item, depth + 1),
      ])
    );
  }
  return value;
}

function compactJson(value: unknown): string {
  if (value === undefined || value === null || value === '') return '-';
  try {
    const text = JSON.stringify(maskDeep(value), null, 2);
    return text.length > 500 ? `${text.slice(0, 500)}...` : text;
  } catch {
    return String(value);
  }
}

function summarizeBatch(result: Sub2ApiBatchResult | unknown): string {
  if (!result || typeof result !== 'object') return '完成';
  const record = result as Sub2ApiBatchResult;
  const parts = [
    typeof record.success === 'number' ? `成功 ${record.success}` : '',
    typeof record.failed === 'number' ? `失败 ${record.failed}` : '',
    typeof record.created === 'number' ? `新增 ${record.created}` : '',
    typeof record.updated === 'number' ? `更新 ${record.updated}` : '',
    typeof record.skipped === 'number' ? `跳过 ${record.skipped}` : '',
  ].filter(Boolean);
  return parts.join('，') || '完成';
}

function quotaText(quota?: Sub2ApiQuotaResult | null): string {
  if (!quota) return '-';
  const direct = readString(quota as Record<string, unknown>, ['plan', 'subscription_plan', 'tier']);
  if (direct) return direct;
  return compactJson(quota);
}

export function Sub2ApiPage() {
  const {
    config,
    setConfig,
    connect,
    restore,
    disconnect,
    isConnected,
    isConnecting,
    connectionError,
    user,
  } = useSub2ApiStore();

  const [form, setForm] = useState<Sub2ApiConfig>(config);
  const [accounts, setAccounts] = useState<Sub2ApiAccount[]>([]);
  const [quotas, setQuotas] = useState<Record<string, Sub2ApiQuotaResult | null>>({});
  const [loading, setLoading] = useState(false);
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  const [showSecrets, setShowSecrets] = useState(false);
  const [importText, setImportText] = useState('');
  const [importName, setImportName] = useState('ZeroLimit import');
  const [importMode, setImportMode] = useState<ImportMode>('data');
  const [detailsAccount, setDetailsAccount] = useState<Sub2ApiAccount | null>(null);

  const loadAccounts = useCallback(async (force = false) => {
    if (!isConnected && !force) return;
    setLoading(true);
    setError(null);
    try {
      const result = await sub2apiApi.listAccounts({ page: 1, pageSize: 500, search });
      setAccounts(result.accounts);
      setSelected(prev => {
        const ids = new Set(result.accounts.map(accountId));
        return Object.fromEntries(Object.entries(prev).filter(([id]) => ids.has(id)));
      });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, [isConnected, search]);

  useEffect(() => {
    setForm(config);
  }, [config]);

  useEffect(() => {
    if (!config.rememberPassword || !config.password) return;
    restore().then((ok) => {
      if (ok) {
        window.setTimeout(() => {
          void loadAccounts(true);
        }, 0);
      }
    });
  }, []);

  useEffect(() => {
    if (isConnected) {
      void loadAccounts();
    }
  }, [isConnected, loadAccounts]);

  const filteredAccounts = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return accounts;
    return accounts.filter(account => {
      const haystack = [
        accountId(account),
        resolveEmail(account),
        resolveName(account),
        resolvePlatform(account),
        resolveStatus(account),
        resolveError(account),
      ].join(' ').toLowerCase();
      return haystack.includes(query);
    });
  }, [accounts, search]);

  const selectedIds = useMemo(
    () => Object.entries(selected).filter(([, value]) => value).map(([id]) => id),
    [selected]
  );

  const stats = useMemo(() => {
    const schedulableCount = accounts.filter(account => resolveSchedulable(account) !== false).length;
    const problemCount = accounts.filter(hasProblem).length;
    return {
      total: accounts.length,
      schedulable: schedulableCount,
      disabled: accounts.length - schedulableCount,
      problem: problemCount,
    };
  }, [accounts]);

  const setFormField = <K extends keyof Sub2ApiConfig>(key: K, value: Sub2ApiConfig[K]) => {
    setForm(current => ({ ...current, [key]: value }));
  };

  const saveAndConnect = async () => {
    try {
      setConfig(form);
      await connect(form);
      toast.success('Sub2API 已连接');
      await loadAccounts();
    } catch (err) {
      toast.error((err as Error).message);
    }
  };

  const runBusy = async (key: string, action: () => Promise<void>) => {
    setBusyKey(key);
    try {
      await action();
    } finally {
      setBusyKey(null);
    }
  };

  const runAccountAction = async (
    id: string,
    label: string,
    action: () => Promise<unknown>,
    options: { reload?: boolean; loadQuota?: boolean } = { reload: true }
  ) => {
    await runBusy(`${id}:${label}`, async () => {
      try {
        const result = await action();
        toast.success(`${label}：${summarizeBatch(result)}`);
        if (options.loadQuota) {
          setQuotas(current => ({ ...current, [id]: result as Sub2ApiQuotaResult }));
        }
        if (options.reload !== false) {
          await loadAccounts();
        }
      } catch (err) {
        toast.error(`${label}失败：${(err as Error).message}`);
      }
    });
  };

  const runBatch = async (label: string, ids: string[], action: (ids: string[]) => Promise<unknown>) => {
    if (ids.length === 0) {
      toast.info('请先选择账号');
      return;
    }

    await runBusy(`batch:${label}`, async () => {
      try {
        const result = await action(ids);
        toast.success(`${label}：${summarizeBatch(result)}`);
        await loadAccounts(true);
      } catch (err) {
        toast.error(`${label}失败：${(err as Error).message}`);
      }
    });
  };

  const toggleAllVisible = (checked: boolean) => {
    setSelected(current => {
      const next = { ...current };
      filteredAccounts.forEach(account => {
        next[accountId(account)] = checked;
      });
      return next;
    });
  };

  const pickImportFile = async () => {
    try {
      const { open } = await import('@tauri-apps/plugin-dialog');
      const { readTextFile } = await import('@tauri-apps/plugin-fs');
      const { basename } = await import('@tauri-apps/api/path');
      const path = await open({
        multiple: false,
        filters: [{ name: 'Sub2API', extensions: ['txt', 'json', 'sub', 'csv'] }],
      });
      if (!path || typeof path !== 'string') return;
      setImportText(await readTextFile(path));
      setImportName(await basename(path));
    } catch (err) {
      toast.error(`读取文件失败：${(err as Error).message}`);
    }
  };

  const importAccounts = async () => {
    const content = importText.trim();
    if (!content) {
      toast.info('请先选择文件或粘贴内容');
      return;
    }

    await runBusy('import', async () => {
      try {
        const result = importMode === 'codex-session'
          ? await sub2apiApi.importCodexSession(content, importName || 'ZeroLimit import')
          : await sub2apiApi.importAccountData(content);
        toast.success(`导入完成：${summarizeBatch(result)}`);
        setImportText('');
        await loadAccounts();
      } catch (err) {
        toast.error(`导入失败：${(err as Error).message}`);
      }
    });
  };

  const deleteUnavailable = async () => {
    const targets = accounts.filter(hasProblem).map(accountId);
    if (targets.length === 0) {
      toast.info('没有检测到异常账号');
      return;
    }
    if (!window.confirm(`确定删除 ${targets.length} 个异常账号吗？`)) return;

    await runBusy('delete-unavailable', async () => {
      let deleted = 0;
      for (const id of targets) {
        try {
          await sub2apiApi.deleteAccount(id);
          deleted += 1;
        } catch (err) {
          console.error('Failed to delete sub2api account', id, err);
        }
      }
      toast.success(`已删除 ${deleted} 个异常账号`);
      await loadAccounts();
    });
  };

  const allVisibleSelected = filteredAccounts.length > 0 && filteredAccounts.every(account => selected[accountId(account)]);
  const busy = Boolean(busyKey);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6"
    >
      <div className="flex flex-col gap-3 xl:flex-row xl:items-start xl:justify-between">
        <div>
          <h1 className="text-3xl font-bold">Sub2API</h1>
          <p className="text-sm text-muted-foreground">账号池、额度、状态和导入管理</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" onClick={() => setShowSecrets(value => !value)} title={showSecrets ? '隐藏敏感信息' : '显示敏感信息'}>
            {showSecrets ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
          </Button>
          <Button variant="outline" onClick={() => void loadAccounts()} disabled={!isConnected || loading || busy}>
            <RefreshCw className={`mr-2 h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            刷新
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="h-5 w-5" />
            连接
          </CardTitle>
          <CardDescription>
            {isConnected ? `已连接${user?.email ? `：${showSecrets ? user.email : maskEmail(user.email)}` : ''}` : '未连接'}
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 lg:grid-cols-2 xl:grid-cols-[1.3fr_1fr_1fr_1fr_auto] xl:items-end">
          <div className="space-y-2">
            <Label htmlFor="sub2api-base">地址</Label>
            <Input
              id="sub2api-base"
              value={form.baseUrl}
              onChange={(event) => setFormField('baseUrl', event.target.value)}
              placeholder="https://aisiu.me/sub2api"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="sub2api-email">邮箱</Label>
            <Input
              id="sub2api-email"
              value={form.email}
              onChange={(event) => setFormField('email', event.target.value)}
              placeholder="admin@sub2api.local"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="sub2api-password">密码</Label>
            <Input
              id="sub2api-password"
              type={showSecrets ? 'text' : 'password'}
              value={form.password}
              onChange={(event) => setFormField('password', event.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="sub2api-gateway-key">网关密钥</Label>
            <Input
              id="sub2api-gateway-key"
              type={showSecrets ? 'text' : 'password'}
              value={form.gatewayKey || ''}
              onChange={(event) => setFormField('gatewayKey', event.target.value)}
              placeholder="可留空"
            />
          </div>
          <div className="flex flex-col gap-2">
            <label className="flex h-8 items-center gap-2 text-xs text-muted-foreground">
              <input
                type="checkbox"
                checked={form.rememberPassword}
                onChange={(event) => setFormField('rememberPassword', event.target.checked)}
                className="h-4 w-4 rounded border-input accent-primary"
              />
              记住
            </label>
            <div className="flex gap-2">
              <Button onClick={saveAndConnect} disabled={isConnecting || busy || !form.baseUrl || !form.email || !form.password}>
                {isConnecting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Key className="mr-2 h-4 w-4" />}
                连接
              </Button>
              {isConnected && (
                <Button variant="outline" onClick={disconnect} disabled={busy}>
                  断开
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {(connectionError || error) && (
        <div className="flex items-center gap-2 rounded-md bg-destructive/10 p-4 text-sm text-destructive">
          <AlertCircle className="h-4 w-4" />
          <span>{connectionError || error}</span>
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="py-4">
          <CardContent className="flex items-center justify-between px-4">
            <span className="text-sm text-muted-foreground">账号</span>
            <span className="text-2xl font-semibold">{stats.total}</span>
          </CardContent>
        </Card>
        <Card className="py-4">
          <CardContent className="flex items-center justify-between px-4">
            <span className="text-sm text-muted-foreground">可调度</span>
            <span className="text-2xl font-semibold text-green-600">{stats.schedulable}</span>
          </CardContent>
        </Card>
        <Card className="py-4">
          <CardContent className="flex items-center justify-between px-4">
            <span className="text-sm text-muted-foreground">停用</span>
            <span className="text-2xl font-semibold text-yellow-600">{stats.disabled}</span>
          </CardContent>
        </Card>
        <Card className="py-4">
          <CardContent className="flex items-center justify-between px-4">
            <span className="text-sm text-muted-foreground">异常</span>
            <span className="text-2xl font-semibold text-red-600">{stats.problem}</span>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            导入
          </CardTitle>
          <CardDescription>{importName || '未选择文件'}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" onClick={pickImportFile} disabled={!isConnected || busy}>
              <FileText className="mr-2 h-4 w-4" />
              选择文件
            </Button>
            <select
              value={importMode}
              onChange={(event) => setImportMode(event.target.value as ImportMode)}
              className="h-9 rounded-md border bg-background px-3 text-sm"
            >
              <option value="data">Sub/账号数据</option>
              <option value="codex-session">Codex Session</option>
            </select>
            <Button onClick={importAccounts} disabled={!isConnected || busy || !importText.trim()}>
              {busyKey === 'import' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
              导入
            </Button>
          </div>
          <textarea
            value={importText}
            onChange={(event) => setImportText(event.target.value)}
            placeholder="粘贴 sub 内容、账号数据或 Codex Session JSON"
            className="min-h-28 w-full resize-y rounded-md border bg-background px-3 py-2 text-sm outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]"
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
            <div>
              <CardTitle>账号列表</CardTitle>
              <CardDescription>已选 {selectedIds.length} 个</CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="搜索账号"
                  className="h-9 w-52 pl-9"
                />
              </div>
              <Button
                variant="outline"
                onClick={() => void runBatch('批量刷新', selectedIds, ids => sub2apiApi.batchRefresh(ids))}
                disabled={!isConnected || busy || selectedIds.length === 0}
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                刷新选中
              </Button>
              <Button
                variant="outline"
                onClick={() => void runBatch('批量清错', selectedIds, ids => sub2apiApi.batchClearError(ids))}
                disabled={!isConnected || busy || selectedIds.length === 0}
              >
                <CheckCircle className="mr-2 h-4 w-4" />
                清错
              </Button>
              <Button
                variant="outline"
                onClick={() => void runBatch('启用选中', selectedIds, ids => sub2apiApi.bulkUpdate(ids, { schedulable: true }))}
                disabled={!isConnected || busy || selectedIds.length === 0}
              >
                <Power className="mr-2 h-4 w-4" />
                启用
              </Button>
              <Button
                variant="outline"
                className="text-yellow-700 hover:bg-yellow-500/10 hover:text-yellow-700"
                onClick={() => void runBatch('停用选中', selectedIds, ids => sub2apiApi.bulkUpdate(ids, { schedulable: false }))}
                disabled={!isConnected || busy || selectedIds.length === 0}
              >
                <PowerOff className="mr-2 h-4 w-4" />
                停用
              </Button>
              <Button
                variant="outline"
                className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                onClick={deleteUnavailable}
                disabled={!isConnected || busy || stats.problem === 0}
              >
                <Trash2 className="mr-2 h-4 w-4" />
                删除异常
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {!isConnected ? (
            <div className="flex items-center justify-center rounded-md border border-dashed py-10 text-sm text-muted-foreground">
              连接 Sub2API 后显示账号
            </div>
          ) : loading && accounts.length === 0 ? (
            <div className="flex items-center justify-center py-10">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : filteredAccounts.length === 0 ? (
            <div className="flex items-center justify-center rounded-md border border-dashed py-10 text-sm text-muted-foreground">
              暂无账号
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10">
                    <input
                      type="checkbox"
                      checked={allVisibleSelected}
                      onChange={(event) => toggleAllVisible(event.target.checked)}
                      className="h-4 w-4 rounded border-input accent-primary"
                    />
                  </TableHead>
                  <TableHead>账号</TableHead>
                  <TableHead>平台</TableHead>
                  <TableHead>状态</TableHead>
                  <TableHead>调度</TableHead>
                  <TableHead>额度</TableHead>
                  <TableHead>更新时间</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAccounts.map(account => {
                  const id = accountId(account);
                  const schedulable = resolveSchedulable(account);
                  const email = resolveEmail(account);
                  const problem = hasProblem(account);
                  return (
                    <TableRow key={id}>
                      <TableCell>
                        <input
                          type="checkbox"
                          checked={Boolean(selected[id])}
                          onChange={(event) => setSelected(current => ({ ...current, [id]: event.target.checked }))}
                          className="h-4 w-4 rounded border-input accent-primary"
                        />
                      </TableCell>
                      <TableCell>
                        <div className="min-w-0">
                          <div className="max-w-[260px] truncate font-medium" title={showSecrets ? email : undefined}>
                            {showSecrets ? email : maskEmail(email)}
                          </div>
                          <div className="max-w-[260px] truncate text-xs text-muted-foreground">
                            #{id} · {showSecrets ? resolveName(account) : maskEmail(resolveName(account))}
                          </div>
                          {resolveError(account) && (
                            <div className="max-w-[260px] truncate text-xs text-destructive" title={resolveError(account)}>
                              {resolveError(account)}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{resolvePlatform(account)}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={statusBadgeClass(account)}>
                          {problem ? <XCircle className="h-3 w-3" /> : <CheckCircle className="h-3 w-3" />}
                          {resolveStatus(account)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {schedulable === false ? (
                          <Badge variant="outline" className="border-yellow-500/40 bg-yellow-500/10 text-yellow-700 dark:text-yellow-300">停用</Badge>
                        ) : (
                          <Badge variant="outline" className="border-green-500/40 bg-green-500/10 text-green-700 dark:text-green-300">启用</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <pre className="max-w-[220px] overflow-hidden truncate text-xs text-muted-foreground">
                          {quotaText(quotas[id] || (account.openai_quota as Sub2ApiQuotaResult | undefined) || (account.quota as Sub2ApiQuotaResult | undefined))}
                        </pre>
                      </TableCell>
                      <TableCell>{formatDate(account.updated_at || account.last_test_at || account.created_at)}</TableCell>
                      <TableCell>
                        <div className="flex justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            onClick={() => void runAccountAction(id, '测试', () => sub2apiApi.testAccount(id))}
                            disabled={busy}
                            title="测试"
                          >
                            {busyKey === `${id}:测试` ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            onClick={() => void runAccountAction(id, '刷新', () => sub2apiApi.refreshAccount(id))}
                            disabled={busy}
                            title="刷新 token"
                          >
                            {busyKey === `${id}:刷新` ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            onClick={() => void runAccountAction(id, '额度', () => sub2apiApi.queryOpenAiQuota(id), { reload: false, loadQuota: true })}
                            disabled={busy}
                            title="查额度"
                          >
                            {busyKey === `${id}:额度` ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            onClick={() => void runAccountAction(id, schedulable === false ? '启用' : '停用', () => sub2apiApi.setSchedulable(id, schedulable === false))}
                            disabled={busy}
                            title={schedulable === false ? '启用调度' : '停用调度'}
                          >
                            {schedulable === false ? <Power className="h-4 w-4" /> : <PowerOff className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            onClick={() => void runAccountAction(id, '清错', () => sub2apiApi.clearError(id))}
                            disabled={busy}
                            title="清除错误"
                          >
                            <CheckCircle className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            onClick={() => setDetailsAccount(account)}
                            disabled={busy}
                            title="详情"
                          >
                            <FileText className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                            onClick={() => {
                              if (window.confirm(`确定删除 ${showSecrets ? email : maskEmail(email)} 吗？`)) {
                                void runAccountAction(id, '删除', () => sub2apiApi.deleteAccount(id));
                              }
                            }}
                            disabled={busy}
                            title="删除"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={Boolean(detailsAccount)} onOpenChange={(open) => !open && setDetailsAccount(null)}>
        <DialogContent className="max-h-[85vh] max-w-4xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>账号详情</DialogTitle>
          </DialogHeader>
          <pre className="whitespace-pre-wrap rounded-md bg-muted p-4 text-xs">
            {compactJson(detailsAccount)}
          </pre>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
