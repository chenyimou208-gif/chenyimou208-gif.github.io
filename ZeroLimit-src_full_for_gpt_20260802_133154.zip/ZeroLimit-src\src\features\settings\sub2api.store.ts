import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { secureStorage } from '@/services/storage/secureStorage';
import { sub2apiApi } from '@/services/api/sub2api.service';
import type { Sub2ApiConfig, Sub2ApiLoginResponse, Sub2ApiUser } from '@/types';

const STORAGE_KEY_SUB2API = 'zerolimit.sub2api.config.v1';

interface Sub2ApiStoreState {
  config: Sub2ApiConfig;
  isConnected: boolean;
  isConnecting: boolean;
  connectionError: string | null;
  user: Sub2ApiUser | null;
  setConfig: (config: Partial<Sub2ApiConfig>) => void;
  connect: (config?: Partial<Sub2ApiConfig>) => Promise<Sub2ApiLoginResponse>;
  disconnect: () => void;
  restore: () => Promise<boolean>;
}

const defaultConfig: Sub2ApiConfig = {
  baseUrl: 'https://aisiu.me/sub2api',
  email: 'admin@sub2api.local',
  password: '',
  gatewayKey: '',
  rememberPassword: false,
};

export const useSub2ApiStore = create<Sub2ApiStoreState>()(
  persist(
    (set, get) => ({
      config: defaultConfig,
      isConnected: false,
      isConnecting: false,
      connectionError: null,
      user: null,

      setConfig: (partial) => {
        const config = { ...get().config, ...partial };
        set({ config });
        sub2apiApi.setConfig(config);
      },

      connect: async (partial = {}) => {
        const config = { ...get().config, ...partial };
        set({ config, isConnecting: true, connectionError: null });
        sub2apiApi.setConfig(config);

        try {
          const session = await sub2apiApi.login();
          const user = await sub2apiApi.me().catch(() => session.user || null);
          set({
            isConnected: true,
            isConnecting: false,
            connectionError: null,
            user,
          });
          return session;
        } catch (error) {
          set({
            isConnected: false,
            isConnecting: false,
            connectionError: (error as Error).message,
            user: null,
          });
          throw error;
        }
      },

      disconnect: () => {
        sub2apiApi.setSession(null);
        set({ isConnected: false, connectionError: null, user: null });
      },

      restore: async () => {
        const config = get().config;
        sub2apiApi.setConfig(config);
        if (!config.baseUrl || !config.email || !config.password) return false;
        if (!config.rememberPassword) return false;

        try {
          await get().connect();
          return true;
        } catch {
          return false;
        }
      },
    }),
    {
      name: STORAGE_KEY_SUB2API,
      storage: createJSONStorage(() => ({
        getItem: (name) => {
          const data = secureStorage.getItem<Sub2ApiStoreState>(name);
          return data ? JSON.stringify(data) : null;
        },
        setItem: (name, value) => {
          secureStorage.setItem(name, JSON.parse(value));
        },
        removeItem: (name) => {
          secureStorage.removeItem(name);
        },
      })),
      partialize: (state) => ({
        config: {
          baseUrl: state.config.baseUrl,
          email: state.config.email,
          password: state.config.rememberPassword ? state.config.password : '',
          gatewayKey: state.config.rememberPassword ? state.config.gatewayKey : '',
          rememberPassword: state.config.rememberPassword,
        },
      }),
    }
  )
);
