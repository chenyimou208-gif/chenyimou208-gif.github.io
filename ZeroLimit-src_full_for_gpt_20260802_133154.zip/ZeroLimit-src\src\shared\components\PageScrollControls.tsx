﻿import { useEffect, useState } from 'react';
import { ChevronsUp } from 'lucide-react';
import { Button } from '@/shared/components/ui/button';

const SCROLL_CONTAINER_SELECTOR = '[data-app-scroll-container="true"]';

function getScrollContainer(): HTMLElement | null {
  return document.querySelector<HTMLElement>(SCROLL_CONTAINER_SELECTOR);
}

export function PageScrollControls() {
  const [state, setState] = useState({ canScroll: false, atTop: true });

  useEffect(() => {
    const container = getScrollContainer();
    if (!container) return;

    const updateState = () => {
      const maxScrollTop = Math.max(0, container.scrollHeight - container.clientHeight);
      setState({
        canScroll: maxScrollTop > 8,
        atTop: container.scrollTop <= 8,
      });
    };

    const mutationObserver = new MutationObserver(updateState);
    const resizeObserver = new ResizeObserver(updateState);

    updateState();
    container.addEventListener('scroll', updateState, { passive: true });
    window.addEventListener('resize', updateState);
    mutationObserver.observe(container, { childList: true, subtree: true });
    resizeObserver.observe(container);

    return () => {
      container.removeEventListener('scroll', updateState);
      window.removeEventListener('resize', updateState);
      mutationObserver.disconnect();
      resizeObserver.disconnect();
    };
  }, []);

  if (!state.canScroll || state.atTop) return null;

  const scrollToTop = () => {
    const container = getScrollContainer();
    if (!container) return;
    container.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <Button
      type="button"
      size="icon-lg"
      variant="outline"
      className="fixed bottom-6 right-5 z-50 rounded-full bg-background/95 shadow-lg backdrop-blur supports-[backdrop-filter]:bg-background/80"
      onClick={scrollToTop}
      title="回到顶部"
      aria-label="回到顶部"
    >
      <ChevronsUp className="h-5 w-5" />
    </Button>
  );
}
