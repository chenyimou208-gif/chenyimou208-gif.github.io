import { normalizeApiBase } from '@/shared/utils/connection';

export interface LocalConnectionConfig {
  apiBase?: string;
  managementKey?: string;
}

export async function readLocalConnectionConfig(): Promise<LocalConnectionConfig | null> {
  if (typeof window === 'undefined') return null;

  try {
    const [{ homeDir, join }, { readTextFile }] = await Promise.all([
      import('@tauri-apps/api/path'),
      import('@tauri-apps/plugin-fs'),
    ]);
    const configPath = await join(await homeDir(), '.zerolimit', 'connection.json');
    const content = await readTextFile(configPath);
    const parsed = JSON.parse(content) as LocalConnectionConfig;
    const apiBase = parsed.apiBase ? normalizeApiBase(parsed.apiBase) : '';
    const managementKey = parsed.managementKey?.trim() || '';

    if (!apiBase || !managementKey) return null;
    return { apiBase, managementKey };
  } catch {
    return null;
  }
}
